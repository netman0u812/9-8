# Constraint Library

Constraint-dispatch library, written for CVS Health.

A constraint plus a direction beats a blank page. Pick one constraint, generate three ideas that
satisfy it, keep the strongest.

## How to use

The library is split by **domain affinity**:

- **General** — works for any domain. Default for SPECIFICITY=NONE.
- **Software / artifact** — when DOMAIN=ARTIFACT.
- **Physical / object** — when DOMAIN=OBJECT.
- **Social / collective** — when the work involves getting other people to do something.
- **Lists** — domain-agnostic, for when the useful move is enumeration.

When in doubt, pick from General. When the user has named a domain, pick from that domain's
section. Choose at random, by mood match, or by what sits closest to the user's own wording.
Never enumerate the whole list at the user — pick one and apply it.

Interpret every constraint as broadly as it will stretch. "Does this count?" → yes. The
constraint supplies direction and just enough friction; both are the point. State the constraint,
apply it, then get out of the way.

---

## General — any domain (default)

**Halve the budget.**
Whatever the resource is — money, headcount, weeks, attention — assume half. Half forces a
different shape, not a smaller version of the same shape.

**Ten times the volume.**
Assume ten times the patients, claims, stores, tickets, or users. What breaks first is usually
the real design problem.

**Design for the worst day.**
Not the demo. The understaffed Monday, the outage, the week the flu clinic and the audit land
together. Build for that and the ordinary day takes care of itself.

**Start from the complaint.**
Take the most common complaint about the current state and treat it as the specification. Not the
sanitized version — the actual words people use.

**Remove the expert.**
Redesign it so the person doing the work needs no special training, no tribal knowledge, and no
one to ask. What has to change about the work itself?

**Delete the step everyone hates.**
Name the step people quietly skip or complain about. Remove it entirely. Now solve for what it
was protecting against — if anything.

**Same outcome, no meeting.**
Get to the same decision or handoff without anyone gathering. What information has to exist, and
where, for the meeting to be unnecessary?

**Move the decision.**
Take a decision that happens at one point and move it much earlier or much later. Earlier means
deciding with less information. Later means living with ambiguity longer. Both change the design.

**Assume it must work offline.**
No connectivity, no system, no lookup. Paper and a person. What survives that version is the
essential mechanism.

**Do it with what's already bought.**
No new tool, no new vendor, no new license. Only what the organization already owns and people
already have open.

**Invert the incentive.**
Find who is rewarded for the current behavior. Flip it. Then design for the world where the flip
already happened.

**Make the invisible visible.**
Take something real but unmeasured — waiting time, rework, handoff loss, the effort of asking —
and make it plainly visible. Often the visibility is the whole intervention.

**One-sentence handoff.**
Whatever gets passed between people or teams has to fit in one sentence. What has to be true
about the work for that to be enough?

**What if it were free?**
Assume cost is not a constraint, design it, then work backward and find which part actually
needed the money. Usually less than expected.

**Give the capability away.**
If a competitor got this exact capability tomorrow, what would still make the difference here?
Build that instead.

**The five-minute version.**
Whatever it is, there is a version that takes five minutes and captures most of the value. Find
it. Ship it before the real one.

**Keep the constraint you'd negotiate away.**
Identify the requirement everyone assumes will be relaxed — the deadline, the compliance rule,
the headcount. Refuse to relax it, and design under it.

**Design for the person who will not read instructions.**
No onboarding, no guide, no announcement email. It has to be obvious from the thing itself.

**Explain it to whoever pays.**
State the idea in the terms of the person funding it, in three sentences, with no internal
vocabulary. Ideas that survive that translation are usually the sound ones.

---

## Software / artifact (DOMAIN=ARTIFACT)

**One screen only.**
Everything fits on a single screen with no scrolling and no second view. What gets cut is the
answer.

**No new systems.**
Solve it inside tools that already exist and are already administered. Integration beats
invention here.

**Make it work where people already are.**
The tab already open, the app already on the phone, the inbox already being read. Anything that
requires going somewhere new loses.

**Read-only first.**
Build the version that only observes and reports. No writes, no changes, no approvals. Read-only
ships faster, needs less review, and often turns out to be sufficient.

**Assume the data is wrong.**
Design for missing fields, stale records, duplicates, and confidently incorrect entries. What
does the thing do when its inputs lie?

**Make the error message the product.**
Take the moment something fails and make that moment genuinely useful — what happened, why, and
the one next step. A good failure path beats a feature.

**Ship the smallest thing that changes a decision.**
Not the smallest thing that works. The smallest thing that causes somebody to do something
differently.

**It has to survive being ignored.**
Nobody looks at it for a month. No maintenance, no babysitting, no one clearing a queue. What
does it need to do to still be correct when someone returns?

**No training required.**
If it needs a session, a deck, or a champion to explain it, it is too complicated. Redesign until
the first use teaches itself.

**Build the report nobody has to request.**
Instead of answering the question, make the question stop being asked. Where would the answer
have to live?

---

## Physical / object (DOMAIN=OBJECT)

**Design for one hand.**
The other hand is holding a bag, a phone, a child, or a cane. Everything has to work one-handed.

**Waiting is the material.**
Someone is going to wait. Treat that time as the thing being designed rather than the thing being
eliminated.

**Signage only.**
No construction, no reorganization, no new equipment. Solve it with what can be printed and
placed. The constraint reveals how much of the problem was wayfinding.

**The last ten feet.**
Everything upstream works. Design only the final ten feet — the counter, the doorway, the shelf,
the handoff to the person.

**Assume it gets dropped, wet, and shared.**
It will be handled by many people in poor conditions and cleaned less often than intended.
Durability and legibility are the design, not afterthoughts.

**Make the shelf do the work.**
Solve it through arrangement and physical order rather than instruction or enforcement. The
layout should make the right action the easy one.

---

## Social / collective

**No mandate.**
Assume no authority to require anything. Adoption has to be earned voluntarily, one person at a
time. What makes the first person try it?

**Make the default the good choice.**
Change nothing about what people can do. Change only what happens when they do nothing.

**One person can start it.**
No committee, no budget, no approval. It has to be startable by one motivated person on a
Thursday, and still be worth doing at that size.

**Design the exit.**
Build in how it ends, gets retired, or gets handed off before building how it starts. Things
without exits accumulate.

**Give the credit away.**
Structure it so the visible credit goes to the people doing the work rather than the people
proposing it. Notice what that changes about the design.

**Make refusing visible.**
Not punished — visible. When declining to participate is simply observable, behavior shifts
without enforcement.

---

## Lists (any domain — for when enumeration is the move)

**Enumerate to exhaustion.**
List every instance until the list stops producing new kinds. The tail is where the non-obvious
ones live; most people stop at seven.

**List what's missing.**
Inventory what is absent rather than present — the roles nobody holds, the data nobody captures,
the step nobody owns.

**Rank by regret.**
Order the options by how much they would be regretted in a year, not by expected value. Different
list, usually.

**Name the twenty.**
Force exactly twenty. The first five are obvious, the middle ten are the real work, and the last
five are either nonsense or the good ones.

**List the ones nobody would say out loud.**
Enumerate the options that are true but impolitic. They frequently contain the actual constraint.

---

Constraints are grouped by domain affinity for use with the routing logic in `SKILL.md`.

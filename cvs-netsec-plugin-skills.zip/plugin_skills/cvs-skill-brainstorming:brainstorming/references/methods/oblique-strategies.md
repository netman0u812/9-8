# Oblique Strategies

Brian Eno + Peter Schmidt, 1975. A deck of ~110 gnomic cards for breaking studio deadlocks. Used on Bowie's *Berlin Trilogy*, *Music for Airports*, and dozens of other records.

## When to use

- Stuck mid-project; have material in front of you, lost contact with it
- Recording-studio energy: tactical decisions inside a defined work
- Group impasse: drawing a card breaks the loop without anyone needing to "be right"
- Decision deadline: forces a move

## Don't use when

- Blank page (the cards assume material exists)
- High-stakes structural decisions

## Procedure

1. Draw a card at random (not by what feels appropriate — that defeats the operation).
2. Apply it literally to the next decision in front of you. **The card is trusted even if its appropriateness is quite unclear** (Eno).
3. Make the move it suggests.
4. Don't over-explain. The card; what it means here; the move. Done.

## The technique

Each card is a short, gnomic instruction — deliberately ambiguous, sometimes contradictory, meant to be applied literally to whatever decision is in front of you. Examples from the deck: "Honour thy error as a hidden intention." "Use an old idea." "Work at a different speed."

When applying this method: draw one constraint at random (do not choose the one that feels appropriate — that defeats the operation), state it, apply it literally to the next decision, and make the move. If you know a real card, use it and say so. If not, apply the technique with a constraint in the same register: terse, imperative, oblique to the problem rather than about it.

Full deck and history (for the user, offline): rtqe.net/ObliqueStrategies (Gregory Alan Taylor's archive).

## Anti-slop notes

- Prefer real cards when you know them, and attribute. Don't pad the output — card, meaning here, move. Three sentences max.
- Don't apologize when the card lands strangely. The strangeness is the operation.

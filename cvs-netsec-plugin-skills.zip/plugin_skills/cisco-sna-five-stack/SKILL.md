---
name: cisco-sna-five-stack
description: Use for Cisco Secure Network Analytics (CSNA/SNA) deployment architecture at CVS Health — the five-stack independent Manager model (Stack 1 CVS Enterprise, Stack 2 Aetna Enterprise, Stack 3 Retail/SNAT, Stack 4 Common COLO, Stack 5 Cloud), Flow Collector placement, telemetry sourcing (NetFlow, FTD, PAN-OS IPFIX/App-ID, ISE pxGrid, 128T SD-WAN, Cisco Telemetry Broker), detection coverage scoring, XDR/Splunk/ISE integration, and CCD Platform-derived host group governance. Trigger on "SNA," "CSNA," "Secure Network Analytics," "five-stack," "Flow Collector," "FC-CVS/AETNA/RETAIL/COLO," "SNA-MGR," "ODID," "pxGrid," or "ETA," even if "SNA" isn't spelled out. Do not confuse with "Secure Network Access" (NAC) — see nac-ztna-fpms/forescout-hw-refresh instead. Also consult cvs-netsec-context for org facts and ccd-platform-data-model for the underlying IPAM/LM datasets.
---

# Cisco Secure Network Analytics (CSNA) — Five-Stack Architecture

Source: "Cisco Secure Network Analytics — Enterprise Deployment Vision & Strategy," CVS Health InfoSec / CCD Platform, v1.0, 2026-05-19, DRAFT. Author: M. J. Martin. Data basis: IPAM v3.78, location_master v5.9g, retail_networks v2.8 (326,809 records total).

## Core thesis

CVS Health's network — 15+ years of acquisitions culminating in the 2018 Aetna merger, four overlapping RFC1918 spaces, six routing domains, 11,000 retail locations, SNAT-masked SD-WAN — cannot run a single SNA Manager. **45 confirmed IP collisions** between CVS and Aetna routing domains (public space, RFC1918, GCP BU allocations, even 203.0.113.0 documentation space) mean a shared Manager would build composite behavioral baselines for fictional entities, producing unreliable alerts in both directions. **Five independent Manager + Data Store stacks eliminate this by construction** — one per routing-domain cluster, each with its own telemetry mechanism, Flow Collector placement, and baseline scope. Zero physical traffic taps required across all five stacks.

Cross-domain correlation happens *above* SNA, in Cisco XDR (entity-based: user identity, hostname, cert fingerprint — not IP), and in Splunk (domain-tagged event retention/hunting).

## Stack assignment rules (authoritative — derived, never manual)

Stack assignment is governed by the `ROUTING_DOMAIN` field in `all_IP_networks` (IPAM). This field cannot be overridden by server owner, app team, or manual estimate. Any IPAM update that changes a subnet's `ROUTING_DOMAIN` must trigger SNA host group review.

| ROUTING_DOMAIN | Stack | Manager | FC type |
|---|---|---|---|
| Internal-PBM | Stack 1 CVS Enterprise | SNA-MGR-CVS | Physical FC at Shea DC, RI One, 2100 Highland, Wood Dale IL |
| Internal-Retail | Stack 3 CVS Retail | SNA-MGR-RETAIL | NetFlow FC at 128T SD-WAN hub controllers (RI One, Shea) |
| Partner · Offshore | Stack 1 CVS Enterprise | SNA-MGR-CVS | As per CVS enterprise FC scope |
| Internal-HCB | Stack 2 Aetna Enterprise | SNA-MGR-AETNA | Physical FC at MID, WDC, Phoenix Aetna DC, Woodbridge NJ DR |
| COLO | Stack 4 Common COLO | SNA-MGR-COLO | Physical FC at LV Switch, ATL Switch, Sparks TRE (ODID-scoped) |
| Cloud-Azure · Cloud-GCP · Cloud-AWS · Internet-Facing | Stack 5 Cloud | SNA-MGR-CLOUD | Virtual FC via Cisco Telemetry Broker |

Non-negotiable: no subnet enters an SNA host group without a verified `CANONICAL_LOCATION` in location_master. Update order is **LM → IPAM → SNA configuration**.

## The five stacks

**Stack 1 — CVS Enterprise** (11,847 subnets, Internal-PBM). Shea DC (Scottsdale AZ), RI One (Woonsocket RI), RI-2100 Highland (Cumberland RI), Wood Dale IL, CVS internet egress. PBM, enterprise apps, Omnicare, Caremark/CVS heritage, DCs, call centers. Contains 191 Aetna-heritage subnets at shared campuses (expected, not misconfig). Telemetry: unsampled NetFlow v9/IPFIX, FTD connection logs (100K eps), PAN-OS IPFIX+App-ID, ISE pxGrid (CVS scope), Secure Client NVM.

**Stack 2 — Aetna Enterprise** (5,293 subnets, Internal-HCB). Middletown CT (MDC), Windsor CT (WDC), Phoenix AZ, Hartford CT HQ, Aetna egress. HCB, Claims, CarePlus VDC fleet (91 field sites), Member Portal. Contains 29 CVS/Caremark-heritage subnets at Aetna DCs (confirmed normal, bi-directional). Telemetry: same mechanisms as Stack 1, separate ISE pxGrid subscription.

**Stack 3 — CVS Retail / SNAT-masked** (9,144 stores, Internal-Retail). Includes MinuteClinic and Optical. All store device traffic PAT'd at the 128T SD-WAN router edge — internal 172.16–172.31.x/26 device IPs (POS, Rx, workstations) are **permanently invisible** to enterprise NetFlow. SNA collects only from 128T hub controllers at RI One (eastern stores) and Shea DC (western stores); source IP = store WAN/tunnel IP, one effective host per store. Host group = `RETAIL-[SITE_CODE]` using store WAN IP — **never** the 294,341 device-level records in retail_networks (those are store-internal and SNA-irrelevant). 84.4% of stores carry PCI designation; SNA gives store-aggregate anomaly detection only — per-device PCI control requires in-store endpoint/ISE micro-segmentation, not SNA.

**Stack 4 — Common COLO** (2,455 subnets, COLO domain). Las Vegas NV (The Core Campus), Atlanta GA (The Keep Campus), Sparks NV (Switch TRE). Physical co-lo carrying CVS + Aetna workloads on separate VRFs. LV Switch Colo confirmed to carry **four heritage types simultaneously** (CVS, AETNA, Caremark/CVS, SWITCH) — Hillsboro OR carries AETNA+SWITCH. COLO is the CVS↔Aetna interconnect zone. Telemetry: Flexible NetFlow per-VRF with ODID tagging (`ODID=CVS-VRF` / `ODID=AETNA-VRF`) — **mandatory prerequisite**, not precautionary; distinct from Stack 5, no Telemetry Broker involvement.

**Stack 5 — Cloud** (1,347 subnets, Azure/GCP/AWS/Internet-Facing). Cloud IPs are BU-allocated; must be derived via CCD Platform `hostname_translate.py` rules, never from the server owner field. 12 confirmed CVS/Aetna IP collisions in GCP space (10.143.x, 10.149.x, 10.236.x) require Telemetry Broker BU-tag scoping rules before IPFIX forward — cannot rely on IP alone. Telemetry: Cisco Telemetry Broker pulls AWS VPC flow logs (S3) + Azure NSG logs (Blob) → IPFIX → virtual FC. Vegas PDC→Azure Zerto DR traffic included in CVS Azure path.

## Detection coverage (scored 0–10, at maturity)

| Stack | Score | Note |
|---|---|---|
| Stack 1 CVS Enterprise | 9.3 | Strong |
| Stack 2 Aetna Enterprise | 9.3 | Strong |
| Stack 3 Retail (SNAT) | 5.2 | Fundamental SNAT constraint, not a deployment quality issue |
| Stack 4 COLO | 7.2 | — |
| Stack 5 Cloud | 8.4 | — |

East-west L7 payload gap applies to *all* stacks (no physical taps deployed) — internal DC traffic across Cisco switches is NetFlow metadata only. Mitigations: ISE micro-segmentation, PAN-OS App-ID at firewall insertion points, Cisco XDR endpoint correlation. Primary use cases: healthcare PHI exfiltration detection, ransomware pre-deployment (SMB/RDP spikes, port sweeps, MITRE T1570), encrypted C2 detection via ETA (TLS handshake metadata / cert fingerprinting / beacon timing — no decryption, so no PHI exposure), retail store anomaly detection (Stack 3, store-aggregate only).

## Identity & integration layer

- **Cisco ISE pxGrid** — real-time user-to-IP binding (802.1X, RADIUS, DHCP). Each Manager gets a **domain-scoped pxGrid subscription**; Stack 1 must never receive Aetna user-IP mappings and vice versa (cross-domain pxGrid scope = the IP collision problem applied to identity). Not available for Stack 3 (SNAT masks device identity). Feeds automated ISE quarantine: SNA detection → pxGrid → ISE policy change, in real time, no manual FW rule change (target: <2 min round-trip for S1+S2).
- **PAN-OS User-ID** — supplements ISE for non-802.1X traffic; App-ID adds L7 context to SNA flows at CVS/Aetna perimeters.
- **ETA (Encrypted Traffic Analytics)** — TLS metadata analysis (cipher suite, cert chain, SNI, timing) without decryption; Talos fingerprinting, beacon detection, DGA detection via DNS flow patterns.
- **Cisco XDR** — cross-stack correlation by entity, not IP; sidesteps the overlap problem entirely at the correlation layer.
- **Splunk** — long-term retention, domain-tagged events, SOC 2 evidence, cross-domain hunt.

## CCD Platform governance (data sources)

- `all_IP_networks v3.78` — 20,942 subnets; `CANONICAL_LOCATION`, `ROUTING_DOMAIN`, `HERITAGE`, `DATA_QUALITY` (Authoritative vs Inferred — drives separate host group tiers). Open patch: Observed→Inferred DATA_QUALITY issue since v3.71, must resolve before Stack 1 baselining.
- `location_master v5.9g` — 11,526 sites; SITE_CODE, NET_TYPE, HERITAGE, LOCATION_TYPE; source for FC host group naming and Stack 3 SITE_CODE mapping.
- `retail_networks v2.8` — 294,341 device records / 9,144 stores; canonical SITE_CODE + metadata only — **device IPs are not SNA-relevant** (SNAT-masked). Store WAN/tunnel IPs come from the 128T controller inventory instead.

## Roadmap (sequential — each stack reaches operational maturity before the next begins)

- **Phase 1 (0–60d):** Stack 1. SNA-MGR-CVS, FC-CVS-DC ×4, FC-CVS-INET ×3, unsampled NetFlow all CVS L3 boundaries, FTD integration, ISE pxGrid (CVS), PAN-OS IPFIX+App-ID. Validate 0 sampled NetFlow sources; baseline 30 days.
- **Phase 2 (60–120d):** Stacks 2 & 3. SNA-MGR-AETNA (FC-AETNA-DC ×3, FC-AETNA-INET ×2, separate pxGrid), SNA-MGR-RETAIL (FC-RETAIL at RI One + Shea). Validate zero cross-stack IP leakage S1/S2. Talos TI activation.
- **Phase 3 (120–180d):** Stacks 4 & 5. Flexible NetFlow per-VRF at LV+ATL COLO (ODID hard prereq), SNA-MGR-COLO, Telemetry Broker (AWS VPC + Azure NSG + GCP BU-tag rules), SNA-MGR-CLOUD, Cisco XDR integration across all five stacks, cross-stack entity correlation activated.
- **Phase 4 (180+d):** Tuning/maturity — Splunk all stacks, ISE quarantine runbooks (S1+S2), SOC 2 evidence mapping, ETA tuning, cross-stack XDR hunt playbooks, annual IPAM/stack review, Stack 3 retail baseline maturity review at 90 days post-live.

## Success criteria

**Technical:** 0 cross-stack IP collisions in host groups; 0 sampled NetFlow sources in production; 0 unlabeled Inferred subnets; 0 Stack 3 host groups using /26 internal LAN blocks; 0 COLO FCs without ODID validation; config-drift review within 5 business days of any IPAM update.

**Operational (at maturity):** ≥85% detection rate on SOC red-team exercises (S1+S2); <10% false positive rate (90 days post-baseline); <15 min MTTD on simulated lateral movement (S1); <2 min ISE quarantine round-trip (S1+S2); 100% of applicable SOC 2 controls with SNA evidence.

**Compliance:** SNA evidences HIPAA Technical Safeguards (audit controls, auto-logoff monitoring), PCI DSS Req. 10 (log/monitor all access), SOC 2 CC7.2.

## Open prerequisites (must resolve before FC deployment)

**CRIT-1 (hard blocker):** COLO VRF-scoped Flexible NetFlow at LV Switch — configure per-VRF with ODID tagging (`ODID=CVS-VRF`/`ODID=AETNA-VRF`) at all Switch COLO fabric switches; validate before activating FC-COLO. Without it, CVS and Aetna flows merge in Stack 4.

**CRIT-2 (hard blocker):** Stack 3 host groups must use store WAN IPs, not internal device IPs — retail is SNAT-masked at the 128T edge; the 294,341 retail_networks device records must **not** be added to Stack 3 host group config.

**CRIT-3 (hard blocker):** Exclude 11 retail /24 collision blocks from Stack 1/2 enterprise host groups — 3 blocks collide with Internal-PBM (172.16.2.0/24, 172.16.7.0/24, 172.20.232.0/24), 8 with Internal-HCB (172.19.5.0/24, 172.19.16.0/24, 172.24.2.0/24, 172.28.1–3.0/24, 172.28.106.0/24, 172.31.224.0/24).

**ATTN-4:** Wood Dale IL (US_WOI_IL_DC) — unplanned 4th CVS DC, absent from original Stack 1 architecture; needs FC assessment and IPAM subnet count before go-live.

**ATTN-5:** Internet egress FC model ("3 CVS + 2 Aetna egress") needs validation against actual border router topology — IPAM shows only 16 Internet-Facing subnets at RI One + 1 at Phoenix Aetna DC.

**ATTN-6:** GCP BU-tag scoping rules in Cisco Telemetry Broker — 12 confirmed CVS/Aetna IP collisions in GCP space (10.143.x, 10.149.x, 10.236.x), Stack 5 requirement.

**ATTN-7:** Reserved address space in production (1.1.1.0 Cloudflare anycast at Shea DC, 203.0.113.0 RFC 5737 TEST-NET at Aetna MDC) — active subnets, do **not** exclude from host groups; flag for IPAM governance remediation instead.

**ATTN-8:** Resolve Observed→Inferred DATA_QUALITY patch (open since all_IP_networks v3.71) before Stack 1 baselining — ~8,400 subnets in Stacks 1/2 carry DATA_QUALITY=Inferred; use distinct naming (`CVS-DC-AUTH` vs `CVS-DC-INFD`) if included before the patch resolves.

## Working notes

- "SNA" here = **Secure Network Analytics** (NDR/behavioral). Don't conflate with "Secure Network Access" (NAC) — that's a different Cisco product line covered by nac-ztna-fpms / forescout-hw-refresh.
- This document is v1.0 DRAFT (2026-05-19) — treat figures (subnet counts, collision counts, scores) as this version's snapshot; flag if the person references a newer IPAM/LM version, since stack composition is directly derived from those datasets and would need to be re-validated.
- When asked about FC placement or stack membership for a specific subnet, apply the ROUTING_DOMAIN rule above rather than guessing from heritage or IP range alone — consult fw-src-dst-policy-analysis's directionality/topology-fingerprint method if the question also involves firewall enforcement, not just SNA visibility.

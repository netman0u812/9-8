# Base Template and KPI Cards

The self-contained HTML scaffold for Step 4, plus the KPI card pattern.

## Base Template

This shows Layout A's structure (header → KPI row → chart row → table). For Layout B, move `.filters` into a persistent sidebar `<aside>` alongside `.dashboard-container` instead of inside the header. For Layout C, drop the standalone `.kpi-row` section and place a small KPI value directly inside each `.chart-container` instead.

**CDN rules (do not deviate):**
- Load external scripts from `cdnjs.cloudflare.com` **only**. Claude.ai artifact previews block every other CDN host — a jsdelivr or unpkg URL means the user sees a blank dashboard in the preview even though the downloaded file would work.
- **Never add SRI `integrity` attributes.** A wrong hash makes the browser silently refuse the script, and the user sees a blank page with no visible error.
- Only add the date adapter if a chart actually uses a time scale (`type: 'time'` on an axis). None of the patterns below need it — they all use category axes. If you do need it, add it **after** the `chart.umd.min.js` script tag — the adapter registers itself against a global `Chart` that must already exist — and use the **`.bundle`** build (the plain build omits date-fns and fails silently):
  `<script src="https://cdnjs.cloudflare.com/ajax/libs/chartjs-adapter-date-fns/3.0.0/chartjs-adapter-date-fns.bundle.min.js"></script>`

**Visible-failure rule:** a general employee should never see a silent blank. Any failure — the chart library didn't load, no rows match the current filters, a value can't be computed — must render as a short plain-language message in the affected spot saying what happened and what to do about it. Console errors don't count; assume the user will never open dev tools.

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Title</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.5.0/chart.umd.min.js"></script>
    <style>
        /* Dashboard styles go here */
    </style>
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <h1>Dashboard Title</h1>
            <div class="filters">
                <!-- Filter controls -->
            </div>
        </header>

        <section class="kpi-row">
            <!-- KPI cards -->
        </section>

        <section class="chart-row">
            <!-- Chart containers -->
        </section>

        <section class="table-section">
            <!-- Data table -->
        </section>

        <footer class="dashboard-footer">
            <span>Data as of: <span id="data-date"></span></span>
        </footer>
    </div>

    <script>
        // Embedded data
        const DATA = [];

        // Visible-failure guard — no silent blanks. If Chart.js didn't load
        // (no internet, CDN blocked by a proxy), swap each canvas for a
        // plain-language message and keep going: KPIs, tables, and the
        // CSS-grid heatmap all render without Chart.js.
        const CHARTS_AVAILABLE = typeof Chart !== 'undefined';
        if (!CHARTS_AVAILABLE) {
            document.querySelectorAll('.chart-container canvas').forEach(canvas => {
                const msg = document.createElement('div');
                msg.className = 'chart-error';
                msg.textContent = "Charts couldn't load. Check your internet connection, then close and reopen this file. Your data is unaffected.";
                canvas.replaceWith(msg);
            });
        }

        // Dashboard logic
        class Dashboard {
            constructor(data) {
                this.rawData = data;
                this.filteredData = data;
                this.charts = {};
                this.init();
            }

            init() {
                this.setupFilters();
                this.renderKPIs();
                this.renderCharts();
                this.renderTable();
            }

            applyFilters() {
                // Filter logic
                this.filteredData = this.rawData.filter(row => {
                    // Apply each active filter
                    return true; // placeholder
                });
                this.renderKPIs();
                this.updateCharts();
                this.renderTable();
            }

            renderCharts() {
                if (!CHARTS_AVAILABLE) return; // canvases already show the error message
                // ... create charts
            }

            updateCharts() {
                if (!CHARTS_AVAILABLE) return;
                // ... update chart data
            }

            // ... methods for the other sections
        }

        const dashboard = new Dashboard(DATA);
    </script>
</body>
</html>
```

## KPI Card Pattern

```html
<div class="kpi-card">
    <div class="kpi-label">Total Revenue</div>
    <div class="kpi-value" id="kpi-revenue">$0</div>
    <div class="kpi-change positive" id="kpi-revenue-change">+0%</div>
</div>
```

```javascript
function renderKPI(elementId, value, previousValue, format = 'number') {
    const el = document.getElementById(elementId);
    const changeEl = document.getElementById(elementId + '-change');

    // Format the value
    el.textContent = formatValue(value, format);

    // Calculate and display change
    if (previousValue && previousValue !== 0) {
        const pctChange = ((value - previousValue) / previousValue) * 100;
        const sign = pctChange >= 0 ? '+' : '';
        changeEl.textContent = `${sign}${pctChange.toFixed(1)}% vs prior period`;
        changeEl.className = `kpi-change ${pctChange >= 0 ? 'positive' : 'negative'}`;
    }
}

function formatValue(value, format) {
    switch (format) {
        case 'currency':
            if (value >= 1e6) return `$${(value / 1e6).toFixed(1)}M`;
            if (value >= 1e3) return `$${(value / 1e3).toFixed(1)}K`;
            return `$${value.toFixed(0)}`;
        case 'percent':
            return `${value.toFixed(1)}%`;
        case 'number':
            if (value >= 1e6) return `${(value / 1e6).toFixed(1)}M`;
            if (value >= 1e3) return `${(value / 1e3).toFixed(1)}K`;
            return value.toLocaleString();
        default:
            return value.toString();
    }
}

// Shared helper — use it anywhere row data lands in innerHTML (tables,
// heatmap cells, filter options). Pasted data containing <, &, or stray
// HTML will otherwise break the layout or inject markup.
function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, c => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
}
```


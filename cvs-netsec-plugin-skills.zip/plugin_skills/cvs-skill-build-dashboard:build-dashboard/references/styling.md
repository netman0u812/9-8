# Dashboard Styling

CSS for Step 4, including the colour system and accessibility rules, layout, cards, filters, tables, and responsive behaviour.

## CSS Styling for Dashboards

### Color and Accessibility Principles

- **Color encodes data, not decoration.** Use a bright accent for the one series that matters; grey out the rest.
- **Never rely on color alone** to distinguish series — pair with direct labels, distinct line styles (solid/dashed), or point shapes so the dashboard still works for colorblind users (~8% of men).
- **Categorical data**: distinct hues, max 6-8 before a legend becomes unreadable. Use blue/orange as the primary pair, not red/green.
- **Sequential data** (e.g. heatmap intensity): single-hue gradient, light to dark.
- **Diverging data** (e.g. above/below target): two-hue gradient with a neutral midpoint.
- **Bar charts always start at zero** — a bar from 95 to 100 exaggerates a 5% difference into something that looks 20x bigger.
- **Status colors are semantic, not decorative**: green/amber/red for positive/neutral/negative should be consistent across every KPI card, gauge, and table cell in the dashboard.

### Color System

Don't default to variant 1 every time. Pick based on the audience/brand from Step 1 — if the user names an industry, brand color, or explicit mood, match it instead. All three keep the same colorblind-safe blue/orange-style primary pair and the same status colors; only the surface tone and accent rotation change.

**Variant 1 — Cool neutral (default: general business, SaaS, unspecified audience):**
```css
:root {
    --bg-primary: #f8f9fa;
    --bg-card: #ffffff;
    --bg-header: #1a1a2e;
    --text-primary: #212529;
    --text-secondary: #6c757d;
    --text-on-dark: #ffffff;
    --color-1: #4C72B0;
    --color-2: #DD8452;
    --color-3: #55A868;
    --color-4: #C44E52;
    --color-5: #8172B3;
    --color-6: #937860;
    --positive: #28a745;
    --negative: #dc3545;
    --neutral: #6c757d;
    --gap: 16px;
    --radius: 8px;
}
```

**Variant 2 — Warm slate (finance, ops, audit — data that skews serious/numeric):**
```css
:root {
    --bg-primary: #f5f4f2;
    --bg-card: #ffffff;
    --bg-header: #2b2a28;
    --text-primary: #26241f;
    --text-secondary: #6f6a60;
    --text-on-dark: #f5f4f2;
    --color-1: #3f6b8f;
    --color-2: #b9773e;
    --color-3: #4f7a5c;
    --color-4: #9c4a45;
    --color-5: #6b5b7a;
    --color-6: #a68b5b;
    --positive: #3f7d4a;
    --negative: #a13d38;
    --neutral: #6f6a60;
    --gap: 16px;
    --radius: 6px;
}
```

**Variant 3 — Clinical light (healthcare, support/ops monitoring — needs high scan-clarity, low visual weight):**
```css
:root {
    --bg-primary: #eef2f5;
    --bg-card: #ffffff;
    --bg-header: #0f3d4a;
    --text-primary: #1c2b30;
    --text-secondary: #5c7078;
    --text-on-dark: #ffffff;
    --color-1: #2f7ea3;
    --color-2: #d98b3f;
    --color-3: #479b7a;
    --color-4: #c05c56;
    --color-5: #6f7fa8;
    --color-6: #8a9a4f;
    --positive: #2e8b57;
    --negative: #c0392b;
    --neutral: #5c7078;
    --gap: 14px;
    --radius: 10px;
}
```

If the user gives a specific brand color, keep that structure but swap `--color-1` and `--bg-header` for their brand color (adjusted for contrast), and re-derive `--color-2` through `--color-6` to stay distinct and colorblind-safe rather than reusing one of the three sets verbatim.

### Layout

```css
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: var(--bg-primary);
    color: var(--text-primary);
    line-height: 1.5;
}

.dashboard-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: var(--gap);
}

.dashboard-header {
    background: var(--bg-header);
    color: var(--text-on-dark);
    padding: 20px 24px;
    border-radius: var(--radius);
    margin-bottom: var(--gap);
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
}

.dashboard-header h1 {
    font-size: 20px;
    font-weight: 600;
}
```

### KPI Cards

```css
.kpi-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: var(--gap);
    margin-bottom: var(--gap);
}

.kpi-card {
    background: var(--bg-card);
    border-radius: var(--radius);
    padding: 20px 24px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
}

.kpi-label {
    font-size: 13px;
    color: var(--text-secondary);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 4px;
}

.kpi-value {
    font-size: 28px;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 4px;
}

.kpi-change {
    font-size: 13px;
    font-weight: 500;
}

.kpi-change.positive { color: var(--positive); }
.kpi-change.negative { color: var(--negative); }
```

### Chart Containers

```css
.chart-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
    gap: var(--gap);
    margin-bottom: var(--gap);
}

.chart-container {
    background: var(--bg-card);
    border-radius: var(--radius);
    padding: 20px 24px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
}

.chart-container h3 {
    font-size: 14px;
    font-weight: 600;
    color: var(--text-primary);
    margin-bottom: 16px;
}

.chart-container canvas {
    max-height: 300px;
}

/* Shown in place of a canvas when Chart.js fails to load */
.chart-error {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 200px;
    padding: 20px;
    text-align: center;
    color: var(--text-secondary);
    background: var(--bg-primary);
    border: 1px dashed #ced4da;
    border-radius: var(--radius);
    font-size: 14px;
}
```

### Filters

```css
.filters {
    display: flex;
    gap: 12px;
    align-items: center;
    flex-wrap: wrap;
}

.filter-group {
    display: flex;
    align-items: center;
    gap: 6px;
}

.filter-group label {
    font-size: 12px;
    color: rgba(255, 255, 255, 0.7);
}

.filter-group select,
.filter-group input[type="date"] {
    padding: 6px 10px;
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 4px;
    background: rgba(255, 255, 255, 0.1);
    color: var(--text-on-dark);
    font-size: 13px;
}

.filter-group select option {
    background: var(--bg-header);
    color: var(--text-on-dark);
}
```

### Data Table

```css
.table-section {
    background: var(--bg-card);
    border-radius: var(--radius);
    padding: 20px 24px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
    overflow-x: auto;
}

.data-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}

.data-table thead th {
    text-align: left;
    padding: 10px 12px;
    border-bottom: 2px solid #dee2e6;
    color: var(--text-secondary);
    font-weight: 600;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    white-space: nowrap;
    user-select: none;
}

.data-table thead th:hover {
    color: var(--text-primary);
    background: #f8f9fa;
}

.data-table tbody td {
    padding: 10px 12px;
    border-bottom: 1px solid #f0f0f0;
}

.data-table tbody tr:hover {
    background: #f8f9fa;
}

.data-table tbody tr:last-child td {
    border-bottom: none;
}

.table-empty {
    text-align: center;
    color: var(--text-secondary);
    padding: 24px 12px;
}
```

### Responsive Design

```css
@media (max-width: 768px) {
    .dashboard-header {
        flex-direction: column;
        align-items: flex-start;
    }

    .kpi-row {
        grid-template-columns: repeat(2, 1fr);
    }

    .chart-row {
        grid-template-columns: 1fr;
    }

    .filters {
        flex-direction: column;
        align-items: flex-start;
    }
}

@media print {
    body { background: white; }
    .dashboard-container { max-width: none; }
    .filters { display: none; }
    .chart-container { break-inside: avoid; }
    .kpi-card { border: 1px solid #dee2e6; box-shadow: none; }
}
```


# Dashboard Layouts

Wireframes for the three layouts in Step 3 of `SKILL.md`. Pick by purpose and data shape.

**Layout A — KPI band + charts (default for executive overview, mixed data shape):**
```
┌──────────────────────────────────────────────────┐
│  Dashboard Title                    [Filters ▼]  │
├────────────┬────────────┬────────────┬───────────┤
│  KPI Card  │  KPI Card  │  KPI Card  │ KPI Card  │
├────────────┴────────────┼────────────┴───────────┤
│                         │                        │
│    Primary Chart        │   Secondary Chart      │
│    (largest area)       │                        │
│                         │                        │
├─────────────────────────┴────────────────────────┤
│    Detail Table (sortable, scrollable)           │
└──────────────────────────────────────────────────┘
```
Use when: purpose is an executive summary or general reporting, and data has a healthy mix of trend + category + detail.

**Layout B — sidebar filters + single dominant chart (operational monitoring, mostly time-series data):**
```
┌────────┬─────────────────────────────────────────┐
│ Filters│  Dashboard Title                         │
│        ├───────────┬───────────┬─────────────────┤
│ Region │  KPI Card │  KPI Card │  KPI Card        │
│ Range  ├───────────┴───────────┴─────────────────┤
│ Status │                                          │
│ ...    │        Primary Chart (full width)        │
│        │        e.g. rolling time series           │
│        ├──────────────────────────────────────────┤
│        │    Detail Table                          │
└────────┴──────────────────────────────────────────┘
```
Use when: purpose is live/near-live monitoring, one metric dominates (e.g. volume over time), and users will keep the same filters open while scanning — a persistent sidebar beats a header dropdown.

**Layout C — KPIs merged into chart headers, no separate KPI row (deep-dive / analysis, mostly categorical data):**
```
┌──────────────────────────────────────────────────┐
│  Dashboard Title                    [Filters ▼]  │
├──────────────────────────┬───────────────────────┤
│ Chart A          [KPI]   │ Chart B        [KPI]  │
├──────────────────────────┴───────────────────────┤
│ Chart C                                   [KPI]  │
├──────────────────────────────────────────────────┤
│    Detail Table (sortable, scrollable, wide)     │
└──────────────────────────────────────────────────┘
```
Use when: purpose is deep-dive analysis and there isn't one clean set of 2-4 headline numbers — each chart has its own supporting number instead.

# Filters and Interactivity

Implementation for Step 6 — dropdown filters, date ranges, combined filter logic, sortable tables.

## Filter and Interactivity Implementation

### Dropdown Filter

```html
<div class="filter-group">
    <label for="filter-region">Region</label>
    <select id="filter-region" onchange="dashboard.applyFilters()">
        <option value="all">All Regions</option>
    </select>
</div>
```

```javascript
function populateFilter(selectId, data, field) {
    const select = document.getElementById(selectId);
    const values = [...new Set(data.map(d => d[field]))].sort();

    // Keep the "All" option, add unique values
    values.forEach(val => {
        const option = document.createElement('option');
        option.value = val;
        option.textContent = val;
        select.appendChild(option);
    });
}

function getFilterValue(selectId) {
    const val = document.getElementById(selectId).value;
    return val === 'all' ? null : val;
}
```

### Date Range Filter

```html
<div class="filter-group">
    <label>Date Range</label>
    <input type="date" id="filter-date-start" onchange="dashboard.applyFilters()">
    <span>to</span>
    <input type="date" id="filter-date-end" onchange="dashboard.applyFilters()">
</div>
```

```javascript
// Dates were normalized to ISO YYYY-MM-DD at ingest (Step 2), so plain
// string comparison is correct and timezone-proof — new Date() parsing
// would shift dates across timezones
function filterByDateRange(data, dateField, startDate, endDate) {
    return data.filter(row => {
        if (startDate && row[dateField] < startDate) return false;
        if (endDate && row[dateField] > endDate) return false;
        return true;
    });
}
```

### Combined Filter Logic

```javascript
applyFilters() {
    const region = getFilterValue('filter-region');
    const category = getFilterValue('filter-category');
    const startDate = document.getElementById('filter-date-start').value;
    const endDate = document.getElementById('filter-date-end').value;

    this.filteredData = this.rawData.filter(row => {
        if (region && row.region !== region) return false;
        if (category && row.category !== category) return false;
        // String comparison is safe because dates are ISO (Step 2)
        if (startDate && row.date < startDate) return false;
        if (endDate && row.date > endDate) return false;
        return true;
    });

    this.renderKPIs();
    this.updateCharts();
    this.renderTable();
}
```

### Sortable Table

```javascript
function renderTable(containerId, data, columns) {
    const container = document.getElementById(containerId);
    let sortCol = null;
    let sortDir = 'desc';

    function render(rows) {
        let html = '<table class="data-table">';

        // Header
        html += '<thead><tr>';
        columns.forEach(col => {
            const arrow = sortCol === col.field
                ? (sortDir === 'asc' ? ' ▲' : ' ▼')
                : '';
            html += `<th data-field="${escapeHtml(col.field)}" style="cursor:pointer">${escapeHtml(col.label)}${arrow}</th>`;
        });
        html += '</tr></thead>';

        // Body — always escape cell values; pasted data can contain markup
        html += '<tbody>';
        if (rows.length === 0) {
            html += `<tr><td colspan="${columns.length}" class="table-empty">No rows match the current filters. Clear a filter to see data.</td></tr>`;
        }
        rows.forEach(row => {
            const cells = columns.map(col => {
                const value = col.format ? formatValue(row[col.field], col.format) : row[col.field];
                return `<td>${escapeHtml(value)}</td>`;
            });
            html += `<tr>${cells.join('')}</tr>`;
        });
        html += '</tbody></table>';

        container.innerHTML = html;
    }

    // Per-table sort handler scoped to this container — never a window
    // global, which a second table on the page would overwrite.
    // Assignment (not addEventListener) so re-calling renderTable on
    // filter change doesn't stack duplicate listeners.
    container.onclick = function(e) {
        const th = e.target.closest('th[data-field]');
        if (!th) return;
        const field = th.dataset.field;
        if (sortCol === field) {
            sortDir = sortDir === 'asc' ? 'desc' : 'asc';
        } else {
            sortCol = field;
            sortDir = 'desc';
        }
        const sorted = [...data].sort((a, b) => {
            const aVal = a[field], bVal = b[field];
            const cmp = aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
            return sortDir === 'asc' ? cmp : -cmp;
        });
        render(sorted);
    };

    render(data);
}
```


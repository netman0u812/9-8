# Chart.js Integration

Per-chart-type implementation for Step 5, and how to update charts when a filter changes.

## Chart.js Integration

### Chart Container Pattern

```html
<div class="chart-container">
    <h3 class="chart-title">Monthly Revenue Trend</h3>
    <canvas id="revenue-chart"></canvas>
</div>
```

### Line Chart

```javascript
function createLineChart(canvasId, labels, datasets) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: datasets.map((ds, i) => ({
                label: ds.label,
                data: ds.data,
                borderColor: COLORS[i % COLORS.length],
                backgroundColor: COLORS[i % COLORS.length] + '20',
                borderWidth: 2,
                fill: ds.fill || false,
                tension: 0.3,
                pointRadius: 3,
                pointHoverRadius: 6,
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'index',
                intersect: false,
            },
            plugins: {
                legend: {
                    position: 'top',
                    labels: { usePointStyle: true, padding: 20 }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ${formatValue(context.parsed.y, 'currency')}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: { display: false }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return formatValue(value, 'currency');
                        }
                    }
                }
            }
        }
    });
}
```

### Bar Chart

```javascript
function createBarChart(canvasId, labels, data, options = {}) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    const isHorizontal = options.horizontal || labels.length > 8;

    return new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: options.label || 'Value',
                data: data,
                backgroundColor: options.colors || COLORS.map(c => c + 'CC'),
                borderColor: options.colors || COLORS,
                borderWidth: 1,
                borderRadius: 4,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: isHorizontal ? 'y' : 'x',
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return formatValue(context.parsed[isHorizontal ? 'x' : 'y'], options.format || 'number');
                        }
                    }
                }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    grid: { display: isHorizontal },
                    ticks: isHorizontal ? {
                        callback: function(value) {
                            return formatValue(value, options.format || 'number');
                        }
                    } : {}
                },
                y: {
                    beginAtZero: !isHorizontal,
                    grid: { display: !isHorizontal },
                    ticks: !isHorizontal ? {
                        callback: function(value) {
                            return formatValue(value, options.format || 'number');
                        }
                    } : {}
                }
            }
        }
    });
}
```

### Doughnut Chart

```javascript
function createDoughnutChart(canvasId, labels, data) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    return new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: COLORS.map(c => c + 'CC'),
                borderColor: '#ffffff',
                borderWidth: 2,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '60%',
            plugins: {
                legend: {
                    position: 'right',
                    labels: { usePointStyle: true, padding: 15 }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const pct = ((context.parsed / total) * 100).toFixed(1);
                            return `${context.label}: ${formatValue(context.parsed, 'number')} (${pct}%)`;
                        }
                    }
                }
            }
        }
    });
}
```

### Gauge Chart (KPI vs. Threshold)

Chart.js has no native gauge type — build one from a half-doughnut plus a center label. Use this for a single status metric (uptime, capacity, score), not for trends.

```html
<div class="chart-container">
    <h3 class="chart-title">System Health</h3>
    <canvas id="health-gauge"></canvas>
</div>
```

```javascript
function createGaugeChart(canvasId, value, max, thresholds = { warning: 70, critical: 40 }) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    const clamped = Math.max(0, Math.min(value, max));
    const color = value < thresholds.critical ? '#dc3545'
        : value < thresholds.warning ? '#ffc107'
        : '#28a745';

    const chart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            datasets: [{
                data: [clamped, max - clamped],
                backgroundColor: [color, '#e9ecef'],
                borderWidth: 0,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            circumference: 180,
            rotation: 270,
            cutout: '75%',
            plugins: { legend: { display: false }, tooltip: { enabled: false } }
        },
        plugins: [{
            // Draw the numeric value in the center of the arc
            id: 'gaugeLabel',
            afterDraw(chart) {
                const { ctx, chartArea: { width, height } } = chart;
                ctx.save();
                ctx.font = 'bold 28px -apple-system, sans-serif';
                ctx.fillStyle = color;
                ctx.textAlign = 'center';
                ctx.fillText(`${value}${max === 100 ? '%' : ''}`, width / 2, height - 10);
                ctx.restore();
            }
        }]
    });
    return chart;
}
```

### Heatmap (Correlation / Density)

Do **not** use the `chartjs-chart-matrix` plugin — it isn't hosted on cdnjs, so it violates the CDN rules above and blanks the artifact preview. Build the heatmap as a dependency-free CSS grid instead. It's self-contained, prints cleanly, and shows exact values without needing tooltips:

```html
<div class="chart-container">
    <h3 class="chart-title">Tickets by Day and Hour</h3>
    <div id="volume-heatmap" class="heatmap"></div>
</div>
```

```css
.heatmap {
    display: grid;
    gap: 2px;
    font-size: 11px;
}
.heatmap .hm-cell {
    padding: 6px 4px;
    text-align: center;
    border-radius: 3px;
    color: var(--text-primary);
}
.heatmap .hm-label {
    padding: 6px 4px;
    color: var(--text-secondary);
    white-space: nowrap;
}
```

```javascript
// data: array of { x: <col category>, y: <row category>, v: <value> }
function createHeatmap(containerId, data, xLabels, yLabels) {
    const el = document.getElementById(containerId);
    const maxVal = Math.max(...data.map(d => d.v), 1);
    const lookup = {};
    data.forEach(d => { lookup[`${d.y}|${d.x}`] = d.v; });

    el.style.gridTemplateColumns = `auto repeat(${xLabels.length}, 1fr)`;

    let html = '<div class="hm-label"></div>';
    xLabels.forEach(x => {
        html += `<div class="hm-label" style="text-align:center">${escapeHtml(x)}</div>`;
    });
    yLabels.forEach(y => {
        html += `<div class="hm-label" style="text-align:right">${escapeHtml(y)}</div>`;
        xLabels.forEach(x => {
            const v = lookup[`${y}|${x}`] || 0;
            const alpha = v === 0 ? 0.04 : 0.15 + 0.75 * (v / maxVal);
            // Single-hue sequential scale (light → dark) per the color
            // principles; swap the RGB triplet to match --color-1
            html += `<div class="hm-cell" style="background:rgba(76,114,176,${alpha.toFixed(2)})" title="${escapeHtml(y)} / ${escapeHtml(x)}: ${v}">${v || ''}</div>`;
        });
    });
    el.innerHTML = html;
}
```

### Updating Charts on Filter Change

```javascript
function updateChart(chart, newLabels, newData) {
    chart.data.labels = newLabels;

    if (Array.isArray(newData[0])) {
        // Multiple datasets
        newData.forEach((data, i) => {
            chart.data.datasets[i].data = data;
        });
    } else {
        chart.data.datasets[0].data = newData;
    }

    chart.update('none'); // 'none' disables animation for instant update
}
```


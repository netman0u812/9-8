---
name: build-dashboard
description: Build an interactive HTML dashboard with charts, filters, and tables. Use when creating an executive overview with KPI cards, turning query results into a shareable self-contained report, building a team monitoring snapshot, or needing multiple charts with filters in one browser-openable file.
---

# Build a Dashboard

Build a self-contained interactive HTML dashboard with charts, filters, tables, and professional styling. Opens directly in a browser — no server or dependencies required.

> **Output contract:** This skill produces a **self-contained HTML artifact** — a single file with all data embedded as JSON, all styles inline, and Chart.js loaded via CDN. No BI tool, no Python, no server. The user downloads or saves the artifact and opens it in any browser. This is the delivery mechanism; do not reference alternative output formats.

## Workflow

### 1. Understand the Dashboard Requirements

Determine:

- **Purpose**: Executive overview, operational monitoring, deep-dive analysis, team reporting
- **Audience**: Who will use this dashboard?
- **Key metrics**: What numbers matter most?
- **Dimensions**: What should users be able to filter or slice by?
- **Data source**: Live query, pasted data, CSV file, or sample data

### 2. Gather the Data

**If data is pasted or uploaded:**
1. Parse and clean the data
2. Normalize every date field to an ISO `YYYY-MM-DD` string during parsing — users paste `MM/DD/YYYY` and other formats constantly, and all filter/sort logic in this skill compares dates as strings, which is only correct for ISO
3. Embed as JSON in the HTML artifact

**If working from a description without data:**
1. Create a realistic sample dataset matching the described schema
2. Label the dashboard clearly as using sample data
3. Include a comment in the HTML showing where to swap in real data

No data warehouse connector is available. If the user wants to use live query results, ask them to run the query in their SQL tool, then paste or upload the output (CSV, JSON, or copied table).

### 3. Design the Dashboard Layout

Don't default to the same layout every time — pick one based on what Step 1 established (purpose and data shape). Two dashboards for different purposes should not look structurally identical.

| Layout | Use when |
|---|---|
| **A — KPI band + charts** | Executive summary or general reporting, with a healthy mix of trend, category, and detail data. The default. |
| **B — Sidebar filters + one dominant chart** | Live or near-live monitoring, one metric dominates (e.g. volume over time), and users keep the same filters open while scanning — a persistent sidebar beats a header dropdown. |
| **C — KPIs merged into chart headers** | Deep-dive analysis with no clean set of 2-4 headline numbers; each chart carries its own supporting number instead. |

Wireframes for all three: `references/layouts.md`.


**Within whichever layout you pick, still adapt to content:**
- 2-4 KPI cards for headline numbers (fewer or none if Layout C fits better)
- 1-3 charts for trends and breakdowns
- Optional detail table at the bottom for drill-down data
- Filters in the header or sidebar depending on how often users will re-filter

### 4. Build the HTML Dashboard

Generate a single self-contained HTML file using the base template in `references/base-template.md`. The file includes:

**Structure (HTML):**
- Semantic HTML5 layout
- Responsive grid using CSS Grid or Flexbox
- Filter controls (dropdowns, date pickers, toggles)
- KPI cards with values and labels
- Chart containers
- Data table with sortable headers

**Styling (CSS):**
- Professional color scheme (clean whites, grays, with accent colors for data)
- Card-based layout with subtle shadows
- Consistent typography (system fonts for fast loading)
- Responsive design that works on different screen sizes
- Print-friendly styles

**Interactivity (JavaScript):**
- Chart.js for interactive charts (included via CDN)
- Filter dropdowns that update all charts and tables simultaneously
- Sortable table columns
- Hover tooltips on charts
- Number formatting (commas, currency, percentages)

**Data (embedded JSON):**
- All data embedded directly in the HTML as JavaScript variables
- No external data fetches required
- Dashboard works completely offline

### 5. Choose Chart Types

Pick chart type by the relationship in the data, not by habit:

| What You're Showing | Chart Type | Notes |
|---|---|---|
| Trend over time | Line chart | Default for any time series |
| Comparison across categories | Bar chart | Horizontal if >8 categories or labels are long |
| Ranking | Horizontal bar chart | Sort by value, not alphabetically |
| Part-to-whole composition | Doughnut chart | Only if <6 categories — otherwise use a bar chart |
| Composition over time | Stacked bar chart | Caps at ~5 series before it's unreadable |
| Volume with a rate overlay | Mixed (bar + line) | e.g. order count (bar) + conversion rate (line) |
| Single KPI vs. a threshold | Gauge chart | Use for status/health, not for trends |
| Correlation / density across two dimensions | Heatmap | Dependency-free CSS grid, not a Chart.js chart — see below |

**Avoid:**
- Pie charts (angle comparison is hard to read — use a bar chart instead)
- Dual-axis line charts unless both axes are clearly labeled (they can imply false correlation)
- More than 6-8 colors in one legend

Use the Chart.js integration patterns in `references/charts.md` for each chart type.

### 6. Add Interactivity

Use the filter and interactivity implementation patterns in `references/interactivity.md` for dropdown filters, date range filters, combined filter logic, sortable tables, and chart updates.

### 7. Before Delivering — Anti-Sameness Checklist

Run through this before emitting the artifact. The goal is a dashboard that looks like it was made for this data, not like the template was filled in on autopilot:

- [ ] **Layout chosen deliberately**: picked A, B, or C (or a justified variation) based on purpose/data shape from Step 1 — not defaulted to A because it's listed first
- [ ] **Palette chosen deliberately**: picked a variant (or brand color) based on audience from Step 1 — not defaulted to Variant 1 because it's listed first
- [ ] **Titles state the insight, not the metric**: "Revenue up 23% in Q3" beats "Revenue by Quarter"; the dashboard title itself names the actual subject, not a generic placeholder like "Dashboard Title"
- [ ] **No em-dashes in visible copy** (titles, labels, KPI text) — a common LLM tell, use a period or comma instead
- [ ] **KPI count and chart count match the content** — not padded to a round number of cards if the data only supports 2 real headline metrics
- [ ] **No leftover placeholder text** — every label, filter option, and column header reflects the actual data, not `category`, `value`, `Item 1`
- [ ] **Failures are visible**: the Chart.js load guard from `references/base-template.md` is present, and an empty filter result shows a message in the table instead of a blank body

### 8. Deliver the HTML Artifact

Emit the complete dashboard as a single HTML artifact. The user saves it locally (e.g., `sales_dashboard.html`) and opens it in any browser — no server required. Include a comment at the top of the `<script>` block showing how to replace the embedded sample data with real data.

---
## Examples

Requests this skill handles:

- "Monthly sales dashboard with revenue trend, top products, and regional breakdown — data's in the orders table."
- "Here's our support ticket data [pastes CSV]. Build a dashboard showing volume by priority, response time trends, and resolution rates."
- "Create a template executive dashboard for a SaaS company showing MRR, churn, new customers, and NPS. Use sample data."

## Tips

- Remind the user the file is fully self-contained -- they can share it with anyone by sending the file, no setup needed
- If the user needs live or auto-refreshing data, say so plainly: these dashboards are point-in-time snapshots, and a BI tool is the right home for real-time views
- Offer a dark or presentation-mode variant when the dashboard will be projected or screen-shared
- If the user names a brand or brand color, apply the brand-color rule in `references/styling.md` instead of a stock variant
- The pinned CDN versions (Chart.js 4.5.0, date-fns adapter 3.0.0) were verified on cdnjs at bundle time. If dashboards start rendering the "charts couldn't load" fallback on machines with working internet, re-verify the pinned URLs — that's a skill-maintenance issue, not a user issue.

## References

- `references/layouts.md` — wireframes for Layouts A, B, and C
- `references/base-template.md` — the self-contained HTML scaffold and KPI card pattern
- `references/charts.md` — Chart.js setup per chart type, and updating charts on filter change
- `references/interactivity.md` — dropdown and date filters, combined filter logic, sortable tables
- `references/styling.md` — colour system, accessibility, layout, cards, tables, responsive design
- `references/performance.md` — data size limits, pre-aggregation, chart and DOM performance

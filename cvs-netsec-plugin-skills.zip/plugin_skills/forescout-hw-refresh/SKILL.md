---
name: forescout-hw-refresh
description: Use for the Forescout NAC hardware refresh and integration project — decommissioning 12 legacy appliances, deploying 6 new consolidated ones, and its integration workstreams (Jamf/Intune, Tanium/Qualys/CrowdStrike, Ping SAML MFA, NiFi/Splunk logging, RADIUS MAB template, Palo Alto egress FW, DHCP/switching, and RAPD rogue-AP detection via Forescout + Cisco Catalyst Center). Trigger on "Forescout refresh," "12 appliances," "6 new appliances," "MAB template," "NiFi," "Ping SAML," "RAPD," "rogue AP," "Catalyst Center," or requests to update/extend/status-check this project plan. Distinct from the broader Phase 1A/1B/1C work in nac-ztna-fpms and the RAPD compliance/current-state assessment in ids-ips-policy-rebuild (this skill owns RAPD delivery scheduling; that one owns the Armis findings). Consult both, plus cvs-netsec-context, for shared background.
---

# Forescout NAC Hardware Refresh & Integration Project

## What this project is

A hardware consolidation + integration effort for the Forescout NAC platform, distinct from (though related to) the broader NAC/ZTNA Phase 1A/1B/1C source-of-truth program tracked in `nac-ztna-fpms`. Confirmed scope, supersedes any older appliance-count figures:

- **Decommission** the 12 existing Forescout appliances
- **Deploy** 6 new appliances (consolidated footprint)
- **Integrate** Jamf + Intune as authoritative asset management sources
- **Integrate** Tanium, Qualys, CrowdStrike for security posture validation
- **Implement** MFA for Forescout administrative access via SAML (Ping Identity — PingFederate/PingOne)
- **Implement** NiFi ingestion → Splunk logging/telemetry pipeline
- **Build** a standardized RADIUS MAB (MAC Authentication Bypass) configuration template for non-802.1X-capable devices
- **Integrate** with Palo Alto egress firewalls so Internet egress enforcement is keyed off live Forescout posture/identity state
- **Integrate** DHCP forwarding with switching infrastructure for endpoint visibility/fingerprinting
- **Enable** RAPD (Rogue Access Point Detection) via Forescout physical switch-layer MAC/port visibility, paired with Cisco Catalyst Center RF-layer detection (Rogue Management/aWIPS) — detection and SOC alerting only, per the Aug 7, 2026 RAPD assessment draft

Out of scope: RADIUS 802.1X (non-MAB) policy redesign, Claroty/IoT-OT posture work, CCD EDL/source-of-truth catalog changes — those stay under `nac-ztna-fpms`. **Automated rogue containment** (wireless deauth, wired port shutdown) is explicitly deferred to a later phase of the broader NAC/ZTNA program — not scheduled in this project's Sep 1–Feb 15 window. Legal/operational review is required before wireless deauth is pursued in any jurisdiction.

## RAPD context (why this is in scope here, not just in ids-ips-policy-rebuild)

The Aug 7, 2026 RAPD assessment (see `ids-ips-policy-rebuild` for the full current-state/Armis findings) identified two gaps in the current Armis-based approach: a static (not dynamically maintained) authorized-AP source of truth, and unconfirmed physical switch-layer correlation. Section 4.1 of that assessment proposes closing both using infrastructure already being touched by this project:

- **Cisco Catalyst Center** (RF layer) — over-the-air scanning and native rogue classification, sourced from a dynamically discovered WLC/9800 inventory. Its own wired correlation ("Rogue on Wire") only works for Catalyst-Center-managed switches — a blind spot for non-Cisco and retail-store infrastructure.
- **Forescout** (physical switch layer) — port-level MAC visibility independent of switch vendor, closing that blind spot. This is the same Forescout capability already being deployed/validated in Phases 1 and 8 of this project, which is why RAPD enablement piggybacks on this project rather than standing alone.

A confirmed rogue requires correlating both layers — a BSSID heard over the air is a candidate until traced onto (or confirmed absent from) the wired network. This project's scope is limited to enabling that detection-and-alert model (replicating what Armis provides today, not improving on the remediation model); automated containment is a separate, later decision.

## Phase structure (13 phases, 0–12; RAPD-related work is a phase 0 subset plus new Phase 11)

The plan is phased, with several integration workstreams running in parallel against the hardware deployment phase rather than strictly sequential:

| Phase | Name | Notes |
|---|---|---|
| 0 | Discovery & Design | Covers all 8 integration areas up front — site placement/HA design, API/connector requirements, SAML design, NiFi/Splunk flow design, MAB device-class scoping, PA integration mechanism, DHCP forwarding requirements |
| 1 | New Hardware Deployment | 6 appliances racked/staged, running parallel to legacy 12, not yet enforcing |
| 2 | Asset Mgmt Integration (Jamf + Intune) | Overlaps Phase 1 |
| 3 | Posture Integration (Tanium/Qualys/CrowdStrike) | Overlaps Phase 1 |
| 4 | MFA Admin Access (SAML/Ping) | Can run independently of hardware timeline |
| 5 | Logging & Telemetry (NiFi + Splunk) | Overlaps Phase 1 |
| 6 | RADIUS MAB Configuration Template | Overlaps Phase 1 |
| 7 | Palo Alto Egress FW Integration | Depends on Phase 0 design decision on context-sharing mechanism (User-ID vs. Dynamic Address Group/tag vs. EDL) |
| 8 | DHCP Forwarding Integration w/ Switching | Overlaps Phase 1; requires switching team maintenance windows |
| 11 | RAPD Detection Enablement | Depends on Phase 1 (hardware live), Phase 8 (switch-layer visibility), and Phase 5 (logging pipeline for SOC alerting); requires Armis architecture review and Catalyst Center licensing confirmation from Phase 0 |
| 9 | Cutover | Site-by-site; folds in MAB, egress enforcement, DHCP, and logging cutover alongside the appliance migration itself |
| 10 | Decommission | Legacy 12 appliances removed only after full stability window post-cutover |
| 12 | *(Future, out of window)* Automated Rogue Containment | Wireless deauth / wired port shutdown — a later NAC/ZTNA program decision, not part of this project's schedule |

Full task-level detail (owners, dependencies, exit criteria per phase) lives in `references/full-project-plan.md` — read it when asked for task-level detail, a specific phase's task list, or when regenerating the plan with real dates.

## Key design/sequencing principles established

- **No legacy appliance is decommissioned until all integrated systems are confirmed stable post-cutover** — RADIUS (802.1X + MAB), egress enforcement, DHCP integration, and logging all have to be live and validated per site before Phase 10 starts.
- **MFA/Ping work (Phase 4) is not on the hardware-deployment critical path** — it can be designed and tested independently.
- **The Forescout→Palo Alto context-sharing mechanism is a design decision, not assumed** — options are User-ID, Dynamic Address Group/tag push, or EDL. This is an open item until Phase 0/7 design is finalized with the PA/firewall team.
- **Cross-functional dependencies exist starting Phase 0**: Splunk/NiFi platform team, Palo Alto/firewall team, Switching team, Ping/IAM team. Don't scope timelines assuming these are internal-team-only tasks.

## Standing risks to carry forward in any update

- 12→6 consolidation may undersize capacity at high-density sites — validate before hardware order is finalized, not after.
- NiFi/Splunk pipeline lag or data loss under high enforcement-event volume — keep legacy logging path live until new pipeline is load-tested.
- Palo Alto tag/group propagation delay creates a window where posture state and egress enforcement are out of sync — needs an explicit acceptable-latency threshold agreed with the PA team.
- DHCP forwarding changes can cause site-wide connectivity outages if not staged in maintenance windows with rollback plans.
- Cisco Catalyst Center's own wired correlation ("Rogue on Wire") only works for Catalyst-Center-managed switches — the reason Forescout's vendor-independent port-level visibility is load-bearing for RAPD, not optional.
- RAPD is described here as an *alternative worth exploring*, not a locked decision — the Armis architecture review and GRC confirmation of the PCI DSS 11.2 mapping (both Phase 0 tasks) must close before this is treated as final in any leadership-facing plan.

## Open items (revisit when regenerating or updating the plan)

- Site placement/HA design for the 6 consolidated appliances (1:1 site mapping vs. centralized)
- Procurement lead time for new hardware (drives Phase 1 start)
- Ping environment: PingFederate on-prem vs. PingOne cloud
- Break-glass admin access policy owner (Security Engineering vs. IAM)
- Forescout→Palo Alto context-sharing mechanism
- Splunk index ownership/retention requirements
- Switch platform inventory and whether DHCP forwarding needs a broader network change window
- Final device-class list requiring RADIUS MAB
- Armis architecture review outcomes (detection mechanism, containment capability, licensed module name — see `ids-ips-policy-rebuild`) and what, if anything, transitions away from Armis
- Cisco Catalyst Center licensing (Rogue Management/aWIPS packages) and required WLC/9800 software versions across the estate
- GRC confirmation that PCI DSS v4.0 Requirement 11.2 continues to map to the Forescout + Catalyst Center model
- Whether the current retail-store control model (no dedicated RF sensor; Forescout NAC + 802.1X/DHCP snooping) remains acceptable under this approach

## When asked to regenerate this plan with real dates

Preserve the phase structure, ownership model, risks, and open items above — only recompute the calendar. Overlapping phases (2, 3, 5, 6, 8) should stay overlapping with Phase 1, not get stretched into a purely sequential chain. See `references/full-project-plan.md` for the full task tables to carry forward unchanged, and follow `leadership-doc-drafting` conventions if the output is meant for a leadership audience rather than execution/practitioner use.

# Project Plan: Forescout NAC Hardware Refresh & Integration
**CVS Health — Network Security Engineering**
**Project Window: September 1, 2026 – February 15, 2027 (24 weeks)**

*Includes RAPD (Rogue Access Point Detection) enablement, per the Aug 7, 2026 RAPD assessment draft — Forescout physical switch-layer visibility paired with Cisco Catalyst Center RF-layer detection, replicating today's Armis detect-and-alert model. Automated rogue containment is explicitly out of scope for this window; it is a later decision within the broader NAC/ZTNA program.*

---

## 1. Schedule at a Glance

| Phase | Workstream | Start | End |
|---|---|---|---|
| 0 | Discovery & Design | Tue, Sep 1, 2026 | Mon, Sep 28, 2026 |
| 1 | New Hardware Deployment (6 appliances) | Tue, Sep 29, 2026 | Mon, Nov 2, 2026 |
| 4 | MFA Admin Access (SAML/Ping) — independent track | Tue, Sep 29, 2026 | Mon, Nov 2, 2026 |
| 8 | DHCP Forwarding Integration w/ Switching | Tue, Oct 6, 2026 | Mon, Nov 9, 2026 |
| 2 | Asset Mgmt Integration (Jamf + Intune) | Tue, Oct 13, 2026 | Mon, Nov 16, 2026 |
| 3 | Posture Integration (Tanium/Qualys/CrowdStrike) | Tue, Oct 13, 2026 | Mon, Nov 16, 2026 |
| 6 | RADIUS MAB Configuration Template | Tue, Oct 13, 2026 | Mon, Nov 9, 2026 |
| 5 | Logging & Telemetry (NiFi + Splunk) | Tue, Oct 13, 2026 | Mon, Nov 23, 2026 |
| 7 | Palo Alto Egress FW Integration | Tue, Oct 27, 2026 | Mon, Dec 7, 2026 |
| 11 | RAPD Detection Enablement (Forescout + Catalyst Center) | Tue, Nov 10, 2026 | Mon, Dec 7, 2026 |
| — | **Change Freeze / Stabilization Window** | Tue, Nov 24, 2026 | Mon, Jan 4, 2027 |
| 9 | Cutover (all sites) | Tue, Jan 5, 2027 | Mon, Jan 25, 2027 |
| 10 | Decommission (12 legacy appliances) | Tue, Jan 26, 2027 | Mon, Feb 15, 2027 |

**Key assumption:** No production cutover, MAB enforcement change, egress policy change, or appliance removal occurs between **Nov 24, 2026 and Jan 4, 2027** — this spans Thanksgiving, peak retail/pharmacy season, and the December holidays, when most enterprises (CVS included) run a change freeze. This window is repurposed as an extended validation/parity-testing period using the work already completed in Phases 1–8, so no time is lost — cutover simply doesn't start production traffic during it.

---

## 2. Current State → Target State

| Dimension | Current State | Target State |
|---|---|---|
| Appliance count | 12 appliances | 6 appliances (consolidated) |
| Asset management sources | Not confirmed / legacy MDM feed | Jamf + Intune (authoritative) |
| Posture validation sources | Tanium, Qualys, CrowdStrike (existing) | Same three, re-validated post-migration |
| Admin access control | Standard local/AD credential login | SAML-based MFA via Ping (PingFederate/PingOne) |
| Logging/telemetry | Not centrally piped / ad hoc | NiFi ingestion pipeline → Splunk |
| Non-802.1X device auth | No standardized approach | Templated RADIUS MAB configuration |
| Egress enforcement | Not integrated with NAC posture | Palo Alto egress FW enforcing based on Forescout posture/identity |
| DHCP visibility | Not integrated with switching | DHCP forwarding integrated with switch infrastructure |
| Rogue AP detection (RAPD) | Armis, static authorized-AP list, RF-layer only (physical switch-layer correlation unconfirmed) | Forescout (physical switch-layer, vendor-independent) + Cisco Catalyst Center (RF-layer, dynamic WLC/9800-sourced inventory); detection/alerting only |

---

## 3. Phase Detail

### Phase 0 — Discovery & Design
**Sep 1 – Sep 28, 2026**

| Task | Owner | Target Week |
|---|---|---|
| Inventory and validate all 12 existing appliances (site, IP, policy bindings, RADIUS clients) | Team | Sep 1–7 |
| Confirm target site placement for 6 new appliances (consolidation ratio, HA design) | Michael + Team | Sep 1–14 |
| Define Jamf/Intune API integration requirements | Assigned engineer | Sep 8–14 |
| Define Tanium/Qualys/CrowdStrike re-integration requirements | Assigned engineer | Sep 8–14 |
| Design Ping SAML integration (metadata exchange, attribute mapping) | Assigned engineer | Sep 8–21 |
| Design NiFi ingestion flows and Splunk index/sourcetype strategy | Assigned engineer | Sep 15–21 |
| Define RADIUS MAB template requirements (device classes, fallback policy) | Assigned engineer | Sep 15–21 |
| Define Palo Alto egress FW integration mechanism (User-ID vs. tag/EDL) | Assigned engineer + PA team | Sep 15–28 |
| Define DHCP forwarding requirements per switch platform | Assigned engineer + Switching team | Sep 15–28 |
| Schedule an Armis technical architecture review to resolve open RAPD items (detection mechanism, containment capability, licensed module name) | Michael | Sep 1–14 |
| Confirm Cisco Catalyst Center licensing (Rogue Management / aWIPS packages) and required WLC/9800 software versions across the estate | Assigned engineer + Catalyst Center/wireless team | Sep 15–28 |
| Confirm with GRC that PCI DSS v4.0 Requirement 11.2 continues to map to a Forescout + Catalyst Center detection model | Michael + GRC | Sep 15–28 |
| Build cutover and rollback plan per site | Michael | Sep 22–28 |

**Exit criteria (Sep 28):** Design approved across all 8 integration areas; stakeholder engagements (Ping, Splunk/NiFi, PA, Switching) scheduled.

---

### Phase 1 — New Hardware Deployment
**Sep 29 – Nov 2, 2026**

| Task | Owner | Target Week |
|---|---|---|
| Procure/stage 6 new appliances | Michael | Sep 29–Oct 12 |
| Rack, cable, base-OS configuration at target sites | Team | Oct 6–19 |
| Apply baseline policy configuration (mirrored from production, pre-integration) | Team | Oct 13–19 |
| Establish HA/clustering between new appliances | Assigned engineer | Oct 20–26 |
| Validate network reachability (mgmt VLAN, SPAN ports, RADIUS listener) | Team | Oct 20–Nov 2 |

**Exit criteria (Nov 2):** All 6 appliances online and passing health checks, running in parallel with the 12 legacy units, not yet enforcing production policy.

---

### Phase 4 — MFA Administrative Access (SAML / Ping)
**Sep 29 – Nov 2, 2026** *(independent of hardware timeline)*

| Task | Owner | Target Week |
|---|---|---|
| Register Forescout admin console as SP in PingFederate/PingOne | Assigned engineer + Ping team | Sep 29–Oct 12 |
| Configure SAML assertion attributes (role, group, admin tier) | Assigned engineer | Oct 13–19 |
| Configure Forescout to accept SAML SSO, enforce MFA at IdP | Assigned engineer | Oct 20–26 |
| Test MFA login across admin roles | Team | Oct 27–Nov 2 |
| Define break-glass/local-admin fallback procedure | Michael | Oct 27–Nov 2 |

**Exit criteria (Nov 2):** All admin access requires SAML MFA; break-glass procedure documented and tested.

---

### Phase 8 — DHCP Forwarding Integration with Switching
**Oct 6 – Nov 9, 2026**

| Task | Owner | Target Week |
|---|---|---|
| Inventory switch platforms and current DHCP relay config per site | Switching team | Oct 6–12 |
| Define target DHCP forwarding config (IP helpers to new appliances, per VLAN) | Assigned engineer + Switching team | Oct 13–19 |
| Stage config changes per site (maintenance windows) | Switching team | Oct 20–Nov 2 |
| Validate Forescout visibility into DHCP lease/fingerprint data | Team | Oct 27–Nov 9 |
| Rollback/troubleshoot plan per site | Switching team + Michael | Nov 3–9 |

**Exit criteria (Nov 9):** All in-scope switches forwarding to new appliances; fingerprinting confirmed with no connectivity disruption.

---

### Phase 2 — Asset Management Integration (Jamf + Intune)
**Oct 13 – Nov 16, 2026**

| Task | Owner | Target Week |
|---|---|---|
| Establish API service accounts/app registrations in Jamf and Intune | Assigned engineer | Oct 13–19 |
| Configure Forescout connectors for Jamf/Intune ingestion | Assigned engineer | Oct 20–26 |
| Validate device attribute mapping into policy engine | Team | Oct 27–Nov 2 |
| Reconcile Jamf/Intune inventory against Forescout inventory | Team | Nov 3–9 |
| Resolve discrepancies (orphaned/duplicate/stale entries) | Team | Nov 10–16 |

**Exit criteria (Nov 16):** Jamf and Intune confirmed live and authoritative on the new stack, inventory reconciled.

---

### Phase 3 — Security Posture Integration (Tanium, Qualys, CrowdStrike)
**Oct 13 – Nov 16, 2026**

| Task | Owner | Target Week |
|---|---|---|
| Re-establish Tanium connector on new appliances | Assigned engineer | Oct 13–19 |
| Re-establish Qualys connector | Assigned engineer | Oct 20–26 |
| Re-establish CrowdStrike connector | Assigned engineer | Oct 20–26 |
| Validate posture data flow into policy decisions | Team | Oct 27–Nov 9 |
| Parity test vs. legacy stack outcomes | Team | Nov 10–16 |

**Exit criteria (Nov 16):** All three sources feeding the new stack with confirmed parity.

---

### Phase 6 — RADIUS MAB Configuration Template
**Oct 13 – Nov 9, 2026**

| Task | Owner | Target Week |
|---|---|---|
| Identify device classes requiring MAB | Team | Oct 13–19 |
| Build standardized MAB policy template | Assigned engineer | Oct 20–26 |
| Define exception/onboarding process for post-go-live additions | Michael | Oct 27–Nov 2 |
| Test MAB template against sample device classes per site | Team | Nov 3–9 |
| Document template for team/runbook use | Assigned engineer | Nov 3–9 |

**Exit criteria (Nov 9):** Tested MAB template ready for cutover; onboarding process documented.

---

### Phase 5 — Logging & Telemetry (NiFi + Splunk)
**Oct 13 – Nov 23, 2026**

| Task | Owner | Target Week |
|---|---|---|
| Stand up NiFi flow to receive Forescout syslog/API events | Assigned engineer | Oct 13–19 |
| Build NiFi processors (parsing, enrichment, routing) | Assigned engineer | Oct 20–Nov 2 |
| Configure Splunk index(es)/sourcetypes | Assigned engineer + Splunk team | Oct 27–Nov 2 |
| Validate end-to-end delivery with sample events | Team | Nov 3–9 |
| Build baseline dashboards/alerts | Assigned engineer | Nov 10–16 |
| Decommission legacy/ad hoc logging path | Team | Nov 17–23 |

**Exit criteria (Nov 23):** Reliable Forescout → NiFi → Splunk flow with working dashboards; no reliance on legacy path.

---

### Phase 7 — Palo Alto Egress Firewall Integration
**Oct 27 – Dec 7, 2026**

| Task | Owner | Target Week |
|---|---|---|
| Confirm context-sharing mechanism (User-ID / DAG-tag / EDL) | Assigned engineer + PA team | Oct 27–Nov 2 |
| Configure Forescout to publish posture-based tags on state change | Assigned engineer | Nov 3–9 |
| Configure PA egress policy keyed to Forescout tags | PA/firewall team | Nov 10–16 |
| Validate enforcement — non-compliant/quarantined restriction | Team | Nov 17–23 |
| Validate enforcement — compliant endpoints retain access | Team | Nov 17–23 |
| Load/scale test tag propagation latency | Assigned engineer | Nov 24–Dec 7 *(validation only — freeze window, see below)* |

**Exit criteria (Dec 7):** PA egress enforcement validated for both scenarios; propagation latency within agreed threshold.

---

### Phase 11 — RAPD Detection Enablement (Forescout + Cisco Catalyst Center)
**Nov 10 – Dec 7, 2026**

Closes the two gaps identified in the Aug 7, 2026 RAPD assessment against the current Armis approach: a static (not dynamically maintained) authorized-AP source of truth, and unconfirmed physical switch-layer correlation. Scope is limited to replicating Armis's current detect-and-alert model on better infrastructure — not introducing automated containment.

| Task | Owner | Target Week |
|---|---|---|
| Confirm Forescout physical switch-layer (port-level MAC) visibility extends to a DHCP lease-data integration and covers retail-store infrastructure outside Catalyst-Center-managed switches | Assigned engineer + Switching team | Nov 10–16 |
| Establish the mechanism correlating Forescout switch-port MAC visibility with Cisco Catalyst Center's RF-layer rogue candidates (Rogue on Wire, Honeypot, Interferer, Neighbor classifications) | Assigned engineer + Catalyst Center/wireless team | Nov 17–23 |
| Route RAPD detection events through the NiFi/Splunk pipeline (Phase 5) so SOC alerts carry MAC, BSSID, location, timestamp, and classification | Assigned engineer | Nov 17–23 |
| Validate the detect-notify-investigate-remediate workflow end-to-end against a test rogue scenario | Team | Nov 24–Dec 7 *(validation only — freeze window, see below)* |
| Document the Armis-to-Forescout/Catalyst-Center transition state and confirm with GRC that it continues to satisfy PCI DSS v4.0 Requirement 11.2 / 12.10.1 | Michael + GRC | Nov 24–Dec 7 |

**Dependencies:** Phase 1 (new appliances live), Phase 8 (DHCP/switch-layer visibility established), Phase 5 (logging pipeline available for SOC alerting), and the Phase 0 Armis architecture review / Catalyst Center licensing confirmation below.

**Exit criteria (Dec 7):** Forescout and Catalyst Center jointly providing RF + physical switch-layer rogue detection with SOC alerting via the new logging pipeline, validated against a test scenario; GRC has confirmed the model satisfies the existing PCI DSS mapping. Automated containment (wireless deauth, wired port shutdown) remains explicitly out of scope — tracked as a future decision within the broader NAC/ZTNA program, contingent on legal/operational review of wireless deauthentication.

---

### Change Freeze / Stabilization Window
**Nov 24, 2026 – Jan 4, 2027**

No production cutover, appliance removal, or live enforcement changes during this window (Thanksgiving through New Year, CVS peak season). Time is used for:
- Continued parity/load testing from Phases 5 and 7 in non-production or shadow mode
- Documentation, runbook finalization, and cutover rehearsal/dry-runs
- Resolving any open items surfaced in Phases 0–8 before go-live

---

### Phase 9 — Cutover
**Jan 5 – Jan 25, 2027**

| Task | Owner | Target Week |
|---|---|---|
| Site-by-site cutover from 12-appliance to 6-appliance footprint | Team | Jan 5–11 |
| Migrate live RADIUS enforcement (802.1X + MAB) to new appliances | Team | Jan 5–11 |
| Cut over DHCP forwarding, egress FW enforcement, logging pipeline per site | Team | Jan 12–18 |
| Monitor for enforcement gaps during parallel-run window | Team | Jan 5–25 |
| Confirm no authentication/posture/egress regressions per site | Team | Jan 19–25 |

**Exit criteria (Jan 25):** All sites on the new 6-appliance stack with MAB, egress enforcement, DHCP integration, and logging live; legacy appliances in standby.

---

### Phase 10 — Decommission
**Jan 26 – Feb 15, 2027**

| Task | Owner | Target Week |
|---|---|---|
| Confirm no active dependencies remain on the 12 legacy appliances | Michael | Jan 26–Feb 1 |
| Remove legacy appliances from Panorama/management, network, monitoring | Team | Feb 2–8 |
| Physical decommission (power down, de-rack, asset disposition) | Team | Feb 9–15 |
| Update CMDB/inventory records to reflect final 6-appliance state | Assigned engineer | Feb 9–15 |

**Exit criteria (Feb 15):** 12 legacy appliances fully decommissioned; inventory updated; project closed.

---

## 4. Risks & Mitigations

| Risk | Impact | Mitigation |
|---|---|---|
| 12→6 consolidation undersizes capacity at high-density sites | Enforcement gaps, performance degradation | Validate throughput/session capacity in Phase 0 before hardware order is finalized |
| Jamf/Intune data mapping mismatches with Forescout policy logic | False posture decisions, access denials | Reconciliation and parity testing before cutover |
| Ping SAML misconfiguration locks out admin access | Loss of NAC management during cutover | Break-glass fallback tested before Phase 9 |
| Posture connector re-establishment introduces stale/duplicate data | Incorrect enforcement decisions | Parity test against legacy outcomes before go-live |
| NiFi/Splunk pipeline lag under high event volume | Blind spots in enforcement visibility | Load-test in Phase 5; keep legacy logging live until validated |
| MAB template misclassifies a device | Security exposure or endpoint outage | Test against representative samples per site; documented exception path |
| PA tag/group propagation delay | Temporary over-/under-enforcement at egress | Load/scale test in Phase 7; agree acceptable latency threshold with PA team |
| DHCP forwarding change disrupts endpoint connectivity | Site-wide outage | Stage in maintenance windows; per-site rollback plan |
| Change freeze compresses effective working time to ~19 of 24 weeks | Schedule pressure if any phase slips into Nov 24–Jan 4 | Phases 0–8 sequenced to complete by Dec 7, leaving the freeze window as buffer, not critical path |
| Site cutover sequencing gap across multiple integrated systems | Temporary loss of enforcement/visibility | Parallel-run window per site; no legacy appliance removed until all systems confirmed stable |
| Cisco Catalyst Center's own wired correlation ("Rogue on Wire") only works for Catalyst-Center-managed switches | Blind spot for non-Cisco and retail-store infrastructure | Forescout's vendor-independent port-level visibility (Phase 11) is the compensating control, not an optional add-on |
| RAPD alternative not yet validated with Armis or GRC before adoption | Risk of building against an unconfirmed compliance mapping or an incomplete understanding of Armis's current capability | Phase 0 Armis architecture review and GRC confirmation must close before Phase 11 is treated as a final decision rather than an alternative being explored |

---

## 5. Team & Ownership

- **Michael J. Martin** — Program owner, cutover/decommission sign-off, cross-team engagement lead
- **Art, Joe, John** — Task execution across hardware, integration, and cutover workstreams (specific assignment TBD pending capacity review)
- **Cross-functional dependencies:** Splunk/NiFi platform team, Palo Alto/firewall team, Switching team, Ping/IAM team — engaged starting Phase 0

---

## 6. Open Items / Decisions Needed

- Confirm final site placement/HA design for the 6 new appliances
- Confirm procurement lead time for new hardware — currently assumed to fit within Sep 29–Oct 12 window; if longer, Phase 1 (and everything overlapping it) shifts right
- Confirm Ping environment (PingFederate on-prem vs. PingOne cloud)
- Confirm break-glass admin access policy owner (Security Engineering vs. IAM)
- Confirm Forescout → Palo Alto context-sharing mechanism
- Confirm Splunk index ownership/retention requirements
- Confirm switch platform inventory and whether DHCP forwarding needs a broader change window
- Confirm final device-class list requiring RADIUS MAB
- **Confirm whether the Nov 24–Jan 4 change freeze assumption is accurate for this environment** — if there's no freeze, cutover could move earlier and compress the overall timeline
- Resolve open Armis items via the technical architecture review (exact correlation mechanism, whether any automated containment exists today, correct licensed module name) before treating Armis transition as decided
- Confirm Cisco Catalyst Center licensing and WLC/9800 software versions across the estate
- Confirm GRC concurrence that the Forescout + Catalyst Center model satisfies PCI DSS v4.0 Requirement 11.2 / 12.10.1
- Confirm whether the current retail-store control model (no dedicated RF sensor; Forescout NAC + 802.1X/DHCP snooping) remains acceptable under this approach or needs revisiting

---

*This is a working execution plan (practitioner-level detail). Let me know if you need this reframed as a leadership/board-level summary with risk and investment framing instead.*

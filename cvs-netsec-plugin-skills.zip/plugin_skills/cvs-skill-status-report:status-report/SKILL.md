---
name: status-report
description: Generate a formal project status report — a structured document with KPI tables, green/yellow/red health, a rated risk register, and decisions needed. Use for standing weekly or monthly project-health reports that serve as a document of record. For a message tailored to a specific audience (executives, engineers, customers), use stakeholder-update instead.
---

# Status Report

Generate a polished status report for leadership or stakeholders.

Ask for whatever you're missing: the reporting period, the project or team, and the raw material (tracker activity, notes, a previous report). Then produce the report.

## Rating risks

Rate each risk on likelihood and impact, then read the level off this matrix:

| | Low Impact | Medium Impact | High Impact |
|---|-----------|---------------|-------------|
| **High Likelihood** | Medium | High | Critical |
| **Medium Likelihood** | Low | Medium | High |
| **Low Likelihood** | Low | Low | Medium |

Report each risk with its level, the mitigation in progress, and an owner. Lead with Critical and High; leave out anything neither controllable nor material.

## Output

Produce a markdown artifact using the structure below.

```markdown
## Status Report: [Project/Team] — [Period]
**Author:** [Name] | **Date:** [Date]

### Executive Summary
[3-4 sentence overview — what's on track, what needs attention, key wins]

### Overall Status: 🟢 On Track / 🟡 At Risk / 🔴 Off Track

### Key Metrics
| Metric | Target | Actual | Trend | Status |
|--------|--------|--------|-------|--------|
| [KPI] | [Target] | [Actual] | [up/down/flat] | 🟢/🟡/🔴 |

### Accomplishments This Period
- [Win 1]
- [Win 2]

### In Progress
| Item | Owner | Status | ETA | Notes |
|------|-------|--------|-----|-------|
| [Item] | [Person] | [Status] | [Date] | [Context] |

### Risks and Issues
| Risk/Issue | Impact | Mitigation | Owner |
|------------|--------|------------|-------|
| [Risk] | [Impact] | [What we're doing] | [Who] |

### Decisions Needed
| Decision | Context | Deadline | Recommended Action |
|----------|---------|----------|--------------------|
| [Decision] | [Why it matters] | [When] | [What I recommend] |

### Next Period Priorities
1. [Priority 1]
2. [Priority 2]
3. [Priority 3]
```

## Pulling Data from Connected Tools

Check your actual tool list and use whichever connected tool fills each role. Name the sources you pulled from; if none are connected, ask the user for the material.

- **Work tracker** (e.g., Jira, Asana, ServiceNow) — project status, completed items, upcoming milestones, and anything at-risk or overdue
- **Chat/messaging** (e.g., Slack, Teams) — recent team discussions for decisions and blockers worth including; when the report is done, offer to draft it as a channel message for the user to review and send
- **Calendar** (e.g., Outlook) — key meetings and decisions from the reporting period

## Tips

1. **Lead with the headline** — Busy leaders read the first 3 lines. Make them count.
2. **Be honest about risks** — Surfacing issues early builds trust. Surprises erode it.
3. **Make decisions easy** — For each decision needed, provide context and a recommendation.

## Related skills — route, don't duplicate

Stay silent about these unless the user's request crosses into their territory. When it does, name the skill and offer it:

- A message tailored to a specific audience rather than a document of record → **stakeholder-update**
- A full standalone risk register, rated and owned → **risk-assessment**
- One decision that needs its own document with options and a recommendation → **decision-brief**
- If the user has no raw material to report from, the **digest** skill can gather the period's activity from connected sources first
- The same content as a CVS-branded slide deck rather than a written document → **cvs-deck** — hand it the finished report; it treats that as the outline rather than re-interviewing

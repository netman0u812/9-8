---
name: document-process
description: Document a business process — flowcharts, RACI, and SOPs. Use when formalizing a process that lives in someone's head, building a RACI to clarify who owns what, writing an SOP for a handoff or audit, or capturing the exceptions and edge cases of how work actually gets done.
---

# Document a Process

Document a business process as a complete standard operating procedure (SOP).

## How It Works

The user describes the process, pastes existing docs, or just names it. Ask the questions needed to fill the gaps, then produce a complete SOP as a markdown artifact.

## Output

```markdown
## Process Document: [Process Name]
**Owner:** [Person/Team] | **Last Updated:** [Date] | **Review Cadence:** [Quarterly/Annually]

### Purpose
[Why this process exists and what it accomplishes]

### Scope
[What's included and excluded]

### RACI Matrix
| Step | Responsible | Accountable | Consulted | Informed |
|------|------------|-------------|-----------|----------|
| [Step] | [Who does it] | [Who owns it] | [Who to ask] | [Who to tell] |

Every step has exactly one A — if two people are Accountable, the step needs splitting or the ownership is unresolved; say so.

### Process Flow
[Numbered step list — see the Process Flow note below; the Mermaid diagram ships as a separate artifact]

### Detailed Steps

#### Step 1: [Name]
- **Who**: [Role]
- **When**: [Trigger or timing]
- **How**: [Detailed instructions]
- **Output**: [What this step produces]

#### Step 2: [Name]
[Same format]

### Exceptions and Edge Cases
| Scenario | What to Do |
|----------|-----------|
| [Exception] | [How to handle it] |

### Metrics
| Metric | Target | How to Measure |
|--------|--------|----------------|
| [Metric] | [Target] | [Method] |

### Related Documents
- [Link to related process or policy]
```

## Pulling from and publishing to connected tools

- **Document storage/wiki** (e.g., SharePoint, Confluence): before writing, search for existing documentation of this process — update, don't duplicate. When done, deliver the SOP as a markdown artifact; if a connected tool supports creating or updating pages, offer to publish it there, and otherwise tell the user where to upload it.
- **Work tracker** (e.g., Jira, Asana): offer to link the process to related work or create tasks for the improvement items surfaced while documenting — only if the connected tool supports creating items.

Never state that publishing happened unless a tool call actually did it.

**Process Flow:** render as a Mermaid flowchart artifact (flowchart TD; decision points as diamonds, exception paths visible). Inside the markdown SOP document itself, include the same flow as a numbered step list so the doc stands alone when pasted elsewhere.

## Tips

1. **Start messy** — a perfect description isn't needed. Take how the process works today and structure it.
2. **Include the exceptions** — "Usually we do X, but sometimes Y" is the most valuable part to document.
3. **Name the people** — Even if roles change, knowing who does what today helps get the process right.

---
name: pci-soc-audit-tracker
description: Scan the mailbox for open PCI and SOC2 audit/compliance items (findings, remediation plans, AuditBoard tasks, weekly assessment status) and compile a current-state tracker.
---

## When to use
Trigger when the user asks to track, check status of, or summarize PCI audit items, SOC2 audit items, Aetna PCI Assessment findings, AuditBoard SOC tasks, or "audit requests" generally. Also trigger on `/pci-soc-audit-tracker`.

## Scope
This tracks the recurring CVS/Aetna PCI Controls Assurance weekly assessment (Curtis Noel's team) and the SOC2 report cycle run through AuditBoard (Robert Bristow / Javier Landin), plus adjacent audit-machinery threads (Archer findings, ServiceNow change aging, HITRUST) that feed the same evidence. It does not cover general IT compliance training or unrelated ServiceNow tickets.

## Steps

1. **Search for PCI items.** Use `graph.get` with `$search` against `/me/messages`, run these in parallel (`Promise.all`), each with `{maxPages: 1, $top: 25}`:
   - `"PCI Aetna Assessment"` — weekly status decks/agendas
   - `"SecEng Archer"` — weekly Archer findings summary (mentions open PCI/FTC worksheets)
   - `"Aetna Assessment - Requests and Findings"` — the live findings/RP table (this is the richest source; it's a running table with columns Document ID / Title / Due Date / Owner / Delegate/POC / Reference / Comments)
   Done when: you have the most recent (by `receivedDateTime`) message from each search.

2. **Search for SOC2 items.** Run in parallel:
   - `"SOC2"` and `"SOC 2"` — narrative/control language reviews, AuditBoard task assignments and comment threads (subjects look like `2026 - SOC - <date> <workstream> | ...`)
   - `"Remediation Plan"` — Archer remediation plan (RP-#####) due-date reminders, which often cross-reference PCI findings (RP numbers appear in both PCI finding tables and SOC2/Archer reminders — match them)
   Done when: you have the current AuditBoard task assignments/comments and any open RP reminders.

3. **Pull full bodies for anything that looks actionable or overdue.** For each candidate hit, fetch `$select=subject,body,from,receivedDateTime` and strip HTML tags (`.replace(/<[^>]+>/g,' ')`). Prioritize:
   - Any message with "PAST DUE", "Coming Due", "At Risk", "Stuck in Workflow" in the subject or body
   - The most recent "Aetna Assessment - Requests and Findings" email — parse its finding table rows (Document ID, Title, Due Date, Owner, Delegate/POC, Reference RP, Comments)
   - AuditBoard task-assignment emails where the assignee is the user (`Michael Martin`) — flag due-date status against today's date
   Done when: you can state, per item, an owner, a due date, and a one-line status in the sender's own words (cite it, don't paraphrase into something stronger than what was said).

4. **Cross-reference RP numbers.** SOC2 Archer remediation plan reminders (RP-#####) frequently correspond to a PCI finding (FND-#####) referenced in the Aetna Assessment findings table. When you see the same RP number in both a PCI finding row and a standalone remediation reminder, merge them into one line item rather than reporting twice.

5. **Flag items where the user is owner or delegate/POC.** Scan the Owner and Delegate/POC columns of the PCI findings table and the "assigned you as Preparer/Reviewer" language in AuditBoard emails for `Michael Martin` / `Martin, Michael J`. These go at the top of the summary as "items on you" — everything else is "team/estate-wide" for awareness only.

6. **Present the tracker in chat**, grouped as:
   - **PCI (2026 Aetna Assessment)** — one bullet per finding/RP: `**FND-##### – <title>** (RP-#####, due <date>): <status quote>`
   - **SOC2** — one bullet per AuditBoard task or narrative review, with due date and current state
   - **Adjacent** — HITRUST, Archer findings summary, ServiceNow change aging (only if genuinely tied to audit evidence)
   - **On you specifically** — called out first if any items have the user as owner/delegate/preparer, especially anything past due
   Use `<mail-cite>` tags on every item referencing a specific email so the user can click through. Do not use markdown tables (narrow task pane) — bullets with bold labels only.

7. **Do not silently assume status.** If a finding's last update is more than ~2 weeks stale relative to today's date, say so explicitly ("no update since 8/14 — worth a status check") rather than reporting the stale comment as current.

Done when: the user has a single chat message covering every open PCI/SOC2 line item you found, correctly bucketed, with citations, and nothing marked "on track" that is actually silent/stale.

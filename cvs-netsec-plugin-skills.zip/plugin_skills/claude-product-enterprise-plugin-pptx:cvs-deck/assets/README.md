# assets/ — Bundled Brand Assets

This directory holds versioned local snapshots of CVS brand assets. The skill reads from here at runtime — no SharePoint connector required on the common build path.

**SharePoint remains the source of truth** for the Everyday Template and icon library. These are annual snapshots. When the brand team publishes a refresh, pull from SharePoint, update these files, bump `ASSET_VINTAGE` in `SKILL.md`, and re-package.

---

## What goes where

```
assets/
├── manifest.json                          # Asset registry (source URIs, vintage, refresh procedure)
├── cvs_utils.py                           # Slide factory helpers — keep color constants in sync with SKILL.md / Style Guide
├── build_icon_index.py                    # Re-runnable indexer (python3 assets/build_icon_index.py)
├── strip_chart_embeddings.py               # Re-runnable — removes ppt/embeddings/*.xlsx + chart refs, see note below
├── sanitize_template_metadata.py          # Re-runnable metadata scrubber — see note below
├── icon-index.json                        # 1,228 icons mapped — regenerate with build_icon_index.py
├── templates/
│   └── everyday_2026.pptx                 # Everyday Template — 6 built-in covers, ~40 interior layouts, 6 closing layouts
├── libraries/
│   └── Iconography_Library_01_2026.pptx   # Full icon library (vector freeform shapes)
└── marks/
    ├── cvs_logo.png                       # Pre-extracted from Everyday Template footer
    ├── heart_solid_red_reg.png / _sm.png     # Hero heart — covers/closing on light backgrounds
    ├── heart_solid_white_reg.png / _sm.png   # Hero heart — covers/closing on dark/navy backgrounds
    ├── heart_outline_red_reg.png / _sm.png   # Accent heart — light backgrounds
    └── heart_outline_white_reg.png / _sm.png # Accent heart — dark backgrounds
```

There is no `icons/` subfolder — icons live only in `libraries/Iconography_Library_01_2026.pptx` and are copied as vector shapes at build time, not pre-extracted as PNGs.

---

## Populating this directory (first time / annual refresh)

### 1. Download the template and icon library from SharePoint
Use the `source_uri` values in `manifest.json`. The SharePoint folder is listed in `manifest.json → source_of_truth`.

### 2. Refresh the heart PNGs
`manifest.json` lists each heart file's `source_uri` as an extracted brand-asset archive (`CVS_Health_*_heart.zip`). An earlier version of this manifest sourced hearts from a `solid_heart.pdf` / `open heart.pdf` pair instead — that path predated the current 8-variant PNG set and has been retired (the doc describing it, `references/template-uri.md`, was removed for the same reason). **Confirm with CVS Brand Center that the zip archive is still the current source before doing an annual refresh.**

### 3. Extract the CVS logo from the Everyday Template

```python
from pptx import Presentation

prs = Presentation("assets/templates/everyday_2026.pptx")
# Find the image shape named "CVS Health logo" in the slide master or a Title Slide
# layout and save its image bytes as cvs_logo.png
for shape in prs.slide_masters[0].shapes:
    if shape.shape_type == 13 and "logo" in shape.name.lower():  # 13 = PICTURE
        with open("assets/marks/cvs_logo.png", "wb") as f:
            f.write(shape.image.blob)
        break
```

### 4. Regenerate the icon index

Run this from the skill root directory whenever the icon library PPTX is updated:

```bash
python3 assets/build_icon_index.py
```

This regenerates `assets/icon-index.json` automatically. No other steps needed for icons.

---

## Template chart-embedding & metadata hygiene (do this on every refresh)

`everyday_2026.pptx` originally bundled 8 embedded chart-data workbooks under
`ppt/embeddings/` (backing sheets for the native charts on slides 2, 38, 40,
41, 42, 43). A marketplace security sweep flags `ppt/embeddings/*.xlsx` on
sight — it's a path-based rule, not a genuine embedded-object finding (no
`p:oleObj`, `progId`, `vbaProject.bin`, ActiveX, or external/DDE connections
anywhere in the package — verified directly against the XML). Filing an
exception didn't clear the sweep, so **the embeddings are now removed
entirely** rather than sanitized in place.

This is safe: every chart's data is fully cached in its own `chart*.xml`
(`<c:numCache>`/`<c:strCache>`) — PowerPoint reads that to render, never the
embedded workbook. Nothing in this skill's build workflow depends on the
embedded workbook either (no `replace_data()` or similar call anywhere in
it), and even if that changes, python-pptx's `Chart.replace_data()` creates
a fresh embedded workbook on demand if none exists — so future automation
isn't foreclosed. The one real cost: opening a delivered deck in real
PowerPoint and clicking "Edit Data in Excel" on one of these charts has no
original spreadsheet to open (modern PowerPoint generates a fresh one seeded
from the cached values instead of erroring, but this isn't guaranteed across
every Office build).

The deck-level `docProps/core.xml`/`custom.xml` has a separate, related
problem: it carries a real employee's name and a stale MSIP Purview label
(`SiteId`/`ActionId`) into **every** generated deck, chart or not, since the
slide-strip pattern in `cvs_utils.py` only removes slides — it never touches
package-level docProps. That's fixed independently of the embeddings.

Run both after every SharePoint pull, before re-bundling, in this order:

```bash
python3 assets/strip_chart_embeddings.py assets/templates/everyday_2026.pptx
python3 assets/sanitize_template_metadata.py assets/templates/everyday_2026.pptx
python3 /mnt/skills/public/pptx/scripts/office/validate.py assets/templates/everyday_2026.pptx
```

`strip_chart_embeddings.py` removes each embedded workbook plus the matching
`<c:externalData>` element and chart relationship — a clean 1:1 mapping, no
dangling references. `sanitize_template_metadata.py` then only has the
deck-level docProps left to fix, since no embedded workbooks remain; it also
drops a pre-existing unreferenced `[trash]/` zip entry the template shipped
with (harmless but fails strict OOXML validation).

## When to refresh

CVS publishes brand asset updates annually. The `ASSET_VINTAGE` constant in `SKILL.md` will generate a non-blocking build-time warning when the calendar year exceeds the vintage year — that's your signal to pull a refresh.

The `manifest.json → annual_refresh_procedure` has the full step-by-step.

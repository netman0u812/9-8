"""
cvs_utils.py — CVS Health slide utility module  v2.1
=====================================================
Copy to your working directory and import:

    import sys; sys.path.insert(0, 'assets')
    from cvs_utils import *
    prs = open_template()

All helpers assume working directory contains the skill's assets/ folder.
"""

import copy, json
import lxml.etree as etree
from datetime import datetime
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN


# ─────────────────────────────────────────────────────────────────────────────
# Color constants
# ─────────────────────────────────────────────────────────────────────────────

CVS_RED         = RGBColor(0xCC, 0x00, 0x00)   # Primary CVS red
CVS_RED_DARK    = RGBColor(0xA3, 0x00, 0x00)   # Hover/depth states
CVS_RED_SOFT    = RGBColor(0xF7, 0x97, 0x8D)   # Red super titles on navy (contrast-safe)
CVS_NAVY        = RGBColor(0x0B, 0x31, 0x5E)   # Primary CVS navy (matches cvs-navy in Style Guide)
CVS_NAVY_DEEP   = RGBColor(0x08, 0x1F, 0x3F)   # Darker navy for depth/closing
CVS_BLUE        = RGBColor(0x0A, 0x4B, 0x8C)   # Secondary accent — numbered circles, chart color
CVS_WHITE       = RGBColor(0xFF, 0xFF, 0xFF)   # White
TEXT_DARK       = RGBColor(0x3F, 0x3F, 0x3F)   # Ink / primary text (cvs-text-gray — never pure black)
TEXT_GRAY       = RGBColor(0x64, 0x64, 0x64)   # Slate / secondary text (cvs-gray-medium)
TEXT_LIGHT      = RGBColor(0x86, 0x86, 0x86)   # Muted / footer text (cvs-gray-light)
SURF_WARM       = RGBColor(0xF5, 0xF1, 0xEC)   # Warm surface (light red-tinted bg) — canonical; if you
                                                # see 'FBF4F2' anywhere, that's drift — this is correct.
SURF_COOL       = RGBColor(0xF0, 0xF2, 0xF5)   # Cool surface (light blue-tinted bg)
SURF_NEUTRAL    = RGBColor(0xF7, 0xF7, 0xF7)   # Neutral card surface, alternating row fill
BORDER_SOFT     = RGBColor(0xD8, 0xD3, 0xC8)   # Soft border / divider — canonical; if you see 'E5E5E5'
                                                # anywhere, that's drift — this is correct.
BORDER          = RGBColor(0xC0, 0xC0, 0xC0)   # Standard (non-soft) border
ICE             = RGBColor(0xCA, 0xDC, 0xFC)   # Light blue text on navy
AMBER           = RGBColor(0xD8, 0x85, 0x00)   # Opportunity / caution / "needs attention"
AMBER_SOFT      = RGBColor(0xFC, 0xF1, 0xE5)   # Opportunity card surface
GREEN_DEEP      = RGBColor(0x0F, 0x6B, 0x45)   # Strong execution / positive outcome
GREEN_SOFT      = RGBColor(0xE8, 0xF4, 0xEE)   # Strong execution card surface

# Semantic colors (AMBER/GREEN pair, ICE) are earned by specific content patterns —
# see references/visual-vocabulary.md "Semantic Split" scheme. Never use them for
# primary brand moments; those stay CVS_RED/CVS_NAVY.

# Hex strings (for recolor_icon and add_picture alt-text)
CVS_RED_HEX     = 'CC0000'
CVS_NAVY_HEX    = '0B315E'
CVS_WHITE_HEX   = 'FFFFFF'

# Font
FONT = 'CVS Health Sans'


# ─────────────────────────────────────────────────────────────────────────────
# Template setup
# ─────────────────────────────────────────────────────────────────────────────

def open_template(path='assets/templates/everyday_2026.pptx'):
    """Open the CVS Everyday Template and strip any content slides present,
    preserving the slide master and its 42 named layouts.

    The bundled template ships pre-stripped (0 content slides), so this loop
    is normally a no-op — it only does real work against a freshly-pulled,
    unstripped copy of the template (e.g. during an annual refresh, before
    strip_example_slides_and_prompts.py runs).

    Returns a Presentation ready to receive new slides via add_slide().
    """
    from pptx.oxml.ns import qn
    prs = Presentation(path)
    sldIdLst = prs.slides._sldIdLst
    for sldId in list(sldIdLst):
        rId = sldId.get(qn('r:id'))
        prs.part.drop_rel(rId)
        sldIdLst.remove(sldId)
    return prs


def get_layout(prs, name):
    """Look up a slide layout by name. Raises ValueError with available names if not found."""
    try:
        return next(l for l in prs.slide_layouts if l.name == name)
    except StopIteration:
        available = [l.name for l in prs.slide_layouts]
        raise ValueError(f"Layout '{name}' not found. Available layouts:\n" +
                         '\n'.join(f"  '{n}'" for n in available))


def suppress_master(slide):
    """Set showMasterSp='0' on a slide to prevent all master shapes appearing.

    The master provides page number, confidentiality text, and CVS logo automatically.
    Only call this when you are intentionally overriding ALL footer elements manually.
    For standard content slides, never call this.
    """
    slide._element.set('showMasterSp', '0')


# ─────────────────────────────────────────────────────────────────────────────
# Slide factory helpers  (start here — don't call add_slide directly)
# ─────────────────────────────────────────────────────────────────────────────

def cover_slide(prs, title_text, presenter_text=''):
    """Create a cover slide using the Title Slide layout.

    The Title Slide layout already contains:
      - CVS Health logo (top-left area, y≈0.47")
      - Red outline heart (right side, y≈1.11")
      - showMasterSp=0 (no master footer — covers don't get page numbers)

    Do NOT call add_footer(), add_confidentiality_text(), or suppress_master()
    on this slide — the layout handles everything.

    Args:
        prs: Presentation from open_template()
        title_text: main presentation title
        presenter_text: presenter name / title / date (optional)

    Returns: slide object
    """
    slide = prs.slides.add_slide(get_layout(prs, 'Title Slide'))
    slide.placeholders[0].text = title_text
    if presenter_text:
        # Don't hardcode idx 1 — the Title Slide layout's presenter/subtitle
        # placeholder isn't guaranteed to sit at that index. Use the first
        # non-title placeholder instead.
        for ph in slide.placeholders:
            if ph.placeholder_format.idx != 0:
                ph.text = presenter_text
                break
    return slide


def content_slide(prs, layout_name='Title and Content'):
    """Create a standard content slide that inherits the master footer automatically.

    The slide master provides on every non-suppressed slide:
      - CVS Health logo      (bottom-right, y≈6.97")
      - Confidentiality text (bottom-left,  y≈7.03")
      - Page number field    (bottom-left,  y≈6.96")

    Do NOT call suppress_master(), add_footer(), or add_confidentiality_text()
    on slides created here — the master handles all footer elements for free.
    Just call add_title() and add your content, then call
    drop_unused_placeholders(slide) at the end — some named layouts (e.g.
    'Title and Content') carry a body placeholder this pattern never
    writes into, and it will otherwise sit on the slide empty.

    Args:
        prs: Presentation from open_template()
        layout_name: any of the 42 named layouts (default: 'Title and Content')
            See references/layout-quick-ref.md or QUICK_BUILD_REF.md for the list.

    Returns: slide object
    """
    return prs.slides.add_slide(get_layout(prs, layout_name))


def drop_unused_placeholders(slide):
    """Remove any real placeholder that was never written into.

    Call this once, at the end of building a slide — after add_title() and
    all content calls (rct()/tb()/copy_icon()/etc.). Several Everyday
    Template layouts (e.g. 'Title and Content') carry a body placeholder
    that content_slide() + add_title() alone never touches, leaving it
    present and empty: `slide.placeholders` shows `(1, '')`. That's not the
    placeholder-ghosting bug described in the Changelog — there's no leftover
    layout text bleeding through — but an empty placeholder still renders a "Click to add text"
    prompt in PowerPoint/LibreOffice/Google Slides, which is exactly the
    "looks wrong when someone opens the deck" symptom the QA checklist item
    exists to catch.

    Only placeholders with no text in any run are removed, so anything
    add_title() or your content calls already wrote into is left alone —
    safe to call unconditionally at the end of every slide build, before or
    after populating content. Removes the shape from the SLIDE only; the
    layout (and every other slide built from it) is untouched.

    Args:
        slide: python-pptx slide object

    Returns:
        int: number of placeholders removed (0 is the common case once a
             slide's placeholders are all written into).
    """
    removed = 0
    # Snapshot with list() first — removing shapes while iterating
    # slide.placeholders directly skips entries as the collection shrinks.
    for ph in list(slide.placeholders):
        if not ph.text_frame.text.strip():
            sp = ph._element
            sp.getparent().remove(sp)
            removed += 1
    return removed


def blank_slide(prs):
    """Create a fully custom slide: Blank layout with master suppressed.

    Use ONLY when no named layout fits the intended design. This suppresses
    the master footer — you must add logo, confidentiality text, and page
    number manually if they are needed on this slide.

    For most slides, use content_slide() — the master footer is free.

    Returns: slide object (no content or footer added)
    """
    slide = prs.slides.add_slide(get_layout(prs, 'Blank'))
    suppress_master(slide)
    return slide


# ─────────────────────────────────────────────────────────────────────────────
# Adaptive title sizing
# ─────────────────────────────────────────────────────────────────────────────

def title_tier(title_text):
    """Return (font_size_pt, title_box_h_inches, content_y_inches) based on title length.

    Tier 1: < 40 chars  → 32pt, h=0.90",  content_y=1.80"  (1 line)
    Tier 2: 40–65 chars → 26pt, h=1.30",  content_y=2.18"  (2 lines)
    Tier 3: 65–90 chars → 22pt, h=1.60",  content_y=2.55"  (3 lines)

    Always assign CONTENT_Y from this function's return value — never hardcode 1.6.
    """
    n = len(title_text.strip())
    if n < 40:
        return 32, 0.90, 1.80
    elif n <= 65:
        return 26, 1.30, 2.18
    else:
        return 22, 1.60, 2.55


# ─────────────────────────────────────────────────────────────────────────────
# Standard slide elements
# ─────────────────────────────────────────────────────────────────────────────

def add_title(slide, title_text, eyebrow=None):
    """Add a standard CVS title block with adaptive font sizing.

    Writes into the slide's real title placeholder (inherited from the layout)
    instead of drawing a separate floating textbox on top of it. Layouts in the
    Everyday Template carry literal example text baked into their title
    placeholder (e.g. "Agenda"), and a floating textbox never overwrites or
    removes that — it just sits on top of it. Editors (PowerPoint, LibreOffice,
    Google Slides) render the still-empty, still-present placeholder underneath
    whenever the slide is opened for editing, producing a ghost of the old
    layout text behind the real title. Writing into the real placeholder
    removes the leftover shape from the equation entirely — there's no separate
    empty shape left for an editor to paint a inherited default into.

    Falls back to a floating textbox only if the layout has no title
    placeholder at all (e.g. the Blank layout) — in that case there is no
    inherited shape to ghost, so the old approach is safe.

    Args:
        slide: python-pptx slide object
        title_text: slide title string (drives tier selection)
        eyebrow: optional super-title string (rendered red, uppercase, 11pt)

    Returns:
        content_y (float): the y-coordinate in inches where body content should start.
                           Always use this return value — never hardcode CONTENT_Y.
    """
    font_size, title_h, content_y = title_tier(title_text)

    if eyebrow:
        # No eyebrow placeholder exists on any layout, so this stays a floating
        # textbox — there's nothing underneath it to ghost.
        box = slide.shapes.add_textbox(Inches(0.5), Inches(0.38), Inches(12.2), Inches(0.35))
        tf = box.text_frame
        tf.word_wrap = False
        p = tf.paragraphs[0]
        p.text = eyebrow.upper()
        p.font.size = Pt(11)
        p.font.bold = True
        p.font.color.rgb = CVS_RED
        p.font.name = FONT

    try:
        title_ph = slide.placeholders[0]
    except KeyError:
        title_ph = None

    if title_ph is not None:
        # Reposition/resize to the standard title box so every slide looks the
        # same regardless of which layout's own title geometry it inherited.
        title_ph.left = Inches(0.5)
        title_ph.top = Inches(0.72)
        title_ph.width = Inches(12.2)
        title_ph.height = Inches(title_h)

        tf = title_ph.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.text = title_text
        p.font.size = Pt(font_size)
        p.font.bold = True
        p.font.color.rgb = TEXT_DARK
        p.font.name = FONT
    else:
        # No title placeholder on this layout (e.g. Blank) — nothing to ghost,
        # fall back to a plain textbox.
        box = slide.shapes.add_textbox(Inches(0.5), Inches(0.72), Inches(12.2), Inches(title_h))
        tf = box.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.text = title_text
        p.font.size = Pt(font_size)
        p.font.bold = True
        p.font.color.rgb = TEXT_DARK
        p.font.name = FONT

    return content_y


def add_footer(slide, page_num, logo_path='assets/marks/cvs_logo.png'):
    """Add footer elements manually. Use ONLY on blank_slide() slides where
    the master is suppressed and you want a footer anyway.

    On standard content_slide() slides, do NOT call this — the master already
    provides the page number, confidentiality text, and CVS logo automatically.

    Args:
        slide: a slide where suppress_master() was already called
        page_num: integer page number
        logo_path: path to cvs_logo.png
    """
    # Page number (static text — master's dynamic ‹#› field is suppressed)
    box = slide.shapes.add_textbox(Inches(0.61), Inches(7.10), Inches(0.39), Inches(0.25))
    tf = box.text_frame
    p = tf.paragraphs[0]
    p.text = str(page_num)
    p.font.size = Pt(9)
    p.font.color.rgb = TEXT_LIGHT
    p.font.name = FONT

    # CVS Health logo (master's built-in logo is suppressed)
    slide.shapes.add_picture(logo_path, Inches(12.08), Inches(7.05),
                             Inches(0.85), Inches(0.32))


def add_confidentiality_text(slide):
    """Add confidentiality marking as inline text.

    Use ONLY on blank_slide() slides where suppress_master() was called.
    The master already provides this text on standard content_slide() slides.
    Assembles the phrase at runtime to avoid static DLP-flagged strings.
    """
    year = datetime.now().year
    parts = ['Confidential', 'and', 'proprietary']
    notice = f'\u00A9{year} CVS Health and/or one of its affiliates. {" ".join(parts)}.'

    box = slide.shapes.add_textbox(Inches(0.94), Inches(7.03), Inches(8.80), Inches(0.25))
    tf = box.text_frame
    p = tf.paragraphs[0]
    p.text = notice
    p.font.size = Pt(9)
    p.font.color.rgb = TEXT_LIGHT
    p.font.name = FONT


# ─────────────────────────────────────────────────────────────────────────────
# Shape helpers
# ─────────────────────────────────────────────────────────────────────────────

def rct(slide, x, y, w, h, fill_color, border_color=None, border_pt=0):
    """Add a filled rectangle. All dimensions in inches.

    Args:
        fill_color: RGBColor (use color constants above)
        border_color: RGBColor or None (no border)
        border_pt: border width in points
    """
    shape = slide.shapes.add_shape(1,  # MSO_SHAPE_TYPE.RECTANGLE
                                   Inches(x), Inches(y), Inches(w), Inches(h))
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    if border_color and border_pt > 0:
        shape.line.color.rgb = border_color
        shape.line.width = Pt(border_pt)
    else:
        shape.line.fill.background()  # no border
    return shape


def tb(slide, text, x, y, w, h,
       size=13, bold=False, color=None, align=None, wrap=True, italic=False):
    """Add a text box with CVS font defaults. All dimensions in inches.

    Args:
        color: RGBColor (defaults to TEXT_DARK)
        align: PP_ALIGN value (None = left)
    """
    color = color or TEXT_DARK
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.word_wrap = wrap
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(size)
    p.font.bold = bold
    p.font.italic = italic
    p.font.color.rgb = color
    p.font.name = FONT
    if align is not None:
        p.alignment = align
    return box


def badge(slide, text, x, y, bg_color=None, text_color=None, size=9, w=1.2, h=0.28):
    """Add a small label badge: filled rect + white bold text centered on top.

    Args:
        bg_color: RGBColor (defaults to CVS_RED)
        text_color: RGBColor (defaults to CVS_WHITE)
    """
    bg_color = bg_color or CVS_RED
    text_color = text_color or CVS_WHITE
    rct(slide, x, y, w, h, bg_color)
    tb(slide, text.upper(),
       x + 0.06, y + 0.04, w - 0.12, h - 0.08,
       size=size, bold=True, color=text_color, align=PP_ALIGN.CENTER)


def red_accent_bar(slide, x=0.5, y=0.36, w=1.2, h=0.06):
    """Add the small red accent bar used above slide titles in some layouts."""
    rct(slide, x, y, w, h, CVS_RED)


def divider_line(slide, x=0.5, y=None, w=12.33, color=None):
    """Add a thin horizontal rule. y defaults to just above footer zone (6.85")."""
    y = y if y is not None else 6.85
    color = color or BORDER_SOFT
    rct(slide, x, y, w, 0.02, color)


def card_shadow(shape, blur_pt=10, dist_pt=2, angle_deg=90, alpha_pct=92):
    """Apply the standard CVS card shadow (soft, downward) to a shape.

    python-pptx has no high-level shadow-setting API, so this writes the
    DrawingML effect directly onto the shape's <p:spPr>. Apply to every
    card-style container for consistent depth — see visual-vocabulary.md
    "Card Shadow Standard." Don't vary shadow style across a deck.

    Args:
        shape: python-pptx shape object (e.g. returned by rct())
        blur_pt: shadow blur radius in points
        dist_pt: shadow offset distance in points
        angle_deg: shadow direction in degrees (90 = straight down)
        alpha_pct: shadow opacity as a percent (92 = subtle; matches the
                   spec's "8% opacity" black, i.e. 100 - 8)
    """
    spPr = shape._element.spPr
    ns = 'http://schemas.openxmlformats.org/drawingml/2006/main'
    effect_lst = etree.SubElement(spPr, f'{{{ns}}}effectLst')
    outer_shdw = etree.SubElement(effect_lst, f'{{{ns}}}outerShdw')
    outer_shdw.set('blurRad', str(int(Pt(blur_pt))))
    outer_shdw.set('dist', str(int(Pt(dist_pt))))
    outer_shdw.set('dir', str(int(angle_deg * 60000)))
    outer_shdw.set('rotWithShape', '0')
    srgb_clr = etree.SubElement(outer_shdw, f'{{{ns}}}srgbClr')
    srgb_clr.set('val', '000000')
    alpha = etree.SubElement(srgb_clr, f'{{{ns}}}alpha')
    alpha.set('val', str(int((100 - alpha_pct) * 1000)))
    return shape


# ─────────────────────────────────────────────────────────────────────────────
# Icon helpers
# ─────────────────────────────────────────────────────────────────────────────

def find_icon(label, variant='outline', index_path='assets/icon-index.json'):
    """Look up an icon in the compact index.

    Returns [label, variant, category, slide_num, shape_name] or None.
    The index uses positional arrays — cols: label, variant, category, slide, shape.
    """
    with open(index_path) as f:
        idx = json.load(f)
    return next(
        (row for row in idx['icons']
         if row[0].lower() == label.lower() and row[1] == variant),
        None
    )


def recolor_icon(sp_element, hex_color):
    """Replace all fill color nodes in a copied icon shape with a target hex color.

    Args:
        sp_element: the lxml element of the copied shape
        hex_color: 6-char hex string without '#', e.g. 'CC0000'

    Replaces schemeClr (theme color references that may resolve incorrectly on
    receiving slides) and updates any existing srgbClr nodes.
    """
    ns = 'http://schemas.openxmlformats.org/drawingml/2006/main'
    # Replace schemeClr with srgbClr
    for node in list(sp_element.findall(f'.//{{{ns}}}schemeClr')):
        parent = node.getparent()
        if parent is not None:
            idx_in_parent = list(parent).index(node)
            parent.remove(node)
            srgb = etree.Element(f'{{{ns}}}srgbClr')
            srgb.set('val', hex_color)
            parent.insert(idx_in_parent, srgb)
    # Update existing srgbClr nodes
    for node in sp_element.findall(f'.//{{{ns}}}srgbClr'):
        node.set('val', hex_color)


def copy_icon(target_slide, label, variant='outline',
              x=None, y=None, w=None, h=None,
              color_hex=None,
              lib_path='assets/libraries/Iconography_Library_01_2026.pptx',
              index_path='assets/icon-index.json'):
    """Find, copy, reposition, and recolor an icon from the library into a slide.

    Args:
        target_slide: python-pptx slide object
        label: icon label string (case-insensitive). See references/icon-cheat-sheet.md
               for intent → label mapping. Use find_icon() to verify a label exists.
        variant: 'outline' (default, preferred) or 'filled'
        x, y: position in inches. None = keep library position.
        w, h: size in inches. None = keep library size. Typical icon: w=0.5, h=0.5
        color_hex: 6-char hex to apply to all fill nodes.
                   None → CVS_RED_HEX ('CC0000').
                   'FFFFFF' for icons on dark backgrounds.
                   'KEEP' to preserve library colors (not recommended on light bg).

    Returns:
        The copied shape element (lxml), or None if icon not found.
    """
    row = find_icon(label, variant, index_path)
    if row is None:
        return None

    _, _, category, slide_num, shape_name = row
    lib = Presentation(lib_path)
    src_slide = lib.slides[slide_num - 1]

    sp_copy = None
    for shape in src_slide.shapes:
        if shape.name == shape_name:
            sp_copy = copy.deepcopy(shape._element)
            target_slide.shapes._spTree.insert(2, sp_copy)
            break

    if sp_copy is None:
        return None

    # Reposition
    ns_a = 'http://schemas.openxmlformats.org/drawingml/2006/main'
    if any(v is not None for v in [x, y, w, h]):
        xfrm = sp_copy.find(f'.//{{{ns_a}}}xfrm')
        if xfrm is not None:
            off = xfrm.find(f'{{{ns_a}}}off')
            ext = xfrm.find(f'{{{ns_a}}}ext')
            if off is not None:
                if x is not None:
                    off.set('x', str(int(x * 914400)))
                if y is not None:
                    off.set('y', str(int(y * 914400)))
            if ext is not None:
                if w is not None:
                    ext.set('cx', str(int(w * 914400)))
                if h is not None:
                    ext.set('cy', str(int(h * 914400)))

    # Recolor (always, unless explicitly told to keep)
    if color_hex != 'KEEP':
        recolor_icon(sp_copy, color_hex or CVS_RED_HEX)

    return sp_copy

#!/usr/bin/env python3
"""
strip_example_slides_and_prompts.py — remove the 58 pre-built example content
slides from the Everyday Template, and clear the literal example text baked
into each of the 42 layouts' placeholders.

Why this exists:
The template shipped with 58 fully-populated example content slides (e.g. an
"Agenda 1" slide with real title/body text, not just a design mockup) plus 42
layouts whose own placeholders also carry literal default text ("Agenda",
"Click to add title for...", "Next steps", etc.) rather than truly empty
placeholders. Two related bugs came from this:

  1. The documented duplicate_slide() recipe (references/slide-layout-registry.md)
     deep-copies a chosen example slide's shapes onto a freshly-created slide
     that already has its own empty placeholders — leaving two title-type
     shapes on one slide, one empty and one carrying the old example text.
  2. Even without duplicate_slide(), any placeholder a build script doesn't
     explicitly fill stays empty at the slide level but still inherits the
     layout's literal default text. Editors (PowerPoint, LibreOffice, Google
     Slides) render that inherited text — with the placeholder's dashed
     outline — behind whatever else was drawn in roughly the same spot,
     producing a "ghost" of old template text behind real content the moment
     the deck is opened for editing.

A usage audit across several real deck-building sessions found the 58 example
slides are never actually reused via duplicate_slide() in practice — content
is built from a bare layout plus manual helpers instead — so removing them
costs nothing functionally and closes off the risk in (1) entirely. Clearing
the layouts' own placeholder text closes off (2): any placeholder left empty
by a build script now falls back to a generic, harmless "Click to add title"-
style prompt instead of misleading leftover example text.

What it does:
  1. Removes all p:sld slides from ppt/presentation.xml's sldIdLst (and their
     relationships) — same effect as cvs_utils.open_template(), applied once
     to the bundled file itself instead of at runtime on every build.
  2. For every slide layout, for every placeholder shape: clears its text
     frame (removes literal runs, keeps formatting/lstStyle) and removes the
     hasCustomPrompt="1" attribute so viewers fall back to their own generic
     type-based prompt rather than an empty "custom" one.
  3. Leaves the slide master, layout geometry/formatting, logo, hearts, and
     footer elements untouched — this only touches slide count and
     placeholder *text*, nothing else.

Usage:
    python3 strip_example_slides_and_prompts.py <path/to/template.pptx>

Rewrites the file in place.
"""

import sys
from pptx import Presentation
from pptx.oxml.ns import qn


def strip_content_slides(prs):
    sldIdLst = prs.slides._sldIdLst
    removed = 0
    for sldId in list(sldIdLst):
        rId = sldId.get(qn('r:id'))
        prs.part.drop_rel(rId)
        sldIdLst.remove(sldId)
        removed += 1
    return removed


def sanitize_layout_placeholders(prs):
    cleared = 0
    for layout in prs.slide_layouts:
        for ph in layout.placeholders:
            had_text = bool(ph.text_frame.text.strip())
            ph.text_frame.clear()
            ph_elm = ph.element.find(qn('p:nvSpPr') + '/' + qn('p:nvPr') + '/' + qn('p:ph'))
            if ph_elm is not None and ph_elm.get('hasCustomPrompt') is not None:
                del ph_elm.attrib['hasCustomPrompt']
            if had_text:
                cleared += 1
    return cleared


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(1)

    path = sys.argv[1]
    prs = Presentation(path)

    n_slides_removed = strip_content_slides(prs)
    n_placeholders_cleared = sanitize_layout_placeholders(prs)

    prs.save(path)
    print(f"Removed {n_slides_removed} example content slides.")
    print(f"Cleared baked example text from {n_placeholders_cleared} layout placeholders.")
    print(f"Layouts preserved: {len(prs.slide_layouts)}")


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""
strip_chart_embeddings.py — remove ppt/embeddings/*.xlsx and the chart
relationships that point at them, from a .pptx.

Why this exists:
A marketplace security scan flags ppt/embeddings/*.xlsx on sight (path-based
rule, not an actual embedded-object/macro finding — verified separately: no
p:oleObj, no progId, no vbaProject.bin, no ActiveX, no externalReferences/DDE
anywhere in this package). Filing an exception didn't clear the sweep, so
this removes the flagged parts outright instead.

This is safe for chart *rendering*: every chart's data is fully cached in its
own chart*.xml (<c:numCache>/<c:strCache>) — PowerPoint reads that to draw the
chart, never the embedded workbook. The only capability lost is "Edit Data in
Excel" opening the *original* linked spreadsheet for these specific charts;
modern PowerPoint instead generates a fresh workbook seeded from the cached
values when you click Edit Data on a chart with no externalData relationship.
python-pptx's own Chart.replace_data() already handles the "no existing
embedded part" case by creating a new one on demand, so future programmatic
chart-data updates aren't affected either.

What it does, per chart:
  1. Removes <c:externalData .../> (or the paired-tag form) from chart*.xml
  2. Removes the matching Relationship (Type=".../relationships/package")
     from ppt/charts/_rels/chart*.xml.rels
  3. Drops the corresponding ppt/embeddings/*.xlsx part entirely

Leaves [Content_Types].xml untouched — the xlsx content type is a generic
Default-Extension mapping, not a per-file Override, so there's nothing left
dangling once the embedding parts are gone.

Usage:
    python3 strip_chart_embeddings.py <path/to/template.pptx>

Rewrites the file in place.
"""

import re
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path


def strip_external_data(chart_xml: bytes) -> tuple[bytes, str | None]:
    """Remove the <c:externalData> element; return (new_xml, rId_removed_or_None)."""
    text = chart_xml.decode("utf-8")
    m = re.search(r'<c:externalData\s+r:id="([^"]+)"\s*/>', text)
    if m:
        return (text[: m.start()] + text[m.end() :]).encode("utf-8"), m.group(1)
    m = re.search(r'<c:externalData\s+r:id="([^"]+)"\s*>.*?</c:externalData>', text, flags=re.DOTALL)
    if m:
        return (text[: m.start()] + text[m.end() :]).encode("utf-8"), m.group(1)
    return chart_xml, None


def strip_relationship(rels_xml: bytes, rid: str) -> bytes:
    """Remove the <Relationship Id="rid" .../> entry from a .rels file."""
    text = rels_xml.decode("utf-8")
    text = re.sub(rf'<Relationship\s+Id="{re.escape(rid)}"[^>]*/>', "", text)
    return text.encode("utf-8")


def strip_chart_embeddings(path: Path) -> None:
    src = zipfile.ZipFile(path)
    names = src.namelist()

    chart_parts = sorted(n for n in names if re.match(r"ppt/charts/chart\d+\.xml$", n))
    embedding_parts = set(n for n in names if n.startswith("ppt/embeddings/") and n.endswith(".xlsx"))

    # Precompute: for each chart, its rels path and the rId to strip + embedding target.
    rid_by_chart = {}
    embeddings_dropped = set()
    for chart_name in chart_parts:
        rels_name = chart_name.replace("ppt/charts/", "ppt/charts/_rels/") + ".rels"
        if rels_name not in names:
            continue
        rels_text = src.read(rels_name).decode("utf-8")
        m = re.search(
            r'<Relationship\s+Id="([^"]+)"\s+Type="[^"]*relationships/package"\s+Target="\.\./embeddings/([^"]+)"\s*/>',
            rels_text,
        )
        if m:
            rid_by_chart[chart_name] = (rels_name, m.group(1), "ppt/embeddings/" + m.group(2))

    tmp_fd, tmp_path = tempfile.mkstemp(suffix=".pptx", dir=str(path.parent))
    Path(tmp_path).unlink()
    with zipfile.ZipFile(tmp_path, "w", zipfile.ZIP_DEFLATED) as out:
        for item in src.infolist():
            name = item.filename
            if name in embedding_parts:
                embeddings_dropped.add(name)
                continue  # drop the embedded workbook part entirely
            content = src.read(name)
            if name in rid_by_chart:
                content, removed_rid = strip_external_data(content)
                assert removed_rid == rid_by_chart[name][1], (
                    f"{name}: expected to remove rId {rid_by_chart[name][1]}, "
                    f"actually removed {removed_rid}"
                )
            for chart_name, (rels_name, rid, target) in rid_by_chart.items():
                if name == rels_name:
                    content = strip_relationship(content, rid)
            out.writestr(item, content)

    shutil.move(tmp_path, path)
    print(f"Stripped chart embeddings: {path}")
    print(f"  Charts processed: {len(rid_by_chart)} of {len(chart_parts)}")
    print(f"  Embedded workbooks removed: {len(embeddings_dropped)}")
    missed = embedding_parts - embeddings_dropped
    if missed:
        print(f"  WARNING — embedding parts still present: {sorted(missed)}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 strip_chart_embeddings.py <path/to/template.pptx>")
        sys.exit(1)
    strip_chart_embeddings(Path(sys.argv[1]))

"""
build_icon_index.py — CVS Health icon library indexer
======================================================
Run this whenever the icon library PPTX is updated to regenerate
assets/icon-index.json. Requires python-pptx:

    pip install python-pptx --break-system-packages

Usage (from the skill root directory):
    python3 assets/build_icon_index.py

Output: assets/icon-index.json
"""

import sys, re, json
from pathlib import Path

LIBRARY_PATH = Path(__file__).parent / "libraries" / "Iconography_Library_01_2026.pptx"
INDEX_PATH   = Path(__file__).parent / "icon-index.json"

try:
    from pptx import Presentation
    import lxml.etree as etree
except ImportError:
    print("ERROR: python-pptx not installed. Run:")
    print("  pip install python-pptx --break-system-packages")
    sys.exit(1)


def _get_labels(slide_raw):
    """Extract ordered icon labels from the slide's table element."""
    gf = re.search(r'<p:graphicFrame\b.*?</p:graphicFrame>', slide_raw, re.DOTALL)
    if not gf:
        return []
    cells = re.findall(r'<a:tc\b.*?</a:tc>', gf.group(0), re.DOTALL)
    labels = []
    for c in cells:
        texts = re.findall(r'<a:t>(.*?)</a:t>', c)
        label = ' '.join(t.strip() for t in texts if t.strip())
        if label:
            labels.append(label)
    return labels


def _get_freeforms(slide_raw):
    """Extract freeform vector shapes sorted by grid position (row then col)."""
    freeforms = []
    for sp in re.findall(r'<p:sp\b.*?</p:sp>', slide_raw, re.DOTALL):
        if '<a:custGeom>' not in sp:
            continue
        names = re.findall(r'<p:cNvPr[^>]+name="([^"]+)"', sp)
        offs  = re.findall(r'<a:off x="(\d+)" y="(\d+)"', sp)
        if names and offs:
            x = int(offs[0][0]) / 914400
            y = int(offs[0][1]) / 914400
            # Snap y to nearest 0.5" to cluster into rows robustly
            row = round(y * 2) / 2
            freeforms.append((row, x, names[0]))
    freeforms.sort(key=lambda f: (f[0], f[1]))
    return freeforms


def _detect_slide_meta(slide_raw):
    """Return (variant, category) or (None, None) if not an icon content slide."""
    variants = re.findall(r'<a:t>(Outline|Filled)</a:t>', slide_raw)
    if not variants:
        return None, None
    if not re.search(r'<p:graphicFrame\b', slide_raw):
        return None, None  # divider slide with no table
    variant = variants[0].lower()
    # Category is in the slide title shape
    category = ""
    for sp in re.findall(r'<p:sp\b.*?</p:sp>', slide_raw, re.DOTALL):
        if 'ph type' not in sp and 'ph ' not in sp:
            continue
        texts = re.findall(r'<a:t>(.*?)</a:t>', sp)
        full  = ' '.join(t.strip() for t in texts if t.strip())
        if 'Outline' in full or 'Filled' in full:
            cat = re.sub(r'(Outline|Filled)', '', full)
            cat = re.sub(r'\s*\(\d+ of \d+\)', '', cat).strip()
            if cat:
                category = cat
                break
    return variant, category or None


def index_library(library_path):
    prs = Presentation(str(library_path))
    all_entries = []
    warnings = []

    for i, slide in enumerate(prs.slides):
        slide_num = i + 1
        raw = etree.tostring(slide._element, pretty_print=True).decode()
        variant, category = _detect_slide_meta(raw)
        if not variant or not category:
            continue

        labels    = _get_labels(raw)
        freeforms = _get_freeforms(raw)

        n = min(len(labels), len(freeforms))
        if len(labels) != len(freeforms):
            warnings.append(
                f"Slide {slide_num} ({variant}/{category}): "
                f"{len(labels)} labels vs {len(freeforms)} shapes — "
                f"indexed first {n} matches"
            )

        for idx in range(n):
            _, _, shape_name = freeforms[idx]
            all_entries.append([labels[idx], variant, category, slide_num, shape_name])

    return all_entries, warnings


def main():
    if not LIBRARY_PATH.exists():
        print(f"ERROR: Library not found at {LIBRARY_PATH}")
        sys.exit(1)

    print(f"Indexing {LIBRARY_PATH.name}...")
    entries, warnings = index_library(LIBRARY_PATH)

    if warnings:
        print(f"\n⚠  {len(warnings)} slide(s) with count mismatches (gracefully handled):")
        for w in warnings:
            print(f"   {w}")

    # Count by category/variant
    cats = {}
    for e in entries:
        k = f"{e['variant']}/{e['category']}"
        cats[k] = cats.get(k, 0) + 1

    print(f"\n{'Category/Variant':<40} Count")
    print("-" * 48)
    for k, v in sorted(cats.items()):
        print(f"  {k:<38} {v}")

    index = {
        "_meta": {
            "source":    LIBRARY_PATH.name,
            "generated": __import__('datetime').date.today().isoformat(),
            "total":     len(entries),
            "cols":      ["label", "variant", "category", "slide", "shape"],
            "note":      "Compact array format. Search: row[0].lower()==target and row[1]==variant. Lookup: label,variant,category,slide,shape = row.",
        },
        "icons": entries,
    }

    with open(INDEX_PATH, "w") as f:
        json.dump(index, f, separators=(',', ':'))  # compact — no whitespace

    print(f"\n✓ Wrote {INDEX_PATH.name}: {len(entries)} icons indexed")


if __name__ == "__main__":
    main()

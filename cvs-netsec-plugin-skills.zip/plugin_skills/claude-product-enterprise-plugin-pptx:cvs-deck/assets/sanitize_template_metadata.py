#!/usr/bin/env python3
"""
sanitize_template_metadata.py — strip stale author names and MSIP Purview
labels from the bundled Everyday Template (and its embedded chart workbooks).

Why this exists:
The Everyday Template's docProps/core.xml carries a real employee's name as
creator/lastModifiedBy, plus a stale MSIP Purview label (SiteId/ActionId from
whoever last touched the file in SharePoint before it was checked out for
bundling). Each of the 8 embedded chart-data workbooks (ppt/embeddings/*.xlsx)
carries its own docProps with different real names and a different stale MSIP
label. None of this metadata is stripped by the skill's slide-strip pattern —
the deck-level metadata survives into EVERY generated deck, and the embedded
workbook metadata survives into every deck that reuses a chart layout (which
the skill's own docs instruct builders to do, since chart layouts are
duplicated from these exact template slides, not built from scratch).

This script neutralizes both without touching chart data, structure, styles,
or relationships — charts and "Edit Data in Excel" keep working exactly as
before, just without carrying a stranger's name or a meaningless inherited
sensitivity label into every deck a CVS colleague builds and shares.

Usage:
    python3 sanitize_template_metadata.py <path/to/template.pptx>

Rewrites the file in place. Run this any time the template is refreshed from
SharePoint (see assets/manifest.json → annual_refresh_procedure), before
re-bundling — the freshly pulled file will have the same problem.
"""

import re
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

GENERIC_NAME = "CVS Health Brand Team"

CORE_NS = "http://purl.org/dc/elements/1.1/"
CP_NS = "http://schemas.openxmlformats.org/package/2006/metadata/core-properties"


def sanitize_core_xml(data: bytes) -> bytes:
    """Replace dc:creator and cp:lastModifiedBy text content with a generic name."""
    text = data.decode("utf-8")
    text = re.sub(
        r"(<dc:creator>).*?(</dc:creator>)",
        rf"\g<1>{GENERIC_NAME}\g<2>",
        text,
    )
    text = re.sub(
        r"(<cp:lastModifiedBy>).*?(</cp:lastModifiedBy>)",
        rf"\g<1>{GENERIC_NAME}\g<2>",
        text,
    )
    return text.encode("utf-8")


def sanitize_custom_xml(data: bytes) -> bytes:
    """Drop MSIP_Label_* and ContentTypeId <property> elements; keep everything else."""
    text = data.decode("utf-8")
    # Each <property ...>...</property> is on one "logical" element; they are not
    # nested, so a non-greedy match per element is safe here.
    text = re.sub(
        r'<property\b[^>]*\bname="(?:MSIP_Label_[^"]*|ContentTypeId)"[^>]*>.*?</property>',
        "",
        text,
        flags=re.DOTALL,
    )
    return text.encode("utf-8")


def sanitize_xlsx_bytes(xlsx_bytes: bytes) -> bytes:
    """Sanitize docProps/core.xml and docProps/custom.xml inside a nested embedded workbook."""
    src = zipfile.ZipFile(__import__("io").BytesIO(xlsx_bytes))
    buf = __import__("io").BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as out:
        for item in src.infolist():
            content = src.read(item.filename)
            if item.filename == "docProps/core.xml":
                content = sanitize_core_xml(content)
            elif item.filename == "docProps/custom.xml":
                content = sanitize_custom_xml(content)
            out.writestr(item, content)
    return buf.getvalue()


def sanitize_pptx(path: Path) -> None:
    src = zipfile.ZipFile(path)
    names = src.namelist()

    core_touched = "docProps/core.xml" in names
    custom_touched = "docProps/custom.xml" in names
    embedded_xlsx = [n for n in names if n.startswith("ppt/embeddings/") and n.endswith(".xlsx")]
    trash_entries = [n for n in names if n.startswith("[trash]/")]

    tmp_fd, tmp_path = tempfile.mkstemp(suffix=".pptx", dir=str(path.parent))
    Path(tmp_path).unlink()  # zipfile wants to create it itself
    with zipfile.ZipFile(tmp_path, "w", zipfile.ZIP_DEFLATED) as out:
        for item in src.infolist():
            if item.filename in trash_entries:
                continue  # drop unreferenced PowerPoint packaging junk
            content = src.read(item.filename)
            if item.filename == "docProps/core.xml":
                content = sanitize_core_xml(content)
            elif item.filename == "docProps/custom.xml":
                content = sanitize_custom_xml(content)
            elif item.filename in embedded_xlsx:
                content = sanitize_xlsx_bytes(content)
            out.writestr(item, content)

    shutil.move(tmp_path, path)
    print(f"Sanitized: {path}")
    print(f"  docProps/core.xml scrubbed: {core_touched}")
    print(f"  docProps/custom.xml scrubbed: {custom_touched}")
    print(f"  embedded workbooks scrubbed: {len(embedded_xlsx)}")
    print(f"  unreferenced [trash]/ entries removed: {len(trash_entries)}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 sanitize_template_metadata.py <path/to/template.pptx>")
        sys.exit(1)
    sanitize_pptx(Path(sys.argv[1]))

---
name: cvs-deck
description: >
  Use this skill any time a CVS Health-branded PowerPoint presentation is involved — creating,
  editing, reviewing, or auditing .pptx files for CVS brand compliance. Triggers include: any
  mention of "CVS deck," "CVS slides," "CVS presentation," "CVS Health template," or any request
  to build or fix a slide deck intended for CVS Health. Also triggers when the user uploads a
  .pptx file in a CVS work context and asks for edits, brand review, or new slides. This skill
  wraps the base pptx skill with mandatory CVS brand enforcement — always use it instead of the
  generic pptx skill when CVS is involved. Use it proactively if there are any signs the user is
  working in a CVS Health context (e.g., CVS colors, CVS logo, CVS content).
metadata:
  version: "0.1.2"
  author: "Ben Dundee"
  contact: "Ben.Dundee@cvshealth.com"
---

# CVS Health PowerPoint Skill — v0.1.2

This skill governs the creation and editing of CVS Health-branded slide decks. It extends the base **pptx skill** with mandatory CVS brand compliance. Always follow both sets of rules.

> **General Availability.** First org-wide release. Brand assets (template, hearts, logo, icon library) are bundled locally — no SharePoint connector required for a standard build. The CVS master is embedded via a slide-strip pattern (see "Template Foundation" below); covers come from 6 built-in layouts; icons are copied as vector shapes from the bundled Iconography Library. See the Changelog at the bottom of this file for what led here.
---

## Environment — detect the surface before acting

Determine where you're running from what's actually available, not assumption. This decides
**whether you build a file at all**, so settle it before the Pre-flight Sequence:

- **Claude in PowerPoint** — live-document tools are present in your tool list. "Current slide"
  and "selection" are real, and the user already has a deck open. Read and write through the live
  file via Office JS (`PowerPoint.run(async (context) => {...})`). **Do not run `open_template()`
  and do not build a new presentation** — python-pptx does not operate on the live deck, and
  handing back a separate file is the wrong deliverable when the user pointed at the one in front
  of them.

  **You cannot install the CVS master in this surface. Say so; do not pretend otherwise.**
  Three routes exist and all are closed today:
  - `open_template()` needs a file and code execution. Neither applies to a live deck.
  - `Presentation.insertSlidesFromBase64()` with the default `KeepSourceFormatting` *would* carry
    a master across — but it works by inserting **slides**, and the bundled
    `everyday_2026.pptx` ships with **0** (all 58 examples were stripped in v0.1.1). There is
    nothing for it to insert, so nothing carries the master.
  - Re-theming slides that already exist is not supported by the PowerPoint JS API at all.

  So what you *can* do here is every rule that does not depend on the master: the palette, the
  type tiers, layout and composition choices, spacing, the icon and heart rules, and every Hard
  Prohibition. That produces a deck that **looks** CVS-branded without **being** CVS-mastered —
  PowerPoint's Design tab will not show the Everyday theme, and slide-master edits will not
  propagate. State that difference plainly, and offer the alternative: build the deck in Claude
  Chat or Claude Code, where the full pipeline runs, and move the content across. Never report a
  deck as brand-compliant when only its surface styling was corrected.

- **Claude Chat** — no live-document tools. Either a `.pptx` arrived as an upload or the deck is
  being built from scratch. There is no selection or active document: the user names the scope,
  you work via code execution with python-pptx, and the full pipeline below applies
  (`open_template()`, master embedding, the whole Pre-flight Sequence). Deliver a **downloadable
  file** — save to `/mnt/user-data/outputs/` and call `present_files`. Never hand back a bare
  filesystem path, `./out/`, or `~/.claude/`.

- **Claude Code** — no live-document tools, but a real filesystem and the user's own working
  directory. Same python-pptx pipeline as Chat; save to the working directory and state the
  absolute path in your final response.

Never emit Office JS outside Claude in PowerPoint, and never ask a Chat or Claude Code user
about their "selection" or "current slide". Conversely, never reach for python-pptx,
`open_template()`, or `/mnt/user-data/outputs/` inside Claude in PowerPoint — none of them apply
to a live deck.


---

## Pre-flight Sequence — Mandatory (Local-First)

**Before writing a single line of python-pptx code, execute these five steps in order. No exceptions.** This sequence describes a python-pptx file build, so it applies on **Claude Chat and Claude Code**. In **Claude in PowerPoint** there is no file to build — see "Environment — detect the surface before acting" above and work through the live deck instead.

```
ASSET_VINTAGE = 2026   # bump this when assets/ is refreshed from SharePoint
```

1. **Load `assets/manifest.json`** — verify each `must_bundle` asset exists on disk at its declared path. Decision:
   - **All present →** proceed. No connector needed.
   - **Any missing →** `tool_search(query="microsoft 365 sharepoint read_resource")`, then `Microsoft 365:read_resource(uri=<source_uri from manifest>)` for that one asset. Document the gap in your response under "Asset Provenance." Then continue.

2. **Run the staleness check** — if `ASSET_VINTAGE != datetime.now().year`, output a non-blocking warning:
   ```
   [ASSET STALENESS] Bundled brand assets are vintage {ASSET_VINTAGE}; it is now {CURRENT_YEAR}.
   CVS refreshes assets annually — see assets/manifest.json source_uri values for SharePoint locations.
   Proceeding with {ASSET_VINTAGE} assets.
   ```
   This does **not** block the build. It signals that a refresh is likely available.

3. **Open the template** — `open_template()` also strips any content slides present, preserving the slide master and its 42 layouts; the bundled file already ships with 0, so this is normally a no-op safety net, not an observable step. This is the step that embeds the CVS theme into your output file. See "Template Foundation" section below for the exact code. **Never start from a blank `Presentation()`.**

4. **Choose a cover layout** — the bundled template has no content slides to begin with. Covers come from **layouts**, not slides. Use `get_layout(prs, 'Title Slide')` or the variant matching the cover-registry.md Quick-Match guide (the 6 built-in `Title Slide` layouts are the only covers this skill supports). Confirm with user if audience or formality is unclear.

5. **Confirm your delivery path** — you settled the surface in "Environment — detect the surface before acting" above; this is where you act on it, before you build rather than after:
   - **Claude Chat** (computer-use tools present — `bash`/`create_file`/`present_files` or equivalent) → save the finished `.pptx` to `/mnt/user-data/outputs/` and call `present_files`. Don't just describe the file — the person needs a way to actually open it.
   - **Claude Code** (no computer-use tools) → save to the user's current working directory and state the absolute path in your final response.

Only after these five complete should you read the rest of the references and start building. **The mandatory SharePoint round-trip from earlier versions is removed from the common path.** For a fully-stocked `assets/` directory, no M365 connector is required. If the connector is unavailable, missing assets are the only failure mode — and they are rare once the package is properly bundled.

**Skipping local-asset verification is a build failure regardless of how the output looks.**

---

## Step 0 — Reading List

**Always read (load every build):**

| File | Why |
|---|---|
| `references/QUICK_BUILD_REF.md` | Constants, grid, title tiers, CONTENT_Y, common layouts, checklist |
| `/mnt/skills/public/pptx/SKILL.md` | Base tooling and rendering mechanics |

**Read on trigger:**

| File | Read when |
|---|---|
| `references/CVS_Slide_Style_Guide.md` | Anything beyond the Quick Ref: dark slide variants, column rules, brand edge cases |
| `references/visual-vocabulary.md` | Before placing any named visual (hexagon, funnel, hero quote, journey map, cycle, RACI) |
| `references/layout-quick-ref.md` | When the quick-pick in QUICK_BUILD_REF.md doesn't have the layout you need |
| `references/inspiration-patterns.md` | When content matches a named pattern (exec summary, 30-60-90, portfolio status) |
| `references/icon-cheat-sheet.md` | Before placing any icon — intent → exact label mapping |
| `references/icon-registry.md` | When the cheat sheet doesn't cover your intent — category browsing |
| `assets/icon-index.json` | At icon placement time only — do not load speculatively |
| `references/cover-registry.md` | When selecting a cover — Quick-Match guide to the 6 built-in covers |
| `references/slide-layout-registry.md` | When detailed layout specs beyond the quick-pick are needed |

> **Cost discipline:** a standard 10-slide deck should touch only QUICK_BUILD_REF.md + icon-cheat-sheet.md + layout-quick-ref.md at most. Reading beyond that on every build is the main way this skill wastes context.

---

## Template Foundation — Embedding the CVS Master

This is the single most important architectural concept in the skill. **The output PPTX must contain the CVS slide master** — not just CVS-colored shapes on a blank file. When the master is embedded, PowerPoint recognizes the presentation as using the CVS Everyday theme: Design tab shows the theme, slide master edits propagate, fonts and color palette resolve correctly.

**The correct pattern — or use `cvs_utils.open_template()` which does this automatically:**

```python
# One-liner via cvs_utils (recommended):
import sys; sys.path.insert(0, 'assets')
from cvs_utils import *
prs = open_template()   # opens template, strips slides, preserves master

# Manual equivalent if not using the module:
from pptx import Presentation
from pptx.oxml.ns import qn

# Step 1: Open the template
prs = Presentation("assets/templates/everyday_2026.pptx")

# Step 2: Strip any content slides while preserving the slide master
# (no-op on the bundled file, which ships pre-stripped — this is a safety net
# for a freshly-pulled, unstripped copy of the template)
sldIdLst = prs.slides._sldIdLst
for sldId in list(sldIdLst):
    rId = sldId.get(qn('r:id'))
    prs.part.drop_rel(rId)
    sldIdLst.remove(sldId)

# Step 3: Look up layouts by name (robust — never use index numbers directly)
def get_layout(prs, name):
    return next(l for l in prs.slide_layouts if l.name == name)

# Step 4: Add slides using the named layouts
slide = prs.slides.add_slide(get_layout(prs, 'Title and Content'))
slide.placeholders[0].text = "Slide Title"
slide.placeholders[1].text = "Body content"

# Save — the output embeds the CVS master; PowerPoint will recognize the theme
prs.save("output.pptx")
```

**Why this step stays in the code:** it's a no-op against the bundled template (already 0 content slides), but it's cheap insurance against a freshly-pulled, unstripped copy — skipping it there would carry all the original example slides into your output instead of the clean slate of just the slide master and its 42 named layouts.

**Why named lookup matters:** Layout indices shift if the template is ever updated. `get_layout(prs, 'Two Content')` is stable; `prs.slide_layouts[16]` is fragile.

### Master shape inheritance — what the master provides

The CVS Everyday Template master automatically provides three footer elements on every slide that does **not** suppress the master:

| Element | Position | How it appears |
|---|---|---|
| CVS Health logo | bottom-right, y≈6.97" | `Graphic 13` in master |
| Confidentiality text | bottom-left, y≈7.03" | `TextBox 12` in master |
| Page number field | bottom-left, y≈6.96" | `Content Placeholder 8` in master (auto-updates) |

**Standard content slides inherit all three for free.** Do not add them manually.

The layouts that suppress the master (`showMasterSp=0`) — and are designed to have no footer — are:
- All `Title Slide` variants (0–6): covers don't get page numbers or confidentiality text
- `Divider red/gray/navy/white/dark`: section breaks have no footer by design

The `Title Slide` layout compensates by including its own CVS Health logo and red outline heart directly in the layout (at y≈0.47" and y≈1.11" respectively), in the slide area rather than the footer zone.

### Controlling master shape inheritance (`showMasterSp`)

If you use `blank_slide()` (master suppressed), all three footer elements disappear. To restore them manually:

```python
slide = blank_slide(prs)   # suppresses master
# If this slide needs a footer (not all custom slides do):
add_confidentiality_text(slide)        # positions match master: x=0.94", y=7.03"
add_footer(slide, page_num)            # page number + logo matching master positions
```

**When to use `blank_slide()`:**
- Slides with fully custom layouts that no named layout accommodates
- Slides where placeholder conflicts would arise

**When NOT to use `blank_slide()`:**
- Standard content slides — use `content_slide(layout_name)`
- Cover slides — use `cover_slide(prs, title, presenter)`
- Section dividers — use `content_slide(prs, 'Divider red')`

### `Blank` + suppress master — the custom-content pattern

For truly custom slides, `blank_slide()` is correct: the CVS theme stays embedded, placeholder conflicts are eliminated, and you have full shape control. But it is the exception, not the default. Over-applying it is the single most common mistake in generated decks — it produces manual text-box footers instead of master-inherited ones.

### Layout quick-pick

Read `references/layout-quick-ref.md` for the full 42-layout index. Common picks:

- Standard content → `Title and Content` (15)
- Two-column → `Two Content` (16) or `Comparison` (22)
- Section break → `Divider red` (9), `Divider navy` (11), `Divider gray` (10)
- Cover → `Title Slide` (0) through `Title Slide 6` (5)
- Closing → `Closing slide` (39) or `Closing` (34)
- Journey / process → `Five Content Journey` (19)
- Pull quote → `Quote or high impact` (32)

## Asset Provenance — Local-First Model

In this model, brand assets are read from the bundled `assets/` directory — not fetched from SharePoint at runtime. This section explains the model, documents what's where, and covers the SharePoint fallback for missing assets.

### Where assets live

| Asset | Local path | Notes |
|---|---|---|
| Everyday Template | `assets/templates/everyday_2026.pptx` | Open this; never blank `Presentation()`. Includes 6 built-in cover variants. |
| Icon Library | `assets/libraries/Iconography_Library_01_2026.pptx` | Vector shapes — see icon copy recipe |
| Icon Index | `assets/icon-index.json` | 1,228 icons mapped; regenerate with `build_icon_index.py` |
| Heart — solid red | `assets/marks/heart_solid_red_reg.png` / `_sm.png` | 1102×915 / 362×301px RGBA — hero heart for covers |
| Heart — solid white | `assets/marks/heart_solid_white_reg.png` / `_sm.png` | 1102×915 / 362×301px RGBA — for dark backgrounds |
| Heart — outline red | `assets/marks/heart_outline_red_reg.png` / `_sm.png` | 276×229 / 212×176px RGBA — accent use |
| Heart — outline white | `assets/marks/heart_outline_white_reg.png` / `_sm.png` | 276×229 / 212×176px RGBA — accent on dark backgrounds |
| CVS Logo | `assets/marks/cvs_logo.png` | Pre-extracted from Everyday Template |

All paths are relative to the skill root. See `assets/manifest.json` for the full registry, source URIs, and annual refresh procedure.

### Worked example — Using the solid heart

```python
# No fetch step needed — asset is local
slide.shapes.add_picture(
    "assets/marks/heart_solid_red_reg.png",
    Inches(9.0), Inches(1.0), Inches(4.0), Inches(4.4)
)
```

### Worked example — Copying an icon (vector, no rasterization)

```python
import copy, json
from pptx import Presentation

# Load the index (compact array format — cols: label, variant, category, slide, shape)
with open("assets/icon-index.json") as f:
    icon_index = json.load(f)["icons"]

# Find the icon by name and variant (positional: row[0]=label, row[1]=variant)
label    = "stethoscope"    # case-insensitive
variant  = "outline"        # "outline" (default) or "filled"
match    = next((row for row in icon_index
                 if row[0].lower() == label and row[1] == variant), None)

if match:
    label, variant, category, slide_num, shape_name = match
    lib = Presentation("assets/libraries/Iconography_Library_01_2026.pptx")
    src_slide = lib.slides[slide_num - 1]
    for shape in src_slide.shapes:
        if shape.name == shape_name:
            sp_copy = copy.deepcopy(shape._element)
            target_slide.shapes._spTree.insert(2, sp_copy)
            # Reposition by editing the <a:off> element if needed:
            # off = sp_copy.find('.//{http://schemas.openxmlformats.org/drawingml/2006/main}off')
            # off.set('x', str(int(target_x_inches * 914400)))
            # off.set('y', str(int(target_y_inches * 914400)))
            break
else:
    # Icon not in index — document the gap in Asset Provenance
    pass
```

> **Why vector copy, not PNG?** Icons in the library are DrawingML freeform paths — they scale perfectly at any size, stay editable (fill color, stroke weight), and add no rasterization blur. PNG would be a quality downgrade. The index file maps label → (slide, shape name) so this is a fast O(n) lookup with no file conversion step.

### Worked example — Using a cover

```python
# Step 1 — Read references/cover-registry.md, use Quick-Match to select one of the 6 built-in covers
# Step 2 — Covers come from layouts, not slides — content slides were stripped in the pre-flight
slide = cover_slide(prs, "Presentation Title", "Presenter Name | CVS Health | Month Year")
# cover_slide() always uses the 'Title Slide' layout. For one of the other 5 built-in
# variants (Title Slide 2-6), use get_layout(prs, 'Title Slide 4') directly instead.
```

### When a local asset is missing — the Documented-Failure rule

If a `must_bundle` asset is absent from the local `assets/` directory, you may fall back to SharePoint **only if you document the gap**. In your final response, include an "Asset Provenance" section listing:

- Which asset was missing and its expected local path
- The `source_uri` from `manifest.json` you used to fetch it
- Whether the fetch succeeded or failed (and if failed, the exact error)
- What fallback you used if the fetch also failed (PIL-drawn, primitive, scratch-built)
- A recommendation to re-bundle the skill with the missing asset populated

**A self-generated heart, icon, or cover with no documented missing-asset gap is a hard build failure** — it ships off-brand work while making the failure invisible to the user. This documentation requirement holds regardless of why the asset was missing (a missing local file, a failed SharePoint fetch, or anything else).

---

## CVS Brand Rules — Fast Reference

### Colors (never deviate from these exact hex values)

| Token | Hex | Use |
|---|---|---|
| `cvs-red` | `CC0000` | Primary accent — super titles, icons, stats, CTA |
| `cvs-red-soft` | `F7978D` | Super titles on navy backgrounds only |
| `cvs-navy` | `0B315E` | Dark slide backgrounds (dividers, cover variants) |
| `cvs-navy-deep` | `081F3F` | Cards on navy slides |
| `cvs-blue` | `0A4B8C` | Numbered circles, secondary chart color |
| `cvs-text-gray` | `3F3F3F` | All slide titles — **never use pure black `000000`** |
| `cvs-gray-medium` | `646464` | Body text, descriptions |
| `cvs-gray-light` | `868686` | Captions, footers |
| `cvs-white` | `FFFFFF` | Primary background, text on dark slides |
| `cvs-gray-surface` | `F7F7F7` | Card backgrounds, alternating table rows |
| `cvs-gray-border` | `C0C0C0` | Borders, dividers |

**Chart color sequence** (use in order): `267AC0`, `00787E`, `00A78E`, `868686`, `61A515`, `487A10`, `F4642A`, `CE430C`, `E94D4D`, `7D3F98`

### Typography

- **Font**: `CVS Health Sans` — always. Never substitute Arial, Calibri, or any other font.
- **Titles** (`3F3F3F`, 32 pt bold) — left-aligned
- **Super titles / eyebrows** (`CC0000`, 13 pt bold, sentence case) — not ALL CAPS
- **Body** (`646464`, 13–14 pt regular) — left-aligned
- **Large stats** (`CC0000`, 44–80 pt bold)
- **Table headers** (white on navy, 9–10 pt bold uppercase, slight letter-spacing)
- **Footnotes** (9–10 pt, `868686`) — min 11 pt for Medicare-facing content

### Layout Grid (13.333″ × 7.5″ widescreen)

```
Super title:  x:0.5  y:0.4   w:12    h:0.35   (13pt bold red)
Title:        x:0.5  y:0.75  w:12.3  h:0.9    (32pt bold dark gray)
Safe area:    y:1.6 → y:6.9  (content lives here)
Footer zone:  y:7.0 → y:7.5  (RESERVED — no content below y:6.9)
```

## Slide Type Quick Reference

| Type | Background | Logo position | Footer |
|---|---|---|---|
| **Cover** | White | Top-left `(0.5, 0.5)` 1.6×0.6 | Confidentiality text only, no page# |
| **Section divider** | Navy `0B315E` | None | No footer |
| **Content (standard)** | White | Bottom-right via footer | Full footer (page# + confidentiality + logo) |

See `references/CVS_Slide_Style_Guide.md` §8 for full recipes for each slide type (one-column, two-column, data/table, stat callout, quote callout).

---

## Design Philosophy — Compliance Is Not Enough

**A deck that follows every brand rule but feels generic has failed.**

CVS Health has a distinctive visual language: hearts, hexagons, tapered funnels, dramatic red/navy color blocks, hero numbers, oversized quotation marks. *Use it.* A striking slide that takes a small brand-aligned creative liberty is better than a flat slide that follows every rule.

The asset libraries and inspiration patterns exist to enable this. When the user provides an outline that mentions specific visuals — "hexagonal diagram", "funnel", "journey map" — those are commitments, not suggestions. Build them as named.

**Read `references/visual-vocabulary.md` for concrete recipes.** It contains the actual code patterns for hearts, hexagons, funnels, hero quotes, semantic-color profile cards, and more. Without it, output defaults to a generic "rectangles + navy + gray + columns" pattern that is brand-compliant but visually flat.

The bar: a skilled human designer at CVS would look at the output and recognize it as on-brand work — not just rule-compliant work.

---

## Visual Motifs to Use

These are CVS signature patterns — reach for them:
- **The CVS Heart**: covers, closing slides, footer mark — **always loaded** from `assets/marks/heart_*.png`. Four variants are bundled: `heart_solid_red_reg` (hero — covers and closing slides on white/light backgrounds), `heart_solid_white_reg` (hero on dark/navy backgrounds), `heart_outline_red_reg` (accent use), `heart_outline_white_reg` (accent on dark backgrounds). Each has a `_sm` variant for small placements. **Never use `MSO_SHAPE.HEART`** for the brand mark — it reads as Valentine's Day. **Never draw your own heart in PIL, SVG, or any other code path** — the official asset has specific proportions and curvature that hand-drawn approximations miss. For "heart-flavored" supporting visuals on body slides (not a literal brand-mark moment), use a reduced-scale/low-opacity `heart_outline_*` asset or a Health care-category icon instead — no pictogram library is bundled.
- **Hexagons**: numbered value drivers, three-pillar tiles, "honeycomb" diagrams
- **Tapered funnels (TRAPEZOID rotated)**: conversion / drop-off visuals — never stacked rectangles
- **Numbered circles with red border**: navy ovals with red outline, white centered number
- **Chevrons**: process flow connectors, badge points, directional emphasis
- **Hero quotation mark + italic quote on navy**: pull quotes get dedicated visual real estate
- **Semantic color cards**: green-tinted for positive/strong, amber-tinted for opportunity/needs-attention
- **Left or top red accent bar**: 0.05–0.06″ thin red bar on edge of callout boxes/cards
- **Section header strips**: navy or red horizontal strips with white uppercase text
- **Icons**: **always copy as vector shapes** from `assets/libraries/Iconography_Library_01_2026.pptx` using `assets/icon-index.json` for lookup. Do not rasterize to PNG — the freeform shapes scale perfectly and keep their fill color editable. Primitive-built icons are forbidden unless preceded by a documented missing-asset gap (see Asset Provenance section).

**Icon copy recipe:**
```python
import copy, json, lxml.etree as etree
from pptx import Presentation

# 1. Load the compact index and find the icon
# Format: each row = [label, variant, category, slide, shape]
with open("assets/icon-index.json") as f:
    index = json.load(f)

match = next((row for row in index["icons"]
              if row[0].lower() == "bar chart" and row[1] == "outline"), None)

# 2. Copy the vector shape from the library into the target slide
if match:
    label, variant, category, slide_num, shape_name = match
    lib = Presentation("assets/libraries/Iconography_Library_01_2026.pptx")
    src_slide = lib.slides[slide_num - 1]
    for shape in src_slide.shapes:
        if shape.name == shape_name:
            sp_copy = copy.deepcopy(shape._element)
            target_slide.shapes._spTree.insert(2, sp_copy)
            # Reposition: update <a:off x="{EMU}" y="{EMU}"/> in sp_copy if needed
            break

# 3. Recolor after copy — library icons carry solidFill/schemeClr nodes that may
#    resolve to invisible or wrong colors on light backgrounds.
def recolor_icon(sp_element, hex_color):
    """Replace all fill color nodes in a copied icon shape with a target hex color.
    hex_color: 6-char hex string without '#', e.g. 'CC0000' for CVS red."""
    ns = 'http://schemas.openxmlformats.org/drawingml/2006/main'
    # Remove any schemeClr nodes (theme color references that may resolve incorrectly)
    for node in sp_element.findall(f'.//{{{ns}}}schemeClr', sp_element.nsmap if hasattr(sp_element, 'nsmap') else {}):
        parent = node.getparent()
        if parent is not None:
            # Replace with srgbClr
            srgb = etree.SubElement(parent, f'{{{ns}}}srgbClr')
            srgb.set('val', hex_color)
            parent.remove(node)
    # Update any existing srgbClr nodes
    for node in sp_element.findall(f'.//{{{ns}}}srgbClr'):
        node.set('val', hex_color)

# Example: force CVS red on a copied icon
recolor_icon(sp_copy, 'CC0000')   # CVS Red
# recolor_icon(sp_copy, 'FFFFFF')  # White (for icons on navy/dark backgrounds)
```
> **Always recolor after copy.** Library icons use `schemeClr` references that may resolve to non-red or near-invisible colors depending on the receiving slide's theme context. Call `recolor_icon()` immediately after the insert — before saving. Use `CC0000` for CVS Red (light backgrounds), `FFFFFF` for white (navy/dark backgrounds).
- **Hash mark**: short red rectangle below a hero number — a signature CVS treatment

---

## Color Discipline — Pick a Scheme, Not Colors

Picking colors element-by-element produces the navy-and-red conflict that reads as "patriotic, not healthcare." The fix: **pick a palette scheme per slide before placing any color.**

The four schemes are defined in `references/visual-vocabulary.md` → **Palette Schemes**:

| Scheme | When to use |
|---|---|
| **White Editorial** *(default)* | Body content slides, dashboards, most workhorse layouts |
| **Navy Hero** | Dividers, closing, executive stat callouts, hero quotes |
| **Warm Heart** | Covers, closing, mission/values moments — always paired with the heart asset |
| **Semantic Split** | True comparison content (strong vs. opportunity, before/after) |

**Default to White Editorial unless the slide type warrants something else.** See the per-slide-type defaults table in visual-vocabulary.md.

**The buffer rule:** red and navy never share a large border without white, `surfWarm`, or `borderSoft` separating them. Most "navy and red feel wrong together" moments are caused by violating this rule. Read the buffer-rule examples in visual-vocabulary.md before placing red elements next to navy ones.

**60/30/10 dominance check:** if red is taking up more than ~10% of the visible area of a slide, pull it back. Red is a punctuation mark, not a paragraph.

---

## Iconography Cadence — Conservative, Purposeful

Icons exist to collect parallel text blocks under a common visual theme. They unify; they don't decorate. (No pictogram library is bundled with this skill — icons are the only glyph asset available.)

- **Roughly 1 in 3 content slides should carry an icon.** Cover, dividers, and closing slides don't count toward the ratio. A deck with zero icons feels generic; a deck with icons on every line item reads as cluttered.
- **When a slide has parallel text blocks** (3 columns, 4 quadrants, value drivers, pillars), give each block a matching icon. Pull the icons from a single category (all from "Healthcare 1," all in red on white) so the set reads as unified — *don't* mix outline and filled icons within one parallel set.
- **Icons earn their place at three specific spots:** stat callouts (above the number), pillar/value-driver tiles (one per tile), and section header strips (left of the label). Outside those three, ask whether the icon is actually doing work or just filling space.

---

## Hard Prohibitions (these signal off-brand / AI-generated slides)

1. ❌ Full-width colored bars at slide top or bottom (no header/footer color stripes — except cover/closing)
2. ❌ Accent lines directly under slide titles
3. ❌ Cream, beige, or warm-neutral backgrounds — white (`FFFFFF`), navy, or `surfWarm` (behind hearts) only
4. ❌ Pure black (`000000`) text — always use `3F3F3F`
5. ❌ Blue as the primary accent — red is primary, blue is secondary
6. ❌ Heavy letter-spacing on titles — only slight `charSpacing` on small section labels
7. ❌ Serif fonts — CVS Health Sans is sans-serif
8. ❌ Centered body text — center titles only on cover/divider slides
9. ❌ Emojis — use professional iconography in CVS red
10. ❌ Rounded rectangles for accent bars — use sharp `RECTANGLE`
11. ❌ **Using `MSO_SHAPE.HEART` to represent the CVS Heart** — use the bundled PNGs in `assets/marks/` instead. The shape primitive reads as Valentine's Day.
12. ❌ **Building a slide without first picking a palette scheme** — picking red, navy, and gray element-by-element creates the navy-and-red conflict. Pick White Editorial / Navy Hero / Warm Heart / Semantic Split per slide.
13. ❌ **Red and navy directly adjacent with no buffer** — insert white, `surfWarm`, or `borderSoft` between them.
14. ❌ **Red on `navy` for super titles** — use `redSoft` (`F7978D`) instead. `red` on `navy` is a vibration trap.

### Asset-Provenance Anti-Patterns

15. ❌ **Self-drawn hearts** — generating a heart in PIL, cairosvg, ImageMagick, SVG, or any other code path. The CVS Heart is bundled in `assets/marks/` as `heart_solid_red_reg.png` (and white/outline variants). Hand-drawn approximations miss the curvature and lobe proportions of the real asset and read as off-brand on inspection.
16. ❌ **Self-drawn logos** — never compose the wordmark from system fonts. Fetch the official logo bundled in the Everyday Template.
17. ❌ **Primitive-built icons without documented fetch failure** — Recipe 8's primitive icons (`iconCross`, `iconChart`, `iconPerson`, `iconGear`) are not the default and not a stylistic choice. They are a fallback, and falling back without showing the work (URI tried, error received) ships off-brand work invisibly.
18. ❌ **Scratch-built cover slides** — covers come from the Everyday Template's 6 built-in cover layouts (`Title Slide` through `Title Slide 6`), guided by `references/cover-registry.md`. After slide-stripping, there are no "slides 4–9" — the cover is added via `get_layout(prs, 'Title Slide')` (or the numbered variant). These 6 are the only covers this skill supports; composing one from scratch is a hard build failure.
19. ❌ **Skipping local-asset verification** — proceeding to build code without first loading `assets/manifest.json` and verifying each `must_bundle` asset exists on disk. If an asset is missing, use the manifest's `source_uri` to fetch from SharePoint as a documented fallback — don't silently omit it or substitute a self-generated version.

20. ❌ **Adding slides without using `prs.slide_layouts`** — calling `prs.slides.add_slide()` with anything other than a layout drawn from `prs.slide_layouts` on the same `prs` object. Slides added any other way don't inherit the CVS master and PowerPoint won't recognize the output as a CVS-themed presentation. Always use `get_layout(prs, 'Layout Name')` as shown in the Template Foundation section.

21. ❌ **Skipping the slide-strip step** — harmless against the bundled template (0 content slides already), but if you're ever working from a freshly-pulled, unstripped copy, skipping this leaves all the original example slides in your output alongside the generated content.

22. ❌ **Hardcoding title font size as 32pt** — 32pt wraps a 60+ character title to three lines, overflowing the 0.9" box and colliding with body content. Always use `title_tier()` or `add_title()` from cvs_utils, or apply the three-tier table from QUICK_BUILD_REF.md manually. Hardcoded 32pt is only correct for titles under 40 characters.

23. ❌ **Using `blank_slide()` for every slide** — the master provides logo, confidentiality text, and page number for free on all `content_slide()` slides. Applying blank to everything suppresses the master footer and forces manual text-box recreations. Use `blank_slide()` only when no named layout fits the design.

24. ❌ **Using Blank layout for the cover** — the `Title Slide` layout has the CVS Health logo and red outline heart built in at the correct positions. Blank does not. Always use `cover_slide(prs, title, presenter)`.

25. ❌ **Calling `add_footer()` or `add_confidentiality_text()` on `content_slide()` slides** — these functions are for `blank_slide()` only. Calling them on master-inheriting slides creates duplicate footer elements.

### AI-Generated-Deck Anti-Patterns (avoid these or output looks like generic AI work)

26. ❌ All-rectangles with no use of `HEXAGON` / `TRAPEZOID` / `CHEVRON`
27. ❌ Three-column layouts where every column is identically styled — vary one (e.g., make column 3 the hero)
28. ❌ Footer that says "CVS Health" without the heart bug
29. ❌ Cover slide built from scratch with just centered text — a "Word document title page" is not a CVS cover
30. ❌ Stacked rectangles labeled as a "funnel" — use a real `TRAPEZOID` with `rotate: 180`
31. ❌ "Beige" decks: navy/gray with no red emphasis anywhere — red must appear on every slide
32. ❌ Bullet lists for content the inspiration patterns prescribe as visual layouts (journey, RACI, 30-60-90)
33. ❌ Text-only solutions to outlines that explicitly mention diagrams, funnels, or hexagons
34. ❌ Closing slide that doesn't echo the cover's hero element (heart, big stat, etc.)
35. ❌ Body slides where the most prominent element is also the smallest text (no typographic hierarchy)
36. ❌ **Zero icons across the whole deck** — the icon index exists for a reason; aim for ~1 in 3 content slides to carry a glyph
37. ❌ **Parallel text blocks (3 columns, 4 quadrants) without matching icons** — icons unify the layout; missing icons here is a design oversight
38. ❌ **Hearts that look like Valentine's Day** — the most common cause is `MSO_SHAPE.HEART` repeated as decoration; the second is using red and pink hearts together (don't); the third is hand-drawn hearts in PIL
39. ❌ **Red showing up at >10% of the visible slide area** — break the 60/30/10 rule and the slide reads as aggressive

---

## Workflow

### Creating from scratch
1. **Run the Pre-flight Sequence** (see top of this file). If any local asset is missing, follow the documented-fallback path and capture for the Asset Provenance section of your final response.
2. Read base pptx skill → `SKILL.md`
3. Read `references/CVS_Slide_Style_Guide.md` §5 for slide element specs and code recipes
4. **Open the template via `open_template()`** (from `cvs_utils.py`) — strips content slides, preserves the CVS master. Never start from a blank `Presentation()`.
5. **Insert the cover** — add via `cover_slide(prs, title, presenter)` (defaults to the `Title Slide` layout) or `get_layout(prs, 'Title Slide 4')` for a specific one of the 6 built-in variants, per `references/cover-registry.md`'s Quick-Match guide.
6. **Plan the slide sequence** — for each slide of content:
   - Check `references/inspiration-patterns.md` first — if the content matches a named pattern (exec summary, portfolio status, 30-60-90, RACI, etc.), use that recipe to structure the content
   - Then check `references/slide-layout-registry.md` for the right structural layout from the Everyday Template or Chart Library (note the 🟦/🟧 source column)
   - Build from the named layout via `content_slide()` / `get_layout()`; never build a layout from scratch if a template equivalent exists. (The bundled template's example content slides were removed — build from layouts, not duplicated example slides; see Changelog.)
7. **Select icons** — look up `assets/icon-index.json` (see `references/icon-cheat-sheet.md` for intent → label mapping) and copy the vector shape from `assets/libraries/Iconography_Library_01_2026.pptx` per the Icon copy recipe. No pictogram library is bundled — use icons for all glyph needs.
8. **Populate content** — replace placeholder text in duplicated slides; set all text to CVS Health Sans; follow typography specs from the style guide.
   - Call `drop_unused_placeholders(slide)` at the end of each slide's build — some layouts carry a body placeholder that `content_slide()` + `add_title()` never touches, and left empty it renders as a "Click to add text" prompt in an editor.
9. **Append a closing slide** — pick one of the built-in closing layouts (`Next steps`, `In closing`, `Closing slide`, `Closing slide option`) per `references/slide-layout-registry.md` → CLOSING LAYOUTS.
10. Run QA (see below)

### Editing an existing deck
1. Read base pptx skill → `SKILL.md`
2. Extract text + generate thumbnails to audit current state
3. Identify brand violations against the checklist below
4. Apply fixes, then re-verify

---

## QA Checklist (run before every delivery)

**Asset Provenance Audit — run this first:**
- [ ] The strip loop ran and `len(prs.slides) == 0` before the first `add_slide()` — true trivially on the bundled template (0 content slides already) and by design if you ever start from an unstripped copy
- [ ] Every slide was added via a factory helper (`cover_slide()`, `content_slide()`, `blank_slide()`) — not raw `prs.slides.add_slide()`
- [ ] **Cover uses `cover_slide()`** — not Blank layout. The Title Slide layout has the CVS logo and heart built in; Blank does not.
- [ ] **Content slides use `content_slide()`** — master provides logo, confidentiality text, and page number automatically. `add_footer()` and `add_confidentiality_text()` were NOT called on these slides.
- [ ] **`blank_slide()` used sparingly** — only for slides where no named layout fits. If all slides are Blank, something went wrong.
- [ ] **Title sizing is adaptive** — `add_title()` used; `CONTENT_Y` taken from its return value. No hardcoded 32pt on titles ≥ 40 characters.
- [ ] Footer zone clean — no double footers on any slide. Content slides inherit master footer; Blank slides manage their own.
- [ ] Every heart in the deck was loaded from `assets/marks/heart_*.png` — no PIL/SVG/cairosvg-drawn hearts
- [ ] The CVS logo in the footer was loaded from `assets/marks/cvs_logo.png` — no hand-composed logos from system fonts
- [ ] Every icon was loaded from `assets/libraries/Iconography_Library_01_2026.pptx` via the index — no primitive-built icons unless paired with a documented missing-asset gap. Icons recolored with `recolor_icon()` after copy.
- [ ] Cover slide added via `get_layout(prs, 'Title Slide')` or variant — not copied from a content slide
- [ ] If any answer above is "no," the final response includes an Asset Provenance section documenting the gap, the fallback used, and a recommendation

**Visual cohesion (the difference between great and generic):**
- [ ] Cover slide features a distinctive visual element (heart, large stat, image area) — not just centered text
- [ ] Closing slide echoes the cover's hero element — visual rhyme across the deck
- [ ] At least one recurring motif used across 2+ slides (heart, hexagon, red accent bars, etc.)
- [ ] Red appears as an accent on every slide — no "beige" navy/gray-only slides
- [ ] Each slide has a clear typographic hierarchy: a hero element (number, stat, quote) larger than everything else
- [ ] Layouts vary across slides — not the same template repeated
- [ ] Outline-specified visuals (funnel, hexagon, journey, etc.) are built as named, not substituted with generic columns
- [ ] Card shadows are consistent across the deck (one shadow style, used everywhere)
- [ ] Semantic colors (green/amber) only appear where content has clear positive/opportunity axis — not as decoration

**Color discipline:**
- [ ] Each slide built against a named palette scheme (White Editorial / Navy Hero / Warm Heart / Semantic Split)
- [ ] Red and navy never share a large border — white, `surfWarm`, or `borderSoft` always buffers them
- [ ] Super titles on navy backgrounds use `redSoft` (`F7978D`), not `red` (`CC0000`)
- [ ] Red occupies roughly ≤10% of the visible slide area (60/30/10 dominance check)
- [ ] No mixing of palette schemes within a single slide

**Heart usage:**
- [ ] All brand-mark hearts come from `assets/marks/heart_*.png` — `MSO_SHAPE.HEART` not used as the brand mark anywhere; no hand-drawn approximations
- [ ] Hearts appear on cover and closing only (unless content is heart-health-related, in which case anatomical icon from icon-registry)
- [ ] No row/scatter of hearts as decoration (Valentine's Day anti-pattern)

**Iconography cadence:**
- [ ] Roughly 1 in 3 content slides includes an icon
- [ ] Slides with parallel text blocks (3 columns, 4 quadrants) have a matching icon set drawn from a single category, single style (all outline OR all filled, not mixed)
- [ ] Icons used at stat callouts, pillar tiles, or section strips — not scattered as decoration

**Brand compliance:**
- [ ] Every content slide has CVS logo bottom-right
- [ ] Every content slide has confidentiality text + page number bottom-left
- [ ] Cover slide has CVS logo top-left (not bottom, not top-right)
- [ ] All titles use `3F3F3F`, not `000000`
- [ ] Super titles are CVS red (`CC0000`), sentence case, not ALL CAPS
- [ ] Font is `CVS Health Sans` throughout
- [ ] Backgrounds are white or CVS navy only (no cream, beige, gray, or other)
- [ ] No accent lines under titles
- [ ] No full-width header/footer color stripes (except cover/closing)
- [ ] Nothing below y = 6.9″ (footer zone)
- [ ] No emojis; icons in CVS red (or white on navy)
- [ ] Charts use CVS chart color sequence, not Office defaults
- [ ] Tables: navy header with white uppercase text; alternating row fill

**Technical QA (from base pptx skill):**
- [ ] No text overflows its container
- [ ] No overlapping elements
- [ ] Visual inspection via thumbnail / PDF render
- [ ] Footer zone consistent across all slides — no double footers, no missing page numbers
- [ ] **Every real placeholder (`slide.placeholders[...]`) that isn't intentionally left blank has been written into directly, or removed via `drop_unused_placeholders(slide)`** — not covered by a floating textbox drawn on top of it. A flattened PNG/PDF render won't show a leftover empty placeholder, but opening the file in an editor (PowerPoint, LibreOffice, Google Slides) will: it renders the placeholder's dashed outline and either the layout's inherited default text (if never written into — see the Changelog's placeholder-ghosting entry) or a generic "Click to add text" prompt (if written-around, e.g. a body placeholder left over on a `content_slide()` + `add_title()` build) behind whatever was drawn over it. Call `drop_unused_placeholders(slide)` at the end of every slide build to clear the latter case. Spot-check by inspecting `slide.placeholders` on a couple of built slides, not just by rendering to an image.
---

## Related skills — route, don't duplicate

This skill is self-contained: it takes no dependency on any other skill, imports nothing from
one, and works if none of them are installed. Routing is not a dependency — it is a sentence you
say when a request has wandered outside this skill's job.

Stay silent about these unless the user's request crosses into their territory. When it does,
name the skill and offer it:

- Raw project data that needs to be **structured before it can be designed** — KPIs, health
  ratings, a risk register, decisions outstanding → **status-report** first, then build the deck
  from its output
- A written narrative aimed at one audience rather than a presentation → **stakeholder-update**
- One decision needing options and a recommendation, as a document rather than slides →
  **decision-brief**
- A standalone rated risk register → **risk-assessment**
- Headcount or capacity modelling → **capacity-plan**
- An interactive, filterable view of live data rather than static slides → **build-dashboard**

**When another skill routes a user here**, that skill has already produced the content. Do not
re-interview the user or restructure what they were given: treat the incoming document as the
outline, confirm the audience and formality if the cover choice is ambiguous, and go straight to
the Pre-flight Sequence. The content decisions belong to the skill that made them; the brand and
layout decisions are yours.


---

## Output Contract

Every build of this skill hands back:
- **The finished deck** — delivered per the surface you identified in "Environment — detect the surface before acting": on **Claude Chat** a `.pptx` saved to `/mnt/user-data/outputs/` and shared via `present_files`; on **Claude Code** a `.pptx` in the working directory with the absolute path stated; on **Claude in PowerPoint** the user's own open deck, edited in place — there is no file to hand back, and you say what you changed instead.
- **An Asset Provenance section**, only when a local asset was missing and a fallback was used — see "Asset Provenance — Local-First Model" above for what it must include. Omitted entirely on a normal build where every `must_bundle` asset was present.
- **An explicit note if any QA Checklist item failed and wasn't fixed before delivery** — never deliver silently with a known issue.

Nothing else is implied: this skill does not send emails, post to chat tools, or write back to SharePoint on its own.

---

## Accessibility

- Every slide must have a title in the standard position (for screen readers)
- Body text minimum 13 pt; footnotes minimum 10 pt (11 pt for Medicare-facing)
- Never rely on color alone to convey meaning — pair with labels or icons
- Every `add_picture()` call for a meaningful (non-decorative) image should set alt text via the picture's `_element` (e.g. its `nvPicPr.cNvPr` `descr` attribute) so screen readers pick it up

---

## Rendering Pitfalls

- Set `word_wrap` explicitly on text frames that need precise alignment — python-pptx's default wrapping can throw off careful positioning
- Build a fresh `RGBColor` / options each time rather than reusing a mutable object across shapes — safer than assuming any particular call mutates in place
- Don't use `MSO_SHAPE.ROUNDED_RECTANGLE` for accent bars — use `MSO_SHAPE.RECTANGLE`
- Hex colors go through `RGBColor.from_string("CC0000")` or `RGBColor(0xCC, 0x00, 0x00)` — no `#` prefix either way

---

## Full Style Reference

→ `references/CVS_Slide_Style_Guide.md`

Sections to read for specific tasks:
| Need | Section |
|---|---|
| Full color token list | §2 |
| Type scale details | §3 |
| Layout grid + margins | §4 |
| Slide element specs + code | §5 |
| Visual motif code examples | §6 |
| Things to avoid | §7 |
| Slide-type recipes | §8 |
| Icon rendering | §9 |
| Accessibility | §10 |
| Quality checklist | §11 |

---

## Changelog

See `references/CHANGELOG.md` for the full version history (v0.1 GA through v0.1.2).

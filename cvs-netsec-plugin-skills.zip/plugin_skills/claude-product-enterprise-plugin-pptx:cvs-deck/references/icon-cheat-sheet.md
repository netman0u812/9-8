# Icon Intent → Label Cheat Sheet

> 50 most-used intents with their exact label strings for the CVS icon library.
> All labels are for the **outline** variant (default). For filled, pass `variant='filled'`.
> If your intent isn't listed, check `references/icon-registry.md` for the full category list,
> then use `find_icon(label)` to verify the label exists before building.

## Usage
```python
copy_icon(slide, 'Stethoscope', x=0.5, y=content_y, w=0.5, h=0.5)
# or: row = find_icon('Stethoscope')  # verify first
```

## Intent → Label map

| Intent | Exact label string | Category |
|---|---|---|
| Prescription / Rx | `Rx bottle` | Health care |
| Rx refill | `Rx bottle refill` | Health care |
| Rx transfer | `Rx bottle transfer` | Health care |
| Rx bag / pickup | `Prescription bag` | Health care |
| Mail-order pharmacy | `Mailbox with Rx` | Health care |
| Medication adherence | `Adherence` | Health care |
| Specialty drug | `Specialty medicine` | Health care |
| Pill / capsule | `Pill capsule` | Health care |
| Drug interaction | `Drug interaction` | Health care |
| Pill dispenser / packaging | `Multi-dose packaging` | Health care |
| Stethoscope / clinical | `Stethoscope` | Health care |
| Pharmacy building | `Pharmacy building` | Health care |
| Prescriber / doctor | `Prescriber` | Health care |
| Drug utilization review | `Drug utilization review (DUR)` | Health care |
| Heart (organ / cardiac) | `Heart` | Health care |
| Mental health | `Mental health` | Health care |
| Brain / neurology | `Brain` | Health care |
| Lungs / respiratory | `Lungs` | Health care |
| Diabetes / glucose | `Glucose monitor` | Health care |
| Blood pressure | `Blood pressure gauge` | Health care |
| Injection / vaccine | `Injection` | Health care |
| Infusion / IV | `Infusion bag` | Health care |
| Patient / member | `Patient or member` | People |
| Family | `Family 1` | People |
| Caregiver | `Hand with heart` | Health care |
| Telemedicine (phone) | `Telemedicine phone` | Technology |
| Telemedicine (laptop) | `Telemedicine laptop 1` | Technology |
| Member card / ID | `Member card` | Health care |
| COVID / virus | `COVID virus` | Health care |
| Bar chart / data viz | `Bar chart` | Business |
| Growth / trend up | `Growth chart` | Business |
| Line chart | `Line chart` | Business |
| Research / analytics | `Research` | Business |
| Medical data | `Medical data` | Business |
| Medical file / record | `Medical file` | Health care |
| Clipboard / checklist | `Clipboard with check list` | Business |
| Calendar / appointment | `Calendar` | Utilities |
| Clock / time | `Clock` | Lifestyle |
| Alert / notification | `Bell` | Lifestyle |
| Check / complete | `Check circle` | Messaging |
| Lock / security | `Lock` | Technology |
| Settings / gear | `Gear` | Utilities |
| Map pin / location | `Map pin` | Utilities |
| Flag / milestone | `Flag` | Messaging |
| Group / team | `Group of people` | People |
| Network / connection | `Network 1` | Business |
| Handshake / partnership | `Handshake` | Health care |
| Retail store | `Retail store` | Retail |
| Shopping cart | `Shopping cart` | Retail |
| Savings / coupon | `Coupon savings 1` | Retail |
| Dollar / cost | `Dollar symbol` | Retail |
| Wallet / payment | `Wallet` | Retail |
| Shipping / delivery | `Shipping` | Retail |

## On a miss

If `find_icon()` returns `None`:
1. Check `references/icon-registry.md` for the category and browse nearby labels
2. Try adjacent terms: 'Patient 1', 'Patient 2' — many icons have numbered variants
3. Use `find_icon()` with a partial word: scan `idx['icons']` for `row[0].lower().startswith('...')`
4. If no match exists, document the gap in Asset Provenance and use the nearest available icon
   rather than building a primitive. Never substitute a generic shape for a missing icon silently.

# CVS Health Slide Style Guide

A complete design specification for generating CVS Health-branded slide decks programmatically via python-pptx, matching the official CVS Health Everyday Template.

---

## 1. Purpose & Scope

This guide encodes the visual language of the **CVS Health Everyday Widescreen Template**. Follow it when generating slide decks for internal or external CVS use. It covers colors, typography, layout grids, component patterns, and rules for common slide types.

**Output format**: 16:9 widescreen (13.333″ × 7.5″). Always use this aspect ratio.

**Required asset**: The CVS Health logo (PNG). Extract it from any CVS template deck or use the official brand center logo. Store it at a known path and reference it on every content slide.

---

## 2. Brand Colors

Use these exact hex values. Never substitute similar shades.

### Primary palette
| Token | Hex | Usage |
|-------|-----|-------|
| `cvs-red` | `CC0000` | Primary accent — super titles (eyebrows), icons, accent bars, highlight stats, call-to-action elements |
| `cvs-red-dark` | `9E0000` | Hover/pressed states, secondary red emphasis |
| `cvs-red-soft` | `F7978D` | Red super titles on dark navy backgrounds (for contrast) |
| `cvs-navy` | `0B315E` | Dark slide backgrounds (dividers, cover variants, headline slides) |
| `cvs-navy-deep` | `081F3F` | Card backgrounds on navy slides |
| `cvs-blue` | `0A4B8C` | Secondary accent — numbered circles, chart colors, data viz |
| `cvs-teal` | `00787E` | Chart series color (secondary) |
| `cvs-teal-light` | `00A78E` | Chart series color |

### Neutrals (required for text and surfaces)
| Token | Hex | Usage |
|-------|-----|-------|
| `cvs-text-gray` | `3F3F3F` | Primary title color, main body text. **Never use pure black (`000000`) for titles.** |
| `cvs-gray-medium` | `646464` | Secondary body text, descriptions |
| `cvs-gray-light` | `868686` | Tertiary labels, captions |
| `cvs-gray-silver` | `A5A5A5` | Disabled or de-emphasized text |
| `cvs-gray-border` | `C0C0C0` | Borders, dividers |
| `cvs-gray-surface-dark` | `E9E9E9` | Shaded row backgrounds, secondary surface |
| `cvs-gray-surface` | `F7F7F7` | Card backgrounds, alternating table rows |
| `cvs-white` | `FFFFFF` | Primary background, text on dark slides |

### Chart colors (for bar/line/pie charts)
Use this ordered sequence when rendering chart data series:
1. `267AC0` (blue)
2. `00787E` (teal)
3. `00A78E` (mint)
4. `868686` (gray — "other")
5. `61A515` (green)
6. `487A10` (dark green)
7. `F4642A` (orange)
8. `CE430C` (dark orange)
9. `E94D4D` (red)
10. `7D3F98` (purple)

### Heat map / status tiers (if needed)
For semantic green-to-red progressions (e.g., scoring, exposure, risk):
| Tier | Hex | Description |
|------|-----|-------------|
| High / best | `C8E6C9` | Soft green |
| Med-High / good | `DCEDC8` | Pale green |
| Medium / neutral | `FFF9C4` | Pale yellow |
| Med-Low / caution | `FFCCBC` | Pale coral |
| Low / attention | `EF9A9A` | Soft red |

### Color rules
- **Never use a `#` prefix with hex values** in python-pptx — pass 6-char strings like `"CC0000"` to `RGBColor.from_string()`, or `RGBColor(0xCC, 0x00, 0x00)`.
- **One color dominates**: CVS red is the visual anchor. Navy is for dark slides only. Gray handles everything else.
- **Avoid defaulting to cream or beige backgrounds.** Use white (`FFFFFF`) or the palette above.
- **Text contrast**: On white backgrounds, use `cvs-text-gray` (`3F3F3F`) for titles, never pure black. On navy backgrounds, use white for titles and `cvs-red-soft` (`F7978D`) for super titles (pure red on navy has poor contrast).

---

## 3. Typography

### Font family
- **Header + body**: `CVS Health Sans`
- This is a proprietary CVS typeface. Always specify it in your code. When rendering on non-CVS machines, it falls back to a system sans-serif — that's fine because the PPTX file still carries the correct font specification for when a CVS user opens it.
- **Never substitute** with Arial, Calibri, or similar unless explicitly asked.

### Type scale
| Element | Size | Weight | Color |
|---------|------|--------|-------|
| Cover title | 44–48 pt | Bold | `cvs-text-gray` |
| Slide title (interior) | **32pt** (< 40 chars) · **26pt** (40–65) · **22pt** (65–90) | Bold | `cvs-text-gray` |
| Section header | 20–24 pt | Bold | `cvs-text-gray` |
| Super title / eyebrow | 13–15 pt | Bold | `cvs-red` (light bg) or `cvs-red-soft` (dark bg) |
| Body text | 13–14 pt | Regular | `cvs-gray-medium` |
| Large stat / callout number | 44–80 pt | Bold | `cvs-red` |
| Table header | 9–10 pt | Bold | White on navy |
| Table body | 10–11 pt | Regular | `cvs-text-gray` |
| Footnote / caption | 9–10 pt | Regular or italic | `cvs-gray-light` |
| Footer (confidentiality) | 9 pt | Regular | `cvs-gray-light` |

### Typography rules
- **Super titles (eyebrows) use sentence case**, not ALL CAPS. Example: "A discovery analysis", not "A DISCOVERY ANALYSIS". CVS avoids heavy letter-spacing.
- **Column and section headers within a slide** may use uppercase with slight letter-spacing (`charSpacing: 1–2`) — but never for the slide's main super title.
- **Titles left-align** — do not center slide titles.
- **Body paragraphs left-align** — do not center body text. Only center titles in cover/divider slides if using a centered divider layout.
- **Avoid italics for body copy.** Use italics only for captions, footnotes, and emphasis.
- **Never underline** for emphasis (underlines are reserved for hyperlinks in the CVS brand).
- Minimum footnote size: 10 pt for commercial/member-facing decks, 11 pt for Medicare/member-facing decks.

---

## 4. Layout Grid

All content lives on a 10″ × 5.625″ safe area within the 13.333″ × 7.5″ slide.

### Standard margins
- **Left margin**: 0.5″
- **Right margin**: 0.5″
- **Top margin**: 0.4″ (for super title) or 0.75″ (for title when no super title)
- **Bottom margin**: 0.5″ (above footer)

### Footer zone (reserved)
- **Bottom 0.6″ of every content slide** is reserved for the footer.
- Footer contains: page number + confidentiality text on bottom-left; CVS Health logo on bottom-right.
- **Never place slide content below y = 6.9″** or it will collide with the footer.

### Content zone
- Usable vertical space for content: y = 1.6″ to y = 6.9″ (approx. 5.3″ tall).
- Usable horizontal space: x = 0.5″ to x = 12.83″ (approx. 12.33″ wide).

---

## 5. Required Slide Elements

### 5.1 Super title (eyebrow) + title block

Every content slide begins with this pair. **Title font size is adaptive** — hardcoding 32pt causes overflow on descriptive titles and is the most common first-QA-loop cause.

#### Adaptive title sizing

| Title length | Font size | Title box height | `CONTENT_Y` (body starts at) |
|---|---|---|---|
| < 40 chars | **32pt** | 0.90" | **1.80"** |
| 40–65 chars | **26pt** | 1.30" | **2.18"** |
| 65–90 chars | **22pt** | 1.60" | **2.55"** |

`CONTENT_Y` is the y-coordinate where body content begins. **Always derive it from the title tier — never hardcode 1.6.**

#### Implementation (python-pptx — use cvs_utils)
```python
# Recommended: use add_title() from cvs_utils.py — handles tiers automatically
content_y = add_title(slide, "Your slide title here", eyebrow="Section name")
# content_y is now the correct y for body content
```

On dark (navy) slides, swap colors:
- Super title: `"F7978D"` (soft red — better contrast on navy than pure red)
- Title: `"FFFFFF"` (white)

### 5.2 Footer (every content slide)

**Default: inherited automatically.** A slide built via `content_slide()` gets the page number, confidentiality text, and CVS Health logo for free from the slide master — do not add any of them manually. This is the common case for every standard content slide.

**Exception: `blank_slide()` only.** If a slide suppresses the master (`blank_slide()`), the three footer elements disappear and must be added back manually via `cvs_utils.py`:
```python
slide = blank_slide(prs)          # suppresses master — footer elements gone
add_confidentiality_text(slide)   # positions match master: x=0.94", y=7.03"
add_footer(slide, page_num)       # page number + logo matching master positions
```
`add_footer()` and `add_confidentiality_text()` exist for this one case. Calling either on a `content_slide()` slide creates a duplicate footer.

Update the copyright year in the confidentiality text to match the current year — `add_confidentiality_text()` assembles it at runtime rather than hardcoding a year.

### 5.3 Cover slide pattern

Cover slides **do not use the standard super title / title block**. Instead:
- CVS Health logo top-left at `(0.5, 0.5)`, size `1.6 × 0.6`
- Super title (sentence case, red) at y ≈ 1.8″
- Large cover title (44–48 pt bold, dark gray) starting at y ≈ 2.25″, often spanning 2 lines
- Subtitle (18–20 pt, medium gray) below title at y ≈ 4.3″
- Presenter/context info at y ≈ 5.3″
- Footer: only the confidentiality text, no page number, no logo in bottom-right (logo is already top-left)

### 5.4 Divider slide pattern (navy)

Full-bleed navy background (`0B315E`). Used for section breaks.
- Optional small white horizontal rule centered above the title
- Section title centered, white, 32–44 pt bold
- Optional small white horizontal rule centered below
- No footer on dividers

---

## 6. Visual Motifs

### 6.1 Left accent bar
A common CVS pattern: a thin vertical red bar on the left edge of callout boxes, quotes, or emphasized content blocks.

```python
# 0.08" wide red bar, full height of the callout — rct() from cvs_utils.py
rct(slide, x=0.5, y=callout_y, w=0.08, h=callout_height, fill_color=CVS_RED)
```

### 6.2 Top accent bar on cards
For cards/tiles that need a subtle brand signal, use a thin red bar across the top:
```python
rct(slide, x=card_x, y=card_y, w=card_width, h=0.08, fill_color=CVS_RED)
```

### 6.3 Numbered circles
For numbered lists (recommendations, steps, findings):
- Circle in CVS Navy (`0B315E`) or CVS Blue (`0A4B8C`), diameter 0.4–0.5″
- Number inside in white, bold, CVS Health Sans, 16–18 pt, centered

```python
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN

circle = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x), Inches(y), Inches(0.5), Inches(0.5))
circle.fill.solid()
circle.fill.fore_color.rgb = CVS_NAVY
circle.line.fill.background()
tb(slide, "1", x, y, w=0.5, h=0.5, size=18, bold=True, color=CVS_WHITE, align=PP_ALIGN.CENTER)
```

### 6.4 Question marks (for discussion prompts)
For open-question slides, use a red-outlined circle with a red "?":
```python
circle = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x), Inches(y), Inches(0.45), Inches(0.45))
circle.fill.solid()
circle.fill.fore_color.rgb = CVS_WHITE
circle.line.color.rgb = CVS_RED
circle.line.width = Pt(2)
tb(slide, "?", x, y, w=0.45, h=0.45, size=18, bold=True, color=CVS_RED, align=PP_ALIGN.CENTER)
```

### 6.5 Section header strips
Horizontal strips (navy or red) to introduce a column or grouping:
- Height: 0.35–0.45″
- Fill: `cvs-navy` for primary, `cvs-red` for secondary emphasis
- Text: white, uppercase, 10–13 pt bold, letter-spaced, centered vertically

### 6.6 CVS heart logo
The red heart is iconic to CVS. You may use a large outlined heart as a decorative element on cover slides (right half of the slide). Source it from the bundled `assets/marks/` PNGs. Do not redraw it.

---

## 7. Things to AVOID (these signal off-brand or AI-generated slides)

1. **Full-width colored bars at the very top or bottom of the slide** (header/footer stripes). CVS slides don't use these.
2. **Accent lines under titles** (e.g., a 2px red line beneath every title). CVS uses whitespace or a super title for hierarchy, not underlines.
3. **Cream, beige, or warm-neutral backgrounds.** Backgrounds are white or navy only.
4. **Pure black text.** Always use `cvs-text-gray` (`3F3F3F`) instead.
5. **Defaulting to blue** as the primary accent. Red is CVS's accent; blue is secondary.
6. **Heavy letter-spacing on titles.** Only use slight `charSpacing` on small section labels.
7. **Serif fonts** for headers. CVS Health Sans is a sans-serif family.
8. **Centered body text.** Only titles on cover/divider slides are centered.
9. **Emojis in content.** CVS uses professional iconography (vector-copied from the bundled Iconography Library, rendered in CVS red), not emojis.
10. **Rounded rectangles for accent elements** when a sharp rectangle will do. CVS cards are sharp-cornered with subtle borders.

---

---

## 8. Slide-type Recipes

### 8.1 Cover slide
- White background
- CVS logo top-left
- Red super title (sentence case)
- Large dark-gray title (44–48 pt, may span 2–3 lines)
- Subtitle in medium gray
- Presenter block at y ≈ 5.3 (name, title, date)
- Optional: large red outlined heart on right half of slide as decoration
- Footer: confidentiality text only (bottom-left), no page number, no bottom-right logo

### 8.2 Section divider (navy)
- Full-bleed navy background
- No super title, no footer
- Optional small white horizontal rule above title
- Centered white title at 32–44 pt bold
- Optional small white horizontal rule below title

### 8.3 One-column content slide
- White background
- Super title + title at top
- Single column of content, max 2/3 page width (8″), left-aligned
- Body 13 pt regular in `cvs-gray-medium`
- Bullets: use `bullet: true`, never Unicode `•` symbols (which create double bullets)
- Optional footnote block at bottom (above footer), introduced by a small red arrow or red vertical bar

### 8.4 Two- or multi-column layout
- Super title + title at top
- 2–5 columns of equal width with gaps of 0.1–0.15″
- Each column may have its own red top accent bar
- Use `cvs-gray-surface` (`F7F7F7`) as card background, `cvs-gray-border` (`C0C0C0`) as card border

### 8.5 Data / table slide
- Header row: navy (`0B315E`) fill, white text, 10 pt bold uppercase with `charSpacing: 1`
- Alternating row fill: `cvs-gray-surface` (`F7F7F7`) on even rows, white on odd
- Body text 10–11 pt in `cvs-text-gray`
- Key identifiers (like row codes) in `cvs-red` bold

### 8.6 Stat callout
- For a big headline number: 60–80 pt bold in `cvs-red`
- Label in 16–18 pt bold in `cvs-text-gray` below
- Description in 11–12 pt in `cvs-gray-medium` below that

### 8.7 Quote / emphasized callout
- Full-width light-gray surface box (`F7F7F7`)
- Red vertical accent bar on the left edge (0.08″ wide)
- Inside: red prefix label (bold) + body text in dark gray
- Example: `"Observation:  High exposure does not mean 'AI should do this'..."`

---

## 9. Icon Guidelines

- **Use icons in CVS red** (`CC0000`) on white backgrounds and **white** on navy.
- **Copy vector shapes from the bundled Iconography Library** (`assets/libraries/Iconography_Library_01_2026.pptx`), looked up by label via `assets/icon-index.json`. Do not rasterize to PNG — vector shapes scale perfectly at any size, stay editable (fill color, stroke weight), and never introduce rasterization blur.
- Standard icon size in content cards: 0.55–0.6″ square.
- Do not use emojis in place of icons.

Example (`copy_icon()` from `cvs_utils.py`):
```python
copy_icon(slide, label="Lightbulb", variant="outline",
          x=1.0, y=2.0, w=0.6, h=0.6, color_hex="CC0000")
```

---

## 10. Accessibility Requirements

CVS templates are accessibility-tested. Preserve these properties:

- **Every slide must have a slide title** in the standard title placeholder location (top-left). This is how screen readers navigate decks.
- **Color contrast**: body text against backgrounds must meet WCAG AA minimum (4.5:1 for regular text, 3:1 for large text). The standard palette above is compliant — don't introduce lighter grays for body text.
- **Don't rely on color alone** to convey meaning. Pair color with icons, labels, or shapes (e.g., heat map tiers always show both a color chip AND the label text).
- **Alt text**: for every meaningful (non-decorative) picture, set alt text via the picture's `_element` (e.g. its `nvPicPr.cNvPr` `descr` attribute). Especially important for charts, diagrams, and icons used meaningfully.
- **Font sizes**: body text never smaller than 13 pt. Footnotes never smaller than 10 pt (11 pt for Medicare-facing content).

---

## 11. Quality Checklist (before shipping a deck)

Run through this before delivering a CVS-branded deck:

- [ ] Every content slide has the CVS logo in the bottom-right
- [ ] Every content slide has the confidentiality text + page number in the bottom-left
- [ ] Cover slide has the CVS logo top-left, not top-right or bottom
- [ ] All titles use `cvs-text-gray` (`3F3F3F`), not pure black
- [ ] Super titles are CVS red, sentence case, not ALL CAPS
- [ ] Font specified as `CVS Health Sans` throughout (it's fine if your local preview shows a fallback — the PPTX carries the spec)
- [ ] Backgrounds are white or CVS navy only (no cream, no beige)
- [ ] No accent lines directly beneath titles
- [ ] No full-width header or footer color stripes
- [ ] No decorative elements below y = 6.9″ (they'd collide with the footer)
- [ ] No emojis; icons are rendered in CVS red (or white on navy)
- [ ] Charts use the CVS chart color sequence, not default Office colors
- [ ] Tables use navy headers with white uppercase text
- [ ] No text overflows its containing shape
- [ ] Copyright year in footer is current

---

## 12. Quick Reference Card

```
PRIMARY ACCENT:   CC0000 (CVS red)
DARK BG:          0B315E (CVS navy)
TITLE COLOR:      3F3F3F (CVS text gray, NOT black)
BODY COLOR:       646464 (medium gray)
FONT:             CVS Health Sans
LAYOUT:           13.333 × 7.5 in (widescreen 16:9)

TITLE POSITION:   x:0.5, y:0.75, fontSize:32 bold
SUPER TITLE:      x:0.5, y:0.4, fontSize:13 bold red, sentence case
SAFE AREA:        y: 1.6 → 6.9
FOOTER ZONE:      y: 7.0 → 7.5 (reserved)

FOOTER LEFT:      "{page#}   [confidentiality notice — from slide master, or assembled at runtime per §5.2]" @ 9pt gray
FOOTER RIGHT:     CVS logo, 0.85 × 0.32 at x:12.08, y:7.05
COVER LOGO:       top-left at x:0.5, y:0.5, 1.6 × 0.6
```

---

*Derived from the CVS Health Everyday Widescreen Template (January 2026 release). Update this guide when the official template changes.*

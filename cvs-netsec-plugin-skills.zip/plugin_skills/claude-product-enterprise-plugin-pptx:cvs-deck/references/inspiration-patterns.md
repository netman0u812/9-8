# CVS Health Slide Inspiration Patterns
> Proven content patterns from real CVS Health business presentations.
> Source: `Slide Templates Retail Health 2026.pptx` — attribution only. This source deck is never fetched at build time (see "How to Use This File" below); its location isn't tracked anywhere in this package.

---

## How to Use This File

These are **content patterns**, not extractable assets. Unlike the icon or cover registries, do not fetch slides from the source file. Instead:

1. Identify which pattern fits the user's content need
2. Use the Everyday Template as the structural base (open the template, choose the closest layout from slide-layout-registry.md)
3. Organize the content following the pattern recipe below
4. Apply CVS brand styling per the style guide — note that internal presentations have **soft brand adherence**: exact color compliance is less critical than for external decks, but font, footer, and layout grid rules still apply

---

## Pattern Index

| # | Pattern Name | Best For | Source Slides |
|---|---|---|---|
| 1 | Executive Summary — Inform/Discuss/Align | Leadership briefings, meeting openers | 2–3 |
| 2 | Portfolio Initiative Status | Multi-initiative portfolio reviews | 3–5 |
| 3 | Weekly Status Dashboard | Recurring status updates, leadership syncs | 6–7 |
| 4 | Initiative Background & Business Case | Initiative kickoffs, funding requests | 8 |
| 5 | Quarterly Outlook | QBR openers, planning reviews | 9 |
| 6 | 30-60-90 Day Plan | Onboarding, new initiative launches, transitions | 13–18 |
| 7 | Strategic Action Plan | Problem-solving readouts, recovery plans | 74–76 |
| 8 | Patient / Member Journey Map | Care journey visualization, channel strategy | 93–94 |
| 9 | Closed-Loop Feedback Model | Process improvement, survey action frameworks | 96–97 |
| 10 | Funnel Diagram | Conversion funnels, pipeline views, process flows | 125–126 |
| 11 | Multi-Metric Operational Dashboard | Performance reporting, operational reviews | 115–117 |
| 12 | RACI Matrix | Workstream ownership, cross-functional clarity | 36 |

---

## Pattern 1 — Executive Summary: Inform / Discuss / Align

**Use when:** Opening a leadership meeting, framing a decision, or delivering a standalone read-and-go summary.

**Layout base:** Two-column (Template slide 21) or one-column (Template slide 19)

### Structure

```
┌─────────────────────────────────────────────────────┐
│  PURPOSE OF TODAY'S REVIEW                          │
│  ☐ Inform   ☐ Discuss   ☐ Align    (check 1–3)      │
├─────────────────┬───────────────────────────────────┤
│  Overview:      │  Key Insights:                    │
│  1–3 sentences  │  • Bullet 1                       │
│  on context     │  • Bullet 2                       │
│                 │  • Bullet 3                       │
├─────────────────┴───────────────────────────────────┤
│  Solution / Recommendation:                         │
│  1–2 sentences on proposed path forward             │
└─────────────────────────────────────────────────────┘
```

**Rules:**
- Purpose checkboxes (Inform / Discuss / Align) always appear at the top — this is the org's standard framing for meeting intent
- "Inform" = no decision needed; "Discuss" = input requested; "Align" = decision required
- Keep the Overview to context only — save analysis for Key Insights
- Recommendation is optional for Inform-only sessions
- Super title: use the meeting or initiative name
- Suitable as a standalone "read-and-go" one-pager

---

## Pattern 2 — Portfolio Initiative Status View

**Use when:** Reporting across multiple initiatives in a portfolio review or executive update.

**Layout base:** Table Style 1 (Template slide 49) extended with a status column

### Structure

```
┌──────────────────────────────────────────────────────────────────┐
│  FOCUS FOR TODAY                                                 │
│  Background: [1 sentence]    Summary: [1 sentence]               │
│  Next steps: [1 sentence]                                        │
│  Leadership Input:  ☐ Inform  ☐ Discuss  ☐ Decide               │
│  1 ✓   2 ✓   3 ✓   (numbered decision points)                   │
├────────────────────┬──────────┬──────────────────────────────────┤
│  Initiative        │  Status  │  Milestone                       │
├────────────────────┼──────────┼──────────────────────────────────┤
│  Initiative Name   │  🟢 Live │  Xx/xx — Next monthly results    │
│  • Description     │          │                                  │
│  • Value prop      │  🟡 Live │  Xx/xx — Enhancement launch      │
│  • Timeline        │          │                                  │
│                    │  🔴 Not  │  Mid-June — UAT begins           │
│                    │  live    │                                  │
└────────────────────┴──────────┴──────────────────────────────────┘
  Key: 🟢 Complete  🟢 On Track  🟡 On Watch  🔴 Off Track
```

**Rules:**
- Status column uses colored circles: green (complete/on track), yellow (on watch), red (off track)
- Always include the status key at the bottom of the table
- "Focus for Today" box sits above the table — framing what leadership needs to do with this information
- Numbered decision points (1 ✓ 2 ✓ 3 ✓) track decisions made in sequence
- Keep initiative descriptions to 3 bullets maximum: description, value prop, timeline

---

## Pattern 3 — Weekly Status Dashboard

**Use when:** Recurring weekly or bi-weekly leadership status update across multiple workstreams.

**Layout base:** Multi-column (Template slide 22 or 23), or build as a bordered table grid

### Structure

```
┌──────────────────────────────────────────────────────────────────┐
│  WEEK ENDING: MM/DD/YYYY                                         │
│  Status key: 🟢 On track  🟡 Potential risk / mitigations in    │
│  place  🔴 At Risk — leadership help needed                      │
├──────────┬──────────────────────────────────────────────────────-┤
│  Area    │  Summary of Required Changes   │  Key Headlines        │
│  (Owner) │                               │                       │
├──────────┼───────────────────────────────┼───────────────────────┤
│ Clinical │ 🟢  ✓ Update                  │ • Completed task      │
│ (Leader) │     ✓ Update                  │ • In progress task    │
│          │     ✓ Update                  │ • WATCH ITEM: TBD     │
├──────────┼───────────────────────────────┼───────────────────────┤
│ Ops      │ 🟡  ✓ Update                  │ • Completed task      │
│ (Leader) │     ✓ Update                  │ • In progress task    │
│          │     ✓ Update                  │ • WATCH ITEM: TBD     │
├──────────┼───────────────────────────────┼───────────────────────┤
│ Tech     │ 🔴  ✓ Update                  │ • Completed task      │
│ (Leader) │                               │ • WATCH ITEM: TBD     │
└──────────┴───────────────────────────────┴───────────────────────┘
```

**Rules:**
- Each row = one workstream or functional area, with the team leader named in parentheses
- RAG status dot appears at the start of each row's summary column
- "WATCH ITEM" callouts are always bold/highlighted — these are escalation flags
- Week-ending date always in the slide title or super title
- Checkmarks (✓) mark completed sub-items within each workstream update
- 4–6 workstreams per slide is ideal; split to two slides if more

---

## Pattern 4 — Initiative Background & Business Case

**Use when:** Introducing a new initiative, requesting funding or resources, or briefing stakeholders on a project.

**Layout base:** One-column (Template slide 19) with right panel for timeline

### Structure

```
┌────────────────────────────────┬────────────────────────────────┐
│  [INITIATIVE NAME]             │  Upcoming Milestones            │
│  Initiative Owner:             │                                 │
│                                │  April 2026 — Milestone        │
│  Initiative Description:       │  May 2026 — Milestone          │
│  [1–2 sentences]               │  June 2026 — Milestone         │
│                                │  July 2026 — Milestone         │
│  Value Proposition /           │                                 │
│  Problem Being Addressed:      ├────────────────────────────────┤
│  [1–2 sentences]               │  KPIs — [Time Period]          │
│                                │  Metric | Current | Target     │
│  What Must Be True:            │  ───────────────────────────── │
│  [conditions for success]      │  KPI 1  |   X    |    Y        │
│                                │  KPI 2  |   X    |    Y        │
│  Business Case:                │                                 │
│  [opportunity sizing,          ├────────────────────────────────┤
│  investment, assumptions,      │  Risks & Mitigation            │
│  confidence level]             │  Risk | Level | Mitigation     │
│                                │  ─────────────────────────────  │
│  Status: 🟢 On Track           │  Critical: Mitigating          │
│          🟡 Date in jeopardy   │  High: Monitoring              │
└────────────────────────────────┴────────────────────────────────┘
```

**Rules:**
- Status indicator (🟢/🟡/🔴) always present in the left panel
- Milestones timeline runs down the right column chronologically
- KPI table uses 3 columns: Metric / Current / Target — add B/(W) and Trend columns for performance reviews
- Business case must include: opportunity sizing, investment required, key assumptions, confidence level
- May include links to supporting materials but pertinent data should be on the slide itself

---

## Pattern 5 — Quarterly Outlook

**Use when:** Opening a quarterly business review, planning session, or strategic check-in.

**Layout base:** Table Style 3 (Template slide 51) with added narrative sections

### Structure

```
┌─────────────────────────────────────────────────────────────────┐
│  Q[X] OUTLOOK  /  Q[X-1] EXECUTIVE SUMMARY                     │
├────────────────────────┬────────────────────────────────────────┤
│  Outlook Questions:    │  Q[X-1] Summary Questions:            │
│  1. Big areas of focus │  1. Goals exceeded / what went well   │
│     in next 90 days    │  2. Goals off track / path to recover │
│  2. Initiatives to     │  3. [Additional context]              │
│     accelerate or      │                                       │
│     reprioritize       │                                       │
│  3. Where leader       │                                       │
│     support needed     │                                       │
├────────────────────────┴────────────────────────────────────────┤
│  Strategic Imperative  │ KPI │ Annual Target │ YTD │ Q Target  │
│  ─────────────────────────────────────────────────────────────  │
│  Initiative name/desc  │  X  │      Y        │  Z  │    W      │
│  Initiative name/desc  │  X  │      Y        │  Z  │    W      │
├─────────────────────────────────────────────────────────────────┤
│  Confidence:  🟢 On track / High   🟡 At risk / Mid            │
│               🔴 Off track / Low                                │
└─────────────────────────────────────────────────────────────────┘
```

**Rules:**
- Two narrative columns side-by-side: forward-looking (Outlook) and backward-looking (Summary)
- KPI table at the bottom anchors the narrative in measurable results
- Confidence indicator (🟢/🟡/🔴) on each KPI row signals delivery confidence
- "What Must Be True to Deliver Q Target" column optional but recommended for exec audiences
- Aligned to strategic imperatives, not just tactical tasks

---

## Pattern 6 — 30-60-90 Day Plan

**Use when:** New leader onboarding, initiative launch, program transition, or any situation requiring a phased 90-day plan.

**Two variants:**

### Variant A — Detailed (one slide per phase)

```
┌─────────────────────────────────────────────────────────────────┐
│  [30 / 60 / 90]-DAY PLAN  —  [Context / Team / Initiative]     │
│                                                                 │
│  ●───────────────────────────────────────────────────────       │
│  30 DAY          60 DAY                    90 DAY               │
│  (current)       (next)                    (future)             │
│                                                                 │
│  [Icon]        [Icon]                  [Icon]                 │
│   Item 1        Item 2                   Item 3                │
│   Description   Description              Description           │
│                                                                 │
│  01            02                       03                     │
│  [Key action]  [Key action]             [Key action]           │
│  [Detail]      [Detail]                 [Detail]               │
│                                                                 │
│  Key Success Metrics                                            │
│  [Metric 1 Name]    [Metric 2 Name]    [Metric 3 Name]         │
│  [Description]      [Description]      [Description]           │
└─────────────────────────────────────────────────────────────────┘
```

### Variant B — Executive Summary (compact, all three phases on one slide)

```
┌─────────────────────────────────────────────────────────────────┐
│  [Context] — 30/60/90 Day Work Summary                         │
│                                                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │   30 DAYS    │  │   60 DAYS    │  │   90 DAYS    │          │
│  │ Item 1 Name  │  │ Item 1 Name  │  │ Item 1 Name  │          │
│  │ Item 2 Name  │  │ Item 2 Name  │  │ Item 2 Name  │          │
│  │ Item 3 Name  │  │ Item 3 Name  │  │ Item 3 Name  │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
└─────────────────────────────────────────────────────────────────┘
```

**Rules:**
- Current phase (active) is visually distinguished — use a filled circle on the timeline
- Numbered actions (01, 02, 03) within each phase signal priority sequencing
- Key Success Metrics row at the bottom grounds the plan in measurable outcomes
- Graphic placeholders: fill with an icon from `assets/icon-index.json` (see `icon-cheat-sheet.md`), recolored to CVS red
- Use Variant A for working sessions; Variant B for executive audiences

---

## Pattern 7 — Strategic Action Plan

**Use when:** Presenting a response to identified pain points, a recovery plan, or a prioritized action roadmap.

**Two variants:**

### Variant A — Pain Point × Time Horizon Grid

```
┌─────────────────────────────────────────────────────────────────┐
│  SUMMARY: STRATEGIC ACTION PLAN                                 │
├──────────────┬───────────────┬───────────────┬──────────────────┤
│  Pain Point  │  Q1           │  Q2           │  Q3/Q4           │
│              │  (Immediate)  │  (Short Term) │  (Longer Term)   │
├──────────────┼───────────────┼───────────────┼──────────────────┤
│  Pain Point  │ • Deliver x   │ • Build on x  │ • Automate y     │
│  #1          │   via y tactic│   impact      │   tactics        │
│  Opp size:$X │   (due xx/xx) │               │                  │
├──────────────┼───────────────┼───────────────┼──────────────────┤
│  Pain Point  │ • A impact    │ • Evaluate    │ • Initiative      │
│  #2          │   via B tactic│   results     │   based on       │
│  Opp size:$X │   (due xx/xx) │   and scale   │   x learnings    │
├──────────────┴───────────────┴───────────────┴──────────────────┤
│  Impact Summary:  $x loss prevented  │  $x recovered  │  X% gap │
└─────────────────────────────────────────────────────────────────┘
```

### Variant B — Four Pain Points × Two Time Horizons

```
┌─────────────────────────────────────────────────────────────────┐
│  SUMMARY: STRATEGIC ACTION PLAN                                 │
│                                                                 │
│  #1 Total Opp $    #2 Total Opp $    #3 Total Opp $            │
│  • Deliver x via   • Deliver x via   • Deliver x via           │
│    y (due xx/xx)     y (due xx/xx)     y (due xx/xx)           │
│                                                                 │
│  ─────────────────────────────────────────────────────          │
│  Short Term: [focus area callout]                               │
│  Long Term: [focus area callout]                                │
└─────────────────────────────────────────────────────────────────┘
```

**Rules:**
- Opportunity size ($) always labeled per pain point — this is the business case for prioritization
- Time horizons labeled as Q1 (immediate) / Q2 (short term) / Q3-Q4 (longer term) OR Short/Long
- Impact Summary row at the bottom aggregates total financial impact across all actions
- Actions use "deliver X impact via Y tactic (due date)" format — specific, owned, and time-bound
- 3–5 pain points per slide; use multiple slides if more

---

## Pattern 8 — Patient / Member Journey Map

**Use when:** Visualizing a care journey, member experience, channel outreach sequence, or multi-step engagement flow.

**Layout base:** Build from scratch using the blank accessibility layout (Template slide 24)

### Structure

```
┌─────────────────────────────────────────────────────────────────┐
│  [JOURNEY NAME]   VISION & PATIENT IMPACT                       │
│                                                                 │
│  Identify → Reach/Awareness → Engage → Impact & Follow-Through  │
│                                                                 │
│  ┌──────┐   ┌──────────┐   ┌──────────┐   ┌──────────────────┐ │
│  │Step 1│ → │ Step 2   │ → │ Step 3   │ → │    Step 4        │ │
│  │[Who] │   │[Channel] │   │[Action]  │   │[Outcome]         │ │
│  │[What]│   │[What]    │   │[What]    │   │[What]            │ │
│  └──────┘   └──────────┘   └──────────┘   └──────────────────┘ │
│                                                                 │
│  Key Activities:          Desired Outcomes:                     │
│  • Activity 1             Members Engaged: X                    │
│  • Activity 2             IHEs Scheduled: X                     │
│                                                                 │
│  Legend: ● Does not exist  ● Exists in all products            │
│          ● Key opportunity  ● Partially exists / in testing     │
└─────────────────────────────────────────────────────────────────┘
```

**Rules:**
- Journey phases across the top: Identify → Reach → Engage → Impact (adapt as needed)
- Each step box: who is acting, what channel, what action, what the patient/member experiences
- Key Activities and Desired Outcomes panels below the journey flow
- Legend at bottom for experience state indicators (exists / in testing / opportunity)
- For multi-channel journeys, stack channels vertically within each phase column
- Financial value panel (Enterprise Revenue / EBITDA) optional for strategic decks

---

## Pattern 9 — Closed-Loop Feedback Model

**Use when:** Explaining how feedback is collected, analyzed, and acted upon; process improvement governance; survey action frameworks.

**Layout base:** Circular diagram (Chart Library slide 28) or build from scratch

### Structure

```
┌─────────────────────────────────────────────────────────────────┐
│  [TITLE — e.g., "We use a closed-loop feedback model"]          │
│                                                                 │
│  Two simultaneous processes inform action at different levels:  │
│                                                                 │
│   INNER LOOP                      OUTER LOOP                   │
│   < 3 months implementation       3+ months implementation     │
│                                                                 │
│   ┌─→ 01 Gather feedback           ┌─→ 01 Gather feedback      │
│   │   02 Survey admin              │   02 Root cause analysis   │
│   │   03 Data/trend analysis       │   03 Implement structural  │
│   │   04 Review with teams    ─────┘       improvements        │
│   └── 05 Implement changes         04 Communicate changes      │
│                                                                 │
│   Workflow/training changes        Structural improvements,     │
│   based on actionable feedback     sometimes requiring budget   │
└─────────────────────────────────────────────────────────────────┘
```

**Rules:**
- Two loops side-by-side: Inner Loop (fast, operational) and Outer Loop (slow, structural)
- Time horizon clearly labeled for each loop
- Numbered steps with arrows showing the cyclical flow
- Brief outcome description below each loop describing what type of change it drives
- Can be simplified to a single loop if the process doesn't have two tiers
- Works well on a navy divider background for visual impact

---

## Pattern 10 — Funnel Diagram

**Use when:** Showing conversion rates, a pipeline view, a patient/member journey with drop-off, or a multi-stage process with volume at each stage.

**Layout base:** Build from scratch using blank layout (Template slide 24)

### Structure

```
┌─────────────────────────────────────────────────────────────────┐
│  [TITLE — e.g., "Feedback Loop Guiding Principles"]             │
│                                                                 │
│  ~90% of inquiries resolved at this stage                       │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  STAGE 1: [Name]                                        │    │
│  │  [Description of what happens at this stage]           │    │
│  └───────────────────────────────────────────────────────  │    │
│      ┌─────────────────────────────────────────────────┐  │    │
│      │  STAGE 2: [Name]                                │  │    │
│      │  [Description]                                  │  │    │
│      └─────────────────────────────────────────────────┘  │    │
│           ┌─────────────────────────────────────────┐     │    │
│           │  STAGE 3: [Name]                        │     │    │
│           │  [Description]                          │     │    │
│           └─────────────────────────────────────────┘     │    │
│                                                            │    │
│  ~10% resolved here ──────────────────────────────────────┘    │
│                                                                 │
│  [Outcome label at bottom of funnel]                            │
└─────────────────────────────────────────────────────────────────┘
```

**Rules:**
- Each stage narrows visually (trapezoid shape, or indented rectangles)
- Volume or percentage label on the left side of each stage
- Stage name bold, description text below in regular weight
- Outcome label at the bottom names what successfully exits the funnel
- For pipeline/empanelment funnels: add actual numbers at each stage, not just percentages
- Color: use CVS Red for the primary funnel shape; stage labels in white

---

## Pattern 11 — Multi-Metric Operational Dashboard

**Use when:** Presenting operational performance across multiple metrics in a single slide — monthly/quarterly reviews, business management meetings.

**Layout base:** Multi-chart combo (Chart Library slide 33) extended

### Structure

```
┌─────────────────────────────────────────────────────────────────┐
│  [TITLE]  MTD/YTD [Period] Results vs. Budget                   │
│                                                                 │
│  ┌─────────────────────┐  ┌─────────────────────────────────┐  │
│  │  Metric 1 vs Budget │  │  Metric 2 vs Budget             │  │
│  │  [Bar/waterfall     │  │  [Bar/waterfall chart]          │  │
│  │   chart]            │  │                                 │  │
│  └─────────────────────┘  └─────────────────────────────────┘  │
│                                                                 │
│  ┌───────────────────┐  ┌───────────────────────────────────┐  │
│  │  Metric 3 Trend   │  │  Commentary                       │  │
│  │  [Line chart]     │  │  Subhead: [key message]           │  │
│  │                   │  │  • Bullet point insight           │  │
│  │                   │  │  • Bullet point insight           │  │
│  └───────────────────┘  └───────────────────────────────────┘  │
│                                                                 │
│  Footer: [source] / [period]                                    │
└─────────────────────────────────────────────────────────────────┘
```

**Rules:**
- 3–4 charts in a 2×2 or 3+1 grid; do not exceed 4 charts per slide
- Each chart has a mini-title (15pt bold) and source line (10pt) beneath it
- Commentary panel replaces one chart quadrant when narrative context is needed
- Waterfall charts work best for budget variance (use CVS chart color sequence)
- Always include: period label (MTD/YTD), reference point (vs. Budget / vs. Prior Year), and footer with data source
- Key callout number (large stat) may be added to any chart quadrant for the most critical metric

---

## Pattern 12 — RACI Matrix

**Use when:** Clarifying cross-functional ownership of a process, workstream, or recurring activity.

**Layout base:** Table Style 1 (Template slide 49)

### Structure

```
┌─────────────────────────────────────────────────────────────────┐
│  [WORKSTREAM NAME] RACI                                         │
│                                                                 │
│  Activities     │ Team A │ Team B │ Team C │ Team D │ Team E   │
│  ───────────────────────────────────────────────────────────── │
│  PRE-WORK       │        │        │        │        │          │
│  Task 1         │   R    │   A    │   I    │   I    │   C      │
│  Task 2         │   R    │   A    │   I    │   I    │   C      │
│  ───────────────────────────────────────────────────────────── │
│  EXECUTION      │        │        │        │        │          │
│  Task 3         │   R    │   A    │   C    │   I    │   C      │
│  Task 4         │   C    │   A    │   R    │   I    │   C      │
│  ───────────────────────────────────────────────────────────── │
│  POST-WORK      │        │        │        │        │          │
│  Task 5         │   R    │   A    │   I    │   I    │   C      │
│  ───────────────────────────────────────────────────────────── │
│  R = Responsible   A = Accountable   C = Consulted   I = Informed │
└─────────────────────────────────────────────────────────────────┘
```

**Rules:**
- Group activities into phases (Pre-Work / Execution / Post-Work or equivalent) with bold section headers
- Team names in column headers; activities in row labels
- RACI key always at the bottom of the table
- Maximum 1 Accountable (A) per row — this is the RACI rule
- For large workstreams, split into multiple slides by phase rather than cramming all activities into one table
- Table header row: navy background (`0B315E`), white text, bold — consistent with CVS table standards

---

## Usage Notes

- These patterns have **soft brand adherence** — appropriate for internal presentations. For external or board-level decks, apply stricter style guide rules from `CVS_Slide_Style_Guide.md`.
- Patterns can be **combined** within a deck — e.g., Pattern 1 (Exec Summary) opens the deck, Pattern 2 (Portfolio Status) covers the body, Pattern 7 (Strategic Action Plan) closes.
- When in doubt about which pattern to use, ask the user: "Is this for an executive update, a working session, or a formal presentation?" — the answer usually points to the right pattern.
- Always use `CVS Health Sans` font and the footer from the Everyday Template even for internal decks.

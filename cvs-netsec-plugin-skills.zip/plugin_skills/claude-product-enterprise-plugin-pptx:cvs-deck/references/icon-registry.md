# Icon Category Summary

> Full lookup is in `assets/icon-index.json` (compact array format, 1,228 icons). Read this file only to understand category scope. Use the JSON index for actual icon lookup.

## Library: Iconography_Library_01_2026.pptx

Two variants for every icon: **outline** (preferred) and **filled** (added visual weight, digital navigation).

| Category | Outline slides | Filled slides | ~Count |
|---|---|---|---|
| Accessibility | 4 | 26 | 6 |
| Business | 5 | 27 | 44 |
| Entertainment | 6 | 28 | 3 |
| Health care | 7–9 | 29–31 | ~130 |
| Lifestyle | 10 | 32 | 37 |
| Maps | 11–12 | 33–34 | 54 |
| Messaging | 13 | 35 | 9 |
| Nature | 14 | 36 | 17 |
| People | 15–16 | 37–38 | ~55 |
| Retail | 17–19 | 39–41 | 105 |
| Technology | 20–21 | 42–43 | 78 |
| Transportation | 22 | 44 | 19 |
| Utilities | 23–24 | 45–46 | 15 |

## Lookup pattern

```python
import json, copy
from pptx import Presentation

with open("assets/icon-index.json") as f:
    idx = json.load(f)

target, variant = "stethoscope", "outline"
row = next((r for r in idx["icons"] if r[0].lower() == target and r[1] == variant), None)
if row:
    label, variant, category, slide_num, shape_name = row
    lib = Presentation("assets/libraries/Iconography_Library_01_2026.pptx")
    src_slide = lib.slides[slide_num - 1]
    for shape in src_slide.shapes:
        if shape.name == shape_name:
            target_slide.shapes._spTree.insert(2, copy.deepcopy(shape._element))
            break
```

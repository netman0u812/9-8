# CVS Health Cover & Closing Slide Registry

> The Everyday Template (`assets/templates/everyday_2026.pptx`) ships with **6 built-in cover layouts** and **6 built-in closing layouts** — these are the only covers this skill supports. There is no external cover library bundled or fetched; an earlier version of this skill referenced a 53-cover SharePoint library, but that file was excluded from the package for size and is no longer part of the supported workflow.

## Critical Usage Rules

- **Choose only one cover** — via `cover_slide()` / `get_layout(prs, 'Title Slide')` or its numbered variant; never combine covers
- **Do not alter the built-in art** — the heart illustration and CVS Health logo are pre-positioned in the layout; don't recolor, crop, or move them
- **All covers support**: Presentation title, presenter name/title, date — these are the intended editable fields

---

## The 6 Built-In Covers

Pulled from the template's own layout set (see `references/slide-layout-registry.md` → COVERS):

| Layout | Style | Title Capacity | Best For |
|---|---|---|---|
| `Title Slide` | Heart art / image | 2–3 lines | Default — internal updates, everyday decks |
| `Title Slide 2` | Heart art / image, alternate | 2–3 lines | Internal updates, visual variety from the default |
| `Title Slide 3` | Heart art / image, alternate | 2–3 lines | Internal updates, visual variety from the default |
| `Title Slide 4` | Image with white band | 2–3 lines | Clean/professional, quarterly reviews, program updates |
| `Title Slide 5` | Image with white band, alternate | 2–3 lines | Same as above, second option |
| `Title Slide 6` | Image with navy band | 2–3 lines | Executive/board-level, formal external presentations |

## Quick-Match Decision Guide

| Situation | Recommended Layout |
|---|---|
| Board of Directors / executive presentation | `Title Slide 6` (navy band) |
| Quarterly business review / program update | `Title Slide 4` or `Title Slide 5` (white band) |
| Internal team update, everyday deck | `Title Slide`, `Title Slide 2`, or `Title Slide 3` (heart art) |
| No strong preference stated | `Title Slide` (default, most universally on-brand) |

## Workflow for Cover Selection

1. Ask or infer the audience and formality level
2. Consult the Quick-Match guide above
3. Add via `cover_slide(prs, title, presenter)` (uses `get_layout(prs, 'Title Slide')` by default) or pass the specific variant name
4. Populate: presentation title, presenter name, presenter title, date
5. Select a closing layout that fits the deck's tone — `Next steps`, `In closing`, `Closing slide`, or `Closing slide option` — and append as the final slide. See `references/slide-layout-registry.md` → CLOSING LAYOUTS for details.

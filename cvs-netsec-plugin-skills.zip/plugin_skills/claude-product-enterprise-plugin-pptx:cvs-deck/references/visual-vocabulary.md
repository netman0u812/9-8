# CVS Health Visual Vocabulary
> Concrete recipes for building visually distinctive CVS-branded slides with python-pptx.
> Read this whenever building from scratch — it is the difference between a generic deck and a CVS-distinctive one.

---

## Why This File Exists

The CVS Slide Style Guide tells Claude *what the brand looks like*. The asset registries tell Claude *what brand assets exist*. This file fills the gap between them: **how to actually build visually rich slides in code**.

Without these recipes, Claude defaults to a generic "rectangles + navy + gray + columns" pattern that is brand-compliant but visually flat. With them, Claude reaches for the distinctive visual language CVS Health actually uses — hearts, hexagons, tapered funnels, hero quotes, dramatic color blocks.

**The bar:** A skilled human designer at CVS would look at the output and recognize it as on-brand work. Compliance is necessary but insufficient — visual ambition matters too.

---

## Available Shapes — What to Reach For

python-pptx exposes these via `MSO_SHAPE.*` (`from pptx.enum.shapes import MSO_SHAPE`), passed as the second argument to `slide.shapes.add_shape(MSO_SHAPE.X, x, y, w, h)`. **Use them confidently** — these are confirmed available:

| Shape | Use For |
|---|---|
| `HEART` | ⚠️ **Do NOT use for the CVS brand mark** — generic Office heart reads as Valentine's Day. Use the bundled PNGs in `assets/marks/` instead (see Recipe 1). The shape primitive is acceptable only for non-brand decorative use that has no CVS-mark intent (rare). |
| `HEXAGON` | Numbered value drivers, three-pillars tiles, "honeycomb" connectivity diagrams |
| `TRAPEZOID` | Tapered funnels (rotate the shape 180° for a narrow-bottom funnel — see Recipe 3) |
| `CHEVRON` | Process flow connectors, "next step" arrows, badge points |
| `RIGHT_ARROW` | Next steps, call-to-action markers, directional emphasis |
| `STAR_5_POINT` | Recognition, achievement, "strong execution" badges |
| `LIGHTNING_BOLT` | Opportunity, energy, breakthrough moments |
| `DONUT` | Single-metric stat callouts (use as ring around a number) |
| `OCTAGON` | Stop / caution / decision-point callouts; gear-style icons when overlaid with smaller oval |
| `DIAMOND` | Decision points, key turning points |
| `PENTAGON` | Forward-pointing process steps |
| `OVAL` | Numbered circles, dot bullets, badge containers |
| `RECTANGLE` | Cards, panels, accent bars (sharp corners — never rounded for accent bars) |
| `ROUNDED_RECTANGLE` | Cards where softer edges are intentional (rare) |
| `LINE` | Dividers, connectors — or use `slide.shapes.add_connector()` |
| `RIGHT_TRIANGLE` | Page-corner accents, dynamic geometric treatments |

`rct()` in `cvs_utils.py` wraps `RECTANGLE` with CVS defaults (fill, optional border) — use it for anything rectangular rather than calling `add_shape()` directly. For the other shapes, use `slide.shapes.add_shape(MSO_SHAPE.X, ...)` directly, following the recipes below.

---

## Color Palette — Going Beyond Navy + Gray

All colors live in `cvs_utils.py` as `RGBColor` constants — this file doesn't redefine them. Import once at the top of your build script:

```python
import sys; sys.path.insert(0, 'assets')
from cvs_utils import (
    CVS_RED, CVS_RED_DARK, CVS_RED_SOFT, CVS_NAVY, CVS_NAVY_DEEP, CVS_BLUE,
    CVS_WHITE, TEXT_DARK, TEXT_GRAY, TEXT_LIGHT, SURF_WARM, SURF_COOL,
    SURF_NEUTRAL, BORDER, BORDER_SOFT, ICE, AMBER, AMBER_SOFT, GREEN_DEEP,
    GREEN_SOFT, FONT, rct, tb, card_shadow,
)
```

| Constant | Hex | Role |
|---|---|---|
| `CVS_RED` | `CC0000` | Primary accent |
| `CVS_RED_DARK` | `A30000` | Hover/depth states |
| `CVS_RED_SOFT` | `F7978D` | Tints, secondary text on navy |
| `CVS_NAVY` | `0B315E` | Primary brand navy |
| `CVS_NAVY_DEEP` | `081F3F` | Darker navy for depth/closing |
| `CVS_BLUE` | `0A4B8C` | Mid-tone for layering, secondary chart color |
| `TEXT_DARK` | `3F3F3F` | Body text |
| `TEXT_GRAY` | `646464` | Secondary text |
| `TEXT_LIGHT` | `868686` | Tertiary, footnotes |
| `CVS_WHITE` | `FFFFFF` | — |
| `SURF_NEUTRAL` | `F7F7F7` | Card surfaces (cool) |
| `SURF_WARM` | `F5F1EC` | Card surfaces (warm — use behind hearts) |
| `BORDER` | `C0C0C0` | Standard border |
| `BORDER_SOFT` | `D8D3C8` | Subtle dividers |
| `ICE` | `CADCFC` | Light blue text on navy |
| `AMBER` / `AMBER_SOFT` | `D88500` / `FCF1E5` | Opportunity / caution — card + surface pair |
| `GREEN_DEEP` / `GREEN_SOFT` | `0F6B45` / `E8F4EE` | Strong execution / positive — card + surface pair |

**When to use semantic colors** (`AMBER`/`AMBER_SOFT`, `GREEN_DEEP`/`GREEN_SOFT`, `ICE`): profile cards, comparison cards, status indicators. Never for primary brand moments — those stay red/navy.

---

## Palette Schemes — Pick One Per Slide

**The single biggest source of off-brand-looking output is treating the color tokens as a buffet.** A skilled designer doesn't pick colors element-by-element — they pick a *scheme* for the slide, then assign roles within it. Red and navy at full saturation directly adjacent fight for attention and read as "patriotic" rather than "healthcare." That's where the navy-and-red conflict comes from.

**Rule:** Before building any slide, pick a palette scheme below and stick with it for the whole slide. Don't mix schemes within one slide.

### The Schemes

#### White Editorial — *the default*
**Use this unless you have a specific reason not to.** It's the workhorse for body content.

- **60% — surface:** `CVS_WHITE`
- **30% — secondary:** `TEXT_DARK` and `TEXT_GRAY` for type, `BORDER_SOFT` for card lines, `SURF_NEUTRAL` for alternating rows
- **10% — accent:** `CVS_RED` (super titles, hero numbers, thin top-bars on cards)
- **Navy used sparingly** — section header strips, table headers, numbered circles only
- **Use for:** body content slides, dashboards, three-column layouts, most workhorse slides

#### Navy Hero
For dramatic moments. The whole slide commits to navy.

- **60% — surface:** `CVS_NAVY` or `CVS_NAVY_DEEP`
- **30% — secondary:** `CVS_WHITE` and `ICE` for type, `CVS_RED_SOFT` (NOT `CVS_RED`) for super titles
- **10% — accent:** `CVS_RED` only as thin underlines or hash marks; the bundled heart PNG at hero scale (see Recipe 1)
- **Critical:** super titles on navy use `CVS_RED_SOFT` (`F7978D`). `CVS_RED` directly on `CVS_NAVY` is a vibration trap — don't.
- **Use for:** dividers, closing slide, executive stat callouts, hero quote slides

#### Warm Heart
For the brand-mark moments. Always paired with the heart asset.

- **60% — surface:** `SURF_WARM` panel on one side, `CVS_WHITE` content panel on the other (split layout)
- **30% — secondary:** `TEXT_DARK` for titles on white side, `TEXT_GRAY` for body
- **10% — accent:** `CVS_RED` heart asset (bundled solid/outline PNGs — see Recipe 1), thin red top-bars
- **Use for:** covers, closing slides, mission/values moments

#### Semantic Split
Earned only when content has a true positive/negative or strong/weak axis.

- **Card A:** `GREEN_SOFT` fill, `GREEN_DEEP` header strip, white text in header
- **Card B:** `AMBER_SOFT` fill, `AMBER` header strip, white text in header
- **Brand red appears only in slide title and footer** — not in either card
- **Use for:** strong-execution-vs-opportunity comparisons, before/after, good/bad. See Recipe 5.

### The Buffer Rule

**Red and navy never share a large border without a buffer.** When they meet, white, `SURF_WARM`, or `BORDER_SOFT` separates them. A red sidebar directly touching a navy card will feel loud and conflicted — that's the "patriotic" reading the eye registers as off-brand.

✅ White card on a navy slide with a thin `CVS_RED` top-accent bar (white separates red from navy)
✅ Red eyebrow text on white above a navy section strip (white separates them)
✅ Navy hexagon with a thin red border (the border is the accent, not a meeting of fields)
❌ Red rectangle directly adjacent to a navy rectangle with no white gap
❌ Red title text on solid navy background — use `CVS_RED_SOFT` instead (Navy Hero rule)
❌ A red sidebar running into a navy header — insert a white or `BORDER_SOFT` divider

### 60 / 30 / 10 Dominance Check

Across the visible area of a slide, color should split roughly:
- **60%** dominant (the surface)
- **30%** secondary (cards, type, structure)
- **10%** accent (the punch — usually red)

**If red is showing up at 30%+ of the slide, pull it back.** Red is a punctuation mark, not a paragraph. Move some red elements to grayMed text or to a thin accent bar, and the slide settles.

### Per-slide-type defaults

| Slide type | Default scheme |
|---|---|
| Cover | Warm Heart |
| Section divider | Navy Hero |
| Standard content slide | White Editorial |
| Stat callout / hero number | Navy Hero or White Editorial |
| Quote slide | Navy Hero |
| Comparison card slide | Semantic Split |
| Closing slide | Warm Heart (echo cover) or Navy Hero |

---

## Recipe Book

### Recipe 1 — The CVS Heart as a Brand Anchor

**The CVS Heart is a brand asset, not a shape primitive.** Never use `MSO_SHAPE.HEART` to represent the CVS Heart — it's a generic Office geometric heart and reads as Valentine's Day, not healthcare. The CVS Heart has specific proportions and curvature that only the official asset captures. Hand-drawing your own heart in PIL, SVG, or any other code path is a hard prohibition (SKILL.md's Hard Prohibitions).

**No fetch needed — the asset is local.** All 8 variants (solid/outline × red/white × reg/sm) are bundled in `assets/marks/`:

| File | Use |
|---|---|
| `heart_solid_red_reg.png` | Hero element on covers/closing, light backgrounds |
| `heart_solid_white_reg.png` | Hero element on covers/closing, navy/dark backgrounds |
| `heart_outline_red_reg.png` | Accent, layered depth, light backgrounds |
| `heart_outline_white_reg.png` | Accent, layered depth, navy/dark backgrounds |
| `*_sm.png` variants of all four | Same roles at smaller placements |

If any of these files is missing from `assets/marks/` on disk, **do not** generate a heart in PIL/SVG/cairosvg as a substitute. Document the gap under the Asset Provenance section of your final response (see SKILL.md's Documented-Failure rule) instead — off-brand hearts shipped silently are worse than a clearly-flagged placeholder.

```python
# ROLE 1 — Hero element on cover (large, dominant)
slide.shapes.add_picture(
    'assets/marks/heart_solid_red_reg.png',
    Inches(9.0), Inches(1.0), Inches(4.0), Inches(4.4)
)
# Pair with a smaller open heart for layered depth
slide.shapes.add_picture(
    'assets/marks/heart_outline_red_reg.png',
    Inches(11.6), Inches(4.5), Inches(1.3), Inches(1.4)
)

# ROLE 2 — Footer brand mark
# Use the full CVS Health logo (heart + wordmark) — assets/marks/cvs_logo.png,
# already embedded via the slide master on content_slide() slides (see SKILL.md
# "Master shape inheritance"). At sizes under 0.3", the standalone heart loses
# readability; the logo is the right call. Never compose the wordmark from
# system fonts.

# ROLE 3 — Closing slide echo (large, partially off-canvas for drama)
slide.shapes.add_picture(
    'assets/marks/heart_solid_red_reg.png',
    Inches(9.5), Inches(0.8), Inches(5.5), Inches(6.0)
)
```

Set alt text on any heart placed as a meaningful (non-decorative) element via the picture's `_element` (its `nvPicPr.cNvPr` `descr` attribute) — see SKILL.md's Accessibility section.

**When a hero heart would be too literal.** For body slides that need warmth without a literal heart shape, use a Health care-category icon (e.g. "Care," "Hand with heart," "Holistic care" from `icon-registry.md`) instead of the brand-mark heart. Reserve the actual heart assets for cover/closing slides.

**Subtle background watermark.** Use an outline variant (`heart_outline_red_reg.png` or `heart_outline_white_reg.png`) at low opacity, scaled large, behind other content — not a hero placement. python-pptx doesn't have a simple opacity setter for pictures; set it via the picture's `_element` (an `<a:alphaModFix>` in its blip fill) if you need true transparency, or use a pre-faded asset if one exists.

**Anatomical heart ≠ brand heart.** The "Heart" entry in `icon-registry.md` is an anatomical silhouette (cardiology, cardiovascular). It's the right choice for heart-health content and the wrong choice for brand-mark moments. Don't substitute one for the other.

**Cohesion rule.** Cover and closing slides should both feature the heart asset — that's the visual rhyme that ties the deck together. Don't introduce hearts mid-deck unless the content is specifically heart-health-related (in which case use the anatomical icon).

**Anti-patterns (banned, see SKILL.md Hard Prohibitions).** A row of `MSO_SHAPE.HEART` icons across a slide. Multiple hearts in red/pink scattered as decoration. A heart hand-drawn in PIL or SVG that "looks close enough." All of these read as off-brand — use the bundled PNGs above, or document the gap if one is genuinely missing.

---

### Recipe 2 — Hexagonal Numbered Tile (Three Pillars)

For "three value drivers" / "three pillars" / "three objectives" content, hexagons beat rectangles every time.

```python
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN

# Outer red border hex (creates the red ring effect)
slide.shapes.add_shape(MSO_SHAPE.HEXAGON, Inches(hx - 0.06), Inches(hy - 0.06),
                        Inches(hw + 0.12), Inches(hh + 0.12))
outer_hex = slide.shapes[-1]
outer_hex.fill.solid()
outer_hex.fill.fore_color.rgb = CVS_RED
outer_hex.line.fill.background()

# Inner navy hex
inner_hex = slide.shapes.add_shape(MSO_SHAPE.HEXAGON, Inches(hx), Inches(hy),
                                    Inches(hw), Inches(hh))
inner_hex.fill.solid()
inner_hex.fill.fore_color.rgb = CVS_NAVY_DEEP if i == 1 else CVS_NAVY  # alternate for variety
inner_hex.line.fill.background()

# Big number inside
tb(slide, '01', hx, hy + 0.45, hw, 1.0,
   size=56, bold=True, color=CVS_WHITE, align=PP_ALIGN.CENTER)

# Hash mark below number, inside hex
rct(slide, hx + hw / 2 - 0.18, hy + 1.5, 0.36, 0.04, CVS_RED)

# Label below hex (outside)
tb(slide, label, hx - 0.15, hy + hh + 0.18, hw + 0.3, 0.4,
   size=12, bold=True, color=TEXT_DARK, align=PP_ALIGN.CENTER)
```

Note: `tb()`'s text is left-aligned by default and doesn't vertically center within its box the way the numbered-tile treatment wants — for the big number specifically, set `p.alignment` and consider `text_frame.vertical_anchor = MSO_ANCHOR.MIDDLE` (from `pptx.enum.text import MSO_ANCHOR`) after the call if it doesn't sit where expected.

**Sizing:** 2.55″ × 2.3″ hexagons spaced ~3″ apart fits three across the left 9″ of a wide slide. Center the row in the available space.

---

### Recipe 3 — Tapered Funnel (Conversion / Drop-off)

When the inspiration pattern calls for a funnel, use a real tapered shape — not stacked rectangles.

```python
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN

fun_x, fun_y, fun_w, fun_h = 7.4, 2.4, 4.5, 4.2

# Tapered funnel using TRAPEZOID, rotated 180° (wide top, narrow bottom)
funnel = slide.shapes.add_shape(MSO_SHAPE.TRAPEZOID, Inches(fun_x), Inches(fun_y),
                                 Inches(fun_w), Inches(fun_h))
funnel.rotation = 180
funnel.fill.solid()
funnel.fill.fore_color.rgb = CVS_NAVY
funnel.line.color.rgb = CVS_RED
funnel.line.width = Pt(1)

stages = [
    {'label': 'ATTEMPTED', 'n': '860', 'conv': None},
    {'label': 'CONNECTED', 'n': '596', 'conv': '69%'},
    {'label': 'RECORDED',  'n': '316', 'conv': '53%'},
    {'label': 'PERSISTED', 'n': '182', 'conv': '58%'},
]
section_h = fun_h / len(stages)

for i, st in enumerate(stages):
    sy = fun_y + i * section_h

    # White divider between sections
    if i > 0:
        rct(slide, fun_x, sy, fun_w, 0.02, CVS_WHITE)

    # Stage label (small, ice blue)
    tb(slide, st['label'], fun_x, sy + 0.12, fun_w, 0.25,
       size=9, bold=True, color=ICE, align=PP_ALIGN.CENTER)
    # Stage number (large, white)
    tb(slide, st['n'], fun_x, sy + 0.36, fun_w, 0.55,
       size=24, bold=True, color=CVS_WHITE, align=PP_ALIGN.CENTER)

    # Conversion badge OUTSIDE the funnel (right side)
    if st['conv']:
        chevron = slide.shapes.add_shape(MSO_SHAPE.CHEVRON, Inches(fun_x + fun_w - 0.15),
                                          Inches(sy + 0.35), Inches(0.35), Inches(0.3))
        chevron.fill.solid()
        chevron.fill.fore_color.rgb = CVS_RED
        chevron.line.fill.background()
        tb(slide, st['conv'], fun_x + fun_w + 0.25, sy + 0.32, 0.95, 0.4,
           size=16, bold=True, color=CVS_RED)
```

**Rule:** Conversion badges live *outside* the funnel, connected by red chevrons. This pulls the eye from stage to stage and makes the drop-off readable.

---

### Recipe 4 — Hero Quote on Navy Card

When the content includes a powerful quote, give it dedicated visual real estate.

```python
from pptx.enum.text import PP_ALIGN

hx, hy, hw, hh = 8.8, 1.85, 4.0, 5.0

# Navy card with red top accent
card = rct(slide, hx, hy, hw, hh, CVS_NAVY_DEEP)
card_shadow(card)
rct(slide, hx, hy, hw, 0.06, CVS_RED)

# Oversized red quotation mark
tb(slide, '"', hx + 0.2, hy + 2.5, 0.9, 1.4, size=90, bold=True, color=CVS_RED)

# Quote in white italic
tb(slide, 'This is the most impactful ExtraCare outreach this patient will ever receive…',
   hx + 0.95, hy + 2.85, hw - 1.15, 1.6, size=14, italic=True, color=CVS_WHITE)

# Red attribution divider + attribution
rct(slide, hx + 0.95, hy + 4.5, 0.4, 0.03, CVS_RED)
tb(slide, '— Pharmacist S, in conversation', hx + 0.95, hy + 4.55, hw - 1.15, 0.32,
   size=10, color=CVS_RED_SOFT)
```

---

### Recipe 5 — Profile / Comparison Cards with Semantic Color

For "good vs. bad", "before vs. after", "Strong execution vs. Opportunity" comparisons, use semantic color tinting — far more meaningful than two navy variants.

```python
from pptx.enum.shapes import MSO_SHAPE

# CARD A — Strong execution (green)
card_a = rct(slide, 0.5, 2.3, 6.15, 4.55, GREEN_SOFT, border_color=GREEN_DEEP, border_pt=1)
card_shadow(card_a)
# Header strip
rct(slide, 0.5, 2.3, 6.15, 0.7, GREEN_DEEP)
# Star icon for "achievement"
star = slide.shapes.add_shape(MSO_SHAPE.STAR_5_POINT, Inches(0.7), Inches(2.42),
                               Inches(0.45), Inches(0.45))
star.fill.solid()
star.fill.fore_color.rgb = CVS_WHITE
star.line.fill.background()
tb(slide, 'STRONG EXECUTION', 1.3, 2.4, 5.0, 0.32, size=11, bold=True, color=CVS_WHITE)

# Then: numbered rows with green check badges
# Use MSO_SHAPE.OVAL with green fill + white "✓" text

# CARD B — Opportunity (amber, mirrored)
# Same structure, swap GREEN_SOFT → AMBER_SOFT, GREEN_DEEP → AMBER
# Swap MSO_SHAPE.STAR_5_POINT → MSO_SHAPE.LIGHTNING_BOLT for "opportunity / energy"
# Use "!" instead of "✓" in the row badges
```

**Rule:** Semantic color is earned only when the content has a clear positive/negative or strong/weak axis. Don't reach for green/amber as decoration.

---

### Recipe 6 — Hero Numbered Cards with Visual Hierarchy

When making "01 / 02 / 03" insight or pillar cards, the numbers should be massive — the visual entry point.

```python
ix, iy, iw, ih = 0.5, 1.85, 4.0, 5.0

# Card shell with subtle shadow
card = rct(slide, ix, iy, iw, ih, CVS_WHITE, border_color=BORDER_SOFT, border_pt=0.75)
card_shadow(card)
# Top red accent bar
rct(slide, ix, iy, iw, 0.06, CVS_RED)

# MASSIVE number — the visual anchor
tb(slide, '01', ix + 0.3, iy + 0.25, 1.5, 0.95, size=64, bold=True, color=CVS_RED)
# Hash mark below number (signature CVS treatment)
rct(slide, ix + 0.3, iy + 1.18, 0.5, 0.04, CVS_NAVY)
# Label
tb(slide, 'Compliance Coaching', ix + 0.3, iy + 1.3, iw - 0.6, 0.6,
   size=16, bold=True, color=CVS_NAVY)
# Then bullets with red dot ovals
```

---

### Recipe 7 — Step Flow with Numbered Circles + Chevron Connectors

For "How it works" / "process" content, build a visual flow with red-bordered navy circles connected by red chevrons.

```python
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN

for i, st in enumerate(steps):
    sy = 2.4 + i * 1.5

    # Numbered circle (navy fill, red border for emphasis)
    circle = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(0.5), Inches(sy),
                                     Inches(0.7), Inches(0.7))
    circle.fill.solid()
    circle.fill.fore_color.rgb = CVS_NAVY
    circle.line.color.rgb = CVS_RED
    circle.line.width = Pt(2.5)
    tb(slide, str(st['n']), 0.5, sy, 0.7, 0.7, size=22, bold=True, color=CVS_WHITE,
       align=PP_ALIGN.CENTER)

    # Down chevron between steps (rotated 90°)
    if i < len(steps) - 1:
        chevron = slide.shapes.add_shape(MSO_SHAPE.CHEVRON, Inches(0.78), Inches(sy + 0.78),
                                          Inches(0.14), Inches(0.55))
        chevron.rotation = 90
        chevron.fill.solid()
        chevron.fill.fore_color.rgb = CVS_RED
        chevron.line.fill.background()
```

---

### Recipe 8 — Icons: Vector-Copy from the Bundled Library (Primary) → Primitives (Documented Failure Only)

Icons come from the bundled Iconography Library — no SharePoint fetch, no rasterization. **Building icons from primitives is a fallback path, not a stylistic choice** — it ships if and only if the requested icon genuinely isn't in the library and you've documented why.

#### Primary path — vector-copy from the bundled library

This is `copy_icon()` from `cvs_utils.py`, already the canonical icon workflow documented in SKILL.md — this recipe doesn't introduce a new path, just shows it in context:

```python
# STEP 1 — Identify the icon you need.
#   Read references/icon-cheat-sheet.md for intent → exact label mapping,
#   or references/icon-registry.md to browse by category.

# STEP 2 — Copy it directly into the slide. No fetch, no rasterization —
#   copy_icon() finds the vector shape in the bundled library, deep-copies
#   it, repositions/resizes it, and recolors its fill nodes in place.
copy_icon(slide, label='Bar chart', variant='outline',
          x=0.5, y=1.5, w=0.5, h=0.5, color_hex=CVS_RED_HEX)
```

**Color treatment.** Pass `color_hex=CVS_RED_HEX` on white backgrounds, `color_hex=CVS_WHITE_HEX` on navy backgrounds — `copy_icon()`'s recolor pass handles it, no image editing needed. `color_hex='KEEP'` preserves the library's own colors (rarely what you want on a light background).

**Style consistency in parallel sets.** When a slide has 3 columns / 4 quadrants / pillar tiles, pull every icon in that set from a single category (e.g., all from "Health care") and a single style (all `variant='outline'` OR all `variant='filled'`, never mixed). This is what makes the set read as unified rather than as four unrelated glyphs.

#### Documented-failure path — primitive-built icons

Use these *only* when `copy_icon()` returns `None` (the requested label genuinely isn't in `assets/icon-index.json` — verify with `find_icon()` first, since a typo'd label is a far more common cause than a real gap) and you've recorded the failure for the user. They are deliberately compact — they read as iconographic at glance size (0.3″–0.5″) without trying to compete with the real icon library, but they are visibly hand-drawn next to the official set. Do not mix primitive icons and library icons in the same parallel set.

```python
from pptx.enum.shapes import MSO_SHAPE
from pptx.util import Inches

def icon_cross(slide, x, y, size, color):
    """Medical cross."""
    rct(slide, x + size * 0.35, y, size * 0.3, size, color)
    rct(slide, x, y + size * 0.35, size, size * 0.3, color)

def icon_chart(slide, x, y, size, color):
    """Bar chart (3 ascending bars)."""
    bw, gap = size * 0.22, size * 0.11
    rct(slide, x, y + size * 0.55, bw, size * 0.45, color)
    rct(slide, x + bw + gap, y + size * 0.25, bw, size * 0.75, color)
    rct(slide, x + 2 * (bw + gap), y, bw, size, color)

def icon_person(slide, x, y, size, color):
    """Person silhouette (head + body)."""
    head = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x + size * 0.3), Inches(y),
                                   Inches(size * 0.4), Inches(size * 0.4))
    head.fill.solid(); head.fill.fore_color.rgb = color; head.line.fill.background()
    body = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x + size * 0.1),
                                   Inches(y + size * 0.45), Inches(size * 0.8), Inches(size * 0.55))
    body.adjustments[0] = 0.08  # corner radius, fraction of shorter side
    body.fill.solid(); body.fill.fore_color.rgb = color; body.line.fill.background()

def icon_gear(slide, x, y, size, color):
    """Gear (octagon with center cutout)."""
    gear = slide.shapes.add_shape(MSO_SHAPE.OCTAGON, Inches(x), Inches(y),
                                   Inches(size), Inches(size))
    gear.fill.solid(); gear.fill.fore_color.rgb = color; gear.line.fill.background()
    hole = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x + size * 0.3), Inches(y + size * 0.3),
                                   Inches(size * 0.4), Inches(size * 0.4))
    hole.fill.solid(); hole.fill.fore_color.rgb = CVS_WHITE; hole.line.fill.background()
```

**Required when shipping a primitive icon.** The deck's final response to the user must include an Asset Provenance section listing: which library icon was attempted (exact label passed to `copy_icon()`), confirmation `find_icon()` also returned `None` for it (ruling out a typo), and a recommendation to add the missing icon to the library on the next annual refresh. Without that paper trail, primitive icons are a hard build failure (SKILL.md's Asset-Provenance Anti-Patterns).

---

### Recipe 9 — Section Header Strips

When labeling sections within a slide:

```python
# Navy header strip with red accent on top
rct(slide, 0.5, 4.9, 12.35, 1.0, SURF_NEUTRAL)
# Red flag bar on left
rct(slide, 0.5, 4.9, 0.08, 1.0, CVS_RED)
tb(slide, "HOW WE'RE ADDRESSING BOTH", 0.7, 4.95, 5, 0.25, size=9.5, bold=True, color=CVS_RED)
```

---

### Recipe 10 — Cover Slide Composition

Covers should always feature one of:
1. **Heart art on right** (most on-brand) — see Recipe 1, Role 1
2. **Split panel** (navy right, content left) — for executive feel
3. **Image area + content** (from one of the Everyday Template's 6 built-in covers)

Anti-pattern: Cover with just centered text on white. That's a "Word document title page", not a CVS cover.

```python
# Heart-art-right cover composition
# ─── Left: content ───
# Top red accent bar (small, top-left)
rct(slide, 0.5, 0.5, 0.7, 0.06, CVS_RED)
# Eyebrow
tb(slide, 'PILOT REVIEW  ·  APRIL 2026', 0.5, 0.7, 7.5, 0.32, size=11, bold=True, color=CVS_RED)
# Hero title — split with red emphasis on second line
tb(slide, 'Call Transcription', 0.5, 1.6, 8.0, 1.05, size=50, bold=True, color=TEXT_DARK)
tb(slide, '& Summarization', 0.5, 2.65, 8.0, 1.05, size=50, bold=True, color=CVS_RED)

# ─── Right: warm surface with hearts ───
rct(slide, 8.5, 0, 4.83, 6.4, SURF_WARM)
# Big heart + accent (Recipe 1, Role 1)

# ─── Bottom: navy band with metadata ───
rct(slide, 0, 6.4, 13.33, 1.1, CVS_NAVY_DEEP)
```

---

## Card Shadow Standard

Every card-style container should use `card_shadow()` from `cvs_utils.py` for subtle depth:

```python
card = rct(slide, x, y, w, h, CVS_WHITE)
card_shadow(card)  # default: 10pt blur, 2pt offset, straight down, 8% opacity black
```

Apply it consistently. Don't vary shadow style across a deck — pick the defaults and stick to them.

---

## Visual Cohesion Across a Deck

A deck with rich slides but no visual cohesion still feels off. Build cohesion with:

1. **Recurring motifs** — pick ONE and use it across at least 2 slides (heart, hexagon, red accent bars, etc.)
2. **Cover ↔ Closing rhyme** — closing slide should echo the cover's hero element
3. **Consistent shadow + corner treatment** — all cards same shadow, all accent bars sharp (no rounded)
4. **Color discipline** — red for emphasis only; never make red the dominant color of a body slide
5. **Typographic hierarchy** — every slide should have a clear hero element (a number, a stat, a quote) larger than everything else
6. **Semantic color used sparingly** — green/amber appear on at most 2 slides per deck

---

## Sizing Reference (widescreen 16:9 — 13.33″ × 7.5″)

| Element | Recommended Size |
|---|---|
| Slide title | 26–28pt, top-left at y=0.78 |
| Eyebrow / supertitle | 10pt, letter-spaced, color red |
| Body text | 10–11pt, color TEXT_GRAY |
| Hero number on card | 56–64pt |
| Hero stat on cover | 50pt+ |
| Quote text | 14pt italic |
| Quote opening mark | 90pt |
| Footer | 9pt, gray |
| Card height (3-across) | ~4.0″ wide × 4.5–5.0″ tall |
| Hexagon (3-across) | 2.55″ × 2.3″ |
| Numbered circle | 0.7″ × 0.7″ |
| Icon at small size | 0.3″–0.5″ |
| Margin around content | 0.5″ all sides |
| Slide divider y-position | 1.65″ (under the title) |

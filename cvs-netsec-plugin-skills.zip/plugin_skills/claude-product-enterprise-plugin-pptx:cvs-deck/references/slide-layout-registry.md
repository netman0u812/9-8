# CVS Health Slide Layout Registry
> Covers layouts from two source files:
> - **Everyday Template** — `CVS_Health_Everyday_Widescreen_Template_01_2026.pptx` (base file for all decks; bundled locally, see `manifest.json`)
> - **Chart Library** — `Chart_Library_01_2026.pptx` (additional chart, diagram, and specialty layouts; not bundled, not currently fetched — future enhancement, see `manifest.json → not_bundled`)

---

## How to Use This Registry

1. Determine the content type for each slide you need to build
2. Look up the matching layout — note the **Source** column to know which file to fetch from
3. Build from the named *layout*, not from a duplicated example slide (see below)
4. Populate content via the real placeholders (`content_slide()` + `add_title()`, or
   `slide.placeholders[...]` directly) plus the manual primitives (`rct()`, `tb()`,
   `copy_icon()`) for anything the layout's placeholders don't cover

```python
prs = open_template()
slide = content_slide(prs, 'Agenda')          # any layout name from the directory below
content_y = add_title(slide, "Your title")     # writes into the real title placeholder
# ...populate body_ph / draw custom content from content_y down
```

**Note on the Everyday Template (🟦):** earlier versions of this skill duplicated one of 58
pre-built example content slides via a `duplicate_slide()` helper (deep-copying its shapes
onto a fresh slide) instead of building from the layout directly. That's been removed —
those example slides deep-copied *real, populated* placeholder text onto a new slide that
already had its own empty placeholders, producing duplicate title/body shapes and a ghosting
bug (see `SKILL.md` Changelog). The bundled template now has 0 content slides,
just the 42 layouts — always build from `get_layout()` / `content_slide()` for 🟦 sources.

**Chart Library (🟧) sources**, if that file is ever bundled or fetched, still need a
duplicate-based approach if they contain populated example slides — audit for the same
literal-placeholder-text pattern before reusing that recipe, and prefer building from the
layout directly if the library exposes layouts the same way the Everyday Template does.

---

## Layout Directory

> **Source key:** 🟦 = Everyday Template &nbsp;&nbsp; 🟧 = Chart Library

### COVERS (Slides 4–9) 🟦
*The template includes 6 built-in cover layouts. Select one using the Quick-Match guide in cover-registry.md.*

| Slide | Layout Name | Description |
|---|---|---|
| 4 | Cover example 1 | Heart art / image — 2–3 line title |
| 5 | Cover example 2 | Heart art / image — 2–3 line title, alternate |
| 6 | Cover example 3 | Heart art / image — 2–3 line title, alternate |
| 7 | Cover example 4 | Image with white band |
| 8 | Cover example 5 | Image with white band, alternate |
| 9 | Cover example 6 | Image with navy band |

> **Cover workflow**: Select one of the 6 built-in cover layouts via `get_layout(prs, 'Title Slide')` (or its numbered variant) per cover-registry.md's Quick-Match guide.

---

### AGENDA LAYOUTS (Slides 12–13) 🟦

| Slide | Layout Name | When to Use | Key Specs |
|---|---|---|---|
| 12 | Agenda 1 | Simple agenda — 3–5 agenda items with speaker and topic | Bulleted list format, left-aligned |
| 13 | Agenda 2 | Timed agenda / full-day schedule | Two columns: Morning / Afternoon with times and locations |

---

### DIVIDER / SECTION SLIDES (Slides 14–18) 🟦
*Use between major sections of a presentation. Choose one style and use it consistently throughout the deck.*

| Slide | Layout Name | Background | When to Use |
|---|---|---|---|
| 14 | Divider — red title | White with CVS red title treatment | Standard sections in everyday decks |
| 15 | Divider — gray | Light gray background | Softer section break, internal decks |
| 16 | Divider — navy | Navy (`0B315E`) background | Formal sections, executive decks |
| 17 | Divider — white heart pattern | White with CVS heart art pattern | Warm, brand-forward sections |
| 18 | Divider — dark heart pattern | Dark background with CVS heart art | High-contrast, bold section breaks |

---

### CONTENT LAYOUTS — Text and Columns (Slides 19–24) 🟦

| Slide | Layout Name | When to Use | Columns | Notes |
|---|---|---|---|---|
| 19 | One-column | Narrative content, explanations, long-form text | 1 | Text box is 2/3 page width — do not extend |
| 20 | One-column with header | Narrative with a named section header above body | 1 | Header: 18pt bold Text Gray |
| 21 | Two-column | Side-by-side content, pros/cons, comparisons | 2 | Header: 18pt bold; Body: 13pt |
| 22 | Three-column | Three parallel points, service pillars, options | 3 | Header: 18pt bold; Body: 13pt |
| 23 | Four-column | Four pillars, quarterly breakdown, feature grid | 4 | Header: 18pt bold; Body: 13pt |
| 24 | Blank (accessibility) | Full-custom layouts needing no visible title | — | Title placeholder is outside frame (for screen readers) — always populate it |

---

### CONTENT LAYOUTS — Journey and Visual (Slides 25–27) 🟦

| Slide | Layout Name | When to Use | Notes |
|---|---|---|---|
| 25 | Five-column journey | Step-by-step process, patient journey, 5-stage flow | Each column has a graphic placeholder + header + descriptor; fill with an icon from `icon-index.json` (no pictogram library is bundled — see icon-cheat-sheet.md) |
| 26 | Title with image on right | Text-heavy content with supporting photo | Photo right half; bullets left half |
| 27 | Title with image on left | Text-heavy content with supporting photo (mirrored) | Photo left half; bullets right half |

---

### CONTENT LAYOUTS — Comparison and Process (Slides 28–33) 🟦

| Slide | Layout Name | When to Use | Notes |
|---|---|---|---|
| 28 | One-panel comparison | Two options side by side with icons, centered | Good for binary choices, plan A vs B |
| 29 | Two-panel comparison | Two options with more visual weight | Icon + header + descriptor; centered |
| 30 | Four-point process | 4-step circular or sequential process | Items labeled 1–4; no graphic placeholders |
| 31 | Comparison layout | Two options with icons — more spacious | Header + descriptor centered under icon |
| 32 | Two-column comparison | Two columns with headers and bullets | Header: 18pt bold; use for detailed feature comparison |
| 33 | Three-column comparison | Three columns with headers and bullets | Header: 16pt bold; tighter spacing for 3 options |

---

### CONTENT LAYOUTS — Stats and Quotes (Slides 34–36) 🟦

| Slide | Layout Name | When to Use | Notes |
|---|---|---|---|
| 34 | Title with infographic on right | Text left + 5 large stats or percentages right | Stats in CVS red large numerals; descriptors in gray |
| 35 | Title with infographic on left | 5 large stats left + text right (mirrored) | Same as 34, layout flipped |
| 36 | Quote with image | Full-slide pull quote with photo | Quote in large type; attribution line below; image fills background |

---

### CHART AND DATA LAYOUTS (Slides 40–47) 🟦

| Slide | Layout Name | When to Use | Notes |
|---|---|---|---|
| 40 | Full-page chart | Single chart that needs maximum size | Chart fills most of slide; key takeaway in 15pt bold below |
| 41 | Text and chart | Bullet points left + chart right | Header 18pt bold; body 13pt; chart right half |
| 42 | Text and chart — brand-aligned | Same as 41 but with CVS red data highlighting | Use when CVS Health data segment should be called out in red |
| 43 | Three pie charts | Three small pie charts for comparison | Equal-sized pies across the slide with individual titles |
| 44 | Diagram layout | Equation-style diagram: item + item = result | Pictogram + header + description; use `+` and `=` connectors |
| 45 | Map layout | US regional map with legend | Pre-built US map with 5 CVS regions labeled and color-coded |
| 46 | Organizational chart | Hierarchy / reporting structure | 10-node org chart; expandable by duplicating node shapes |
| 47 | Timeline | Chronological milestones | Two-row timeline with year headers and bullet points |

#### Chart Color Sequence (use in order, never use Office defaults)
```
1: 267AC0  2: 00787E  3: 00A78E  4: 868686  5: 61A515
6: 487A10  7: F4642A  8: CE430C  9: E94D4D  10: 7D3F98
11-15: Contact BrandCenter@CVSHealth.com
```
- CVS Health Red (`CC0000`) may replace a segment color **only** when calling out CVS-specific data
- A 2pt white separator line should appear between adjacent color segments

---

### TABLE LAYOUTS (Slides 49–51) 🟦

| Slide | Layout Name | When to Use | Notes |
|---|---|---|---|
| 49 | Table Style 1 (default) | General data tables — gray text and lines | Most versatile; use for standard reporting tables |
| 50 | Table Style 2 with total row | Data with a summary/total row at bottom | "Total row checked" styling; good for financial tables |
| 51 | Table Style 3 — compact | Numeric data, 3 columns, compact rows | Optional key takeaway line centered below table; max 1 line |

#### Table Styling Rules
- **Header row**: Navy background (`0B315E`), white text, 9–10pt bold uppercase, slight letter-spacing
- **Body rows**: Alternating white / `F7F7F7` fill
- **Body text**: 13pt CVS Health Sans, Text Gray (`3F3F3F`)
- **Never** create freeform tables — always use one of the 3 template styles above
- 7 total table styles exist in the Table Styles menu (Tables 1–7); styles 4–7 are available in PowerPoint's table styles panel even though not shown as sample slides

---

### CLOSING LAYOUTS (Slides 53–57) 🟦

| Slide | Layout Name | When to Use | Notes |
|---|---|---|---|
| 53 | Next steps | Action-oriented close — 3 dated next steps | Timeline format with year/date + action bullets |
| 54 | In closing | Narrative closing — recap and emphasis | 3-part structure: opening / during / conclusion |
| 55 | Closing slide | Standard deck close | Use this as the default closing layout |
| 56 | Closing slide option | Alternate close style | Secondary option if 55 doesn't fit |
| 57 | Disclaimer | Legal/disclaimer text | 8–13pt text; use only when legal language is required |

---

### CHART LIBRARY — Additional Charts (Slides 11–17) 🟧
*These supplement the 5 chart layouts already in the Everyday Template. Use when the Everyday Template chart layouts don't match the data structure needed.*

| Slide | Layout Name | When to Use | Notes |
|---|---|---|---|
| 11 | Full-page chart — color order | Single clustered bar chart, up to 6 series | Annotated with key takeaway (15pt bold) + source (10pt) below |
| 12 | Full-page chart — 5-color bar | Grouped bar chart, 4+ categories, 5 series | Use when categories span the full width of the slide |
| 13 | Combination chart — column + line | Two metrics on different scales (e.g., volume + rate) | Dual Y-axis; CVS Health data highlighted as line series |
| 14 | Horizontal bar chart | Ranking or comparison across many categories | Best when category labels are long; bars run left to right |
| 15 | Multi-line chart with CVS highlight | Trend over time comparing CVS Health vs competitors | CVS Health line visually distinct; up to 4 lines + 9 years of data |
| 16 | Text + chart (pie) | Narrative context left + single pie chart right | Same as Everyday Template slide 41 — use either |
| 17 | Three pie charts | Three time periods or segments compared | Same as Everyday Template slide 43 — use either |

---

### CHART LIBRARY — Process and Diagram Layouts (Slides 23–29) 🟧
*These fill genuine gaps in the Everyday Template — none of these process and diagram types exist there.*

| Slide | Layout Name | When to Use | Notes |
|---|---|---|---|
| 23 | Process chart 1 — 3 numbered steps | Linear 3-step process with descriptions | Large numbered circles (CVS navy); descriptor text below each |
| 24 | Process chart 2 — 3 column headers | Complex workflow with 3 phases, each with sub-steps and bullets | Main headers in navy band; sub-headers + bullets inside each column |
| 25 | Process chart 3 — 5 columns | 5-stage process or journey with key takeaway | Compact column headers + body; key takeaway line 15–18pt bold at bottom |
| 26 | Bottom-up diagram | Hierarchy that builds upward (inputs → outputs) | Text box + 4 subheads + bullets; pyramid structure pointing up |
| 27 | Top-down diagram | Hierarchy flowing downward (strategy → execution) | Mirror of bottom-up; pyramid structure pointing down |
| 28 | Circular / cyclical diagram | Repeating cycle, feedback loop, or continuous process | 4 segments around a central element; all text centered |
| 29 | Venn diagram — 3 circle overlap | Three intersecting concepts, populations, or strategies | 3 overlapping circles with header + description for each |

---

### CHART LIBRARY — Specialty Layouts (Slides 33–35) 🟧
*High-value layouts with no equivalent anywhere in the Everyday Template.*

| Slide | Layout Name | When to Use | Notes |
|---|---|---|---|
| 33 | Multi-chart combo | Dashboard-style slide: text + bar chart + 2 small tables + line chart | Use when a single slide must show multiple data views at once |
| 34 | Partnership / logo grid | 6-tile grid for partners, vendors, or business units | Each tile: logo placeholder + header + centered description; key takeaway at bottom |
| 35 | International map | Global geographic data | Full world map; use when US-only map (Everyday Template slide 45) is insufficient |

---

## Layout Selection Guide

Use this to choose the right layout for any content type:

| Content Type | Recommended Layout | Source | Slide |
|---|---|---|---|
| Agenda / schedule | Agenda 1 or 2 | 🟦 Template | 12–13 |
| Section break | Divider — navy (executive) or red (everyday) | 🟦 Template | 14–18 |
| Long narrative / explanation | One-column | 🟦 Template | 19 |
| Two key messages or options | Two-column or Two-column comparison | 🟦 Template | 21 or 32 |
| Three pillars / options | Three-column or Three-column comparison | 🟦 Template | 22 or 33 |
| Four pillars | Four-column | 🟦 Template | 23 |
| Step-by-step journey (5 steps) | Five-column journey | 🟦 Template | 25 |
| Content + supporting photo | Image on right or Image on left | 🟦 Template | 26–27 |
| Two options with icons | One or Two-panel comparison | 🟦 Template | 28–29 |
| Process with 4 steps | Four-point process | 🟦 Template | 30 |
| Process with 3 numbered steps | Process chart 1 | 🟧 Chart Library | 23 |
| Complex 3-phase workflow | Process chart 2 | 🟧 Chart Library | 24 |
| 5-stage process or journey | Process chart 3 | 🟧 Chart Library | 25 |
| Hierarchy building upward | Bottom-up diagram | 🟧 Chart Library | 26 |
| Hierarchy flowing downward | Top-down diagram | 🟧 Chart Library | 27 |
| Repeating cycle or feedback loop | Circular diagram | 🟧 Chart Library | 28 |
| Three intersecting concepts | Venn diagram | 🟧 Chart Library | 29 |
| Key stats / percentages | Infographic right or left | 🟦 Template | 34–35 |
| Pull quote | Quote with image | 🟦 Template | 36 |
| Single chart (primary message) | Full-page chart | 🟦 Template | 40 |
| Ranked or many-category bar | Horizontal bar chart | 🟧 Chart Library | 14 |
| Two metrics on different scales | Combination chart (column + line) | 🟧 Chart Library | 13 |
| Trend over time, CVS vs others | Multi-line chart | 🟧 Chart Library | 15 |
| Data with context | Text and chart | 🟦 Template | 41 |
| CVS vs competitor data | Text and chart — brand-aligned | 🟦 Template | 42 |
| Multiple charts for comparison | Three pie charts | 🟦 Template | 43 |
| Formula / equation visual | Diagram layout | 🟦 Template | 44 |
| US geographic / regional data | US map layout | 🟦 Template | 45 |
| Global / international data | International map | 🟧 Chart Library | 35 |
| Org structure / hierarchy | Organizational chart | 🟦 Template | 46 |
| Project milestones / history | Timeline | 🟦 Template | 47 |
| Data table | Table Style 1, 2, or 3 | 🟦 Template | 49–51 |
| Dashboard — multiple data views | Multi-chart combo | 🟧 Chart Library | 33 |
| Partners, vendors, or business units | Partnership / logo grid | 🟧 Chart Library | 34 |
| Action items / next steps | Next steps | 🟦 Template | 53 |
| Recap and wrap-up | In closing | 🟦 Template | 54 |

---

## Accessibility Requirements (Built Into Template)

- Every slide must have a title — even "blank" slides use the out-of-frame title placeholder
- Minimum body text: 13pt
- Minimum footnote text: 10pt commercial, 11pt Medicare-facing
- Every image must have alt text set via `shape.alt_text`
- Never rely on color alone to convey meaning — pair with labels or icons
- Do not resize or reposition the footnote/source placeholder (it's pinned to the bottom)

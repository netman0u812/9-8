# CVS Everyday Template — Layout Reference

Full index of all 42 named slide layouts in `assets/templates/everyday_2026.pptx`. Use `get_layout(prs, 'Layout Name')` — never hardcode indices.

| Index | Layout name | Placeholders | Primary use |
|---|---|---|---|
| 0 | `Title Slide` | Title, Presenter | Cover — heart art right |
| 1 | `Title Slide 2` | Title, Presenter | Cover — split panel |
| 2 | `Title Slide 3` | Picture, Title, Presenter | Cover — image area |
| 3 | `Title Slide 4` | Title, Subtitle, Presenter, Picture | Cover — image right |
| 4 | `Title Slide 5` | Picture, Title, Subtitle, Presenter | Cover — image left |
| 5 | `Title Slide 6` | Title, Presenter, Picture | Cover — full bleed image |
| 6 | `Title Slide 7 Parter-branded` | Title, Presenter, Logo, Picture | Cover — partner co-brand |
| 7 | `Agenda` | Title, Content | Agenda — single column |
| 8 | `Agenda 2` | Title, Morning, Afternoon | Agenda — split columns |
| 9 | `Divider red` | Title | Section divider — red |
| 10 | `Divider gray` | Title | Section divider — gray |
| 11 | `Divider navy` | Title | Section divider — navy |
| 12 | `Divider white` | Title | Section divider — white |
| 13 | `Divider dark` | Title | Section divider — dark heart pattern |
| 14 | `Title and Content without Header` | Title, Content | Body — no eyebrow/super-title |
| 15 | `Title and Content` | Title, Content | Body — standard single column |
| 16 | `Two Content` | Title, Left, Right | Body — two columns |
| 17 | `Three Content` | Title, Col1, Col2, Col3 | Body — three columns |
| 18 | `Four Content` | Title, Col1–4 | Body — four columns |
| 19 | `Five Content Journey` | Title, Step1–5 | Process / journey map |
| 20 | `Full page chart` | Title, Chart | Data — full-page chart |
| 21 | `Chart with text` | Title, Text, Chart | Data — chart + callout text |
| 22 | `Comparison` | Title, Left, Right | Data — side-by-side comparison |
| 23 | `One panel` | Title, Panel, Caption | Data — one highlighted panel |
| 24 | `Three points` | Title, Point1, Point2 | Data — three key points |
| 25 | `Text and image right` | Title, Text, Picture | Body — image on right |
| 26 | `Text and image left` | Title, Text, Picture | Body — image on left |
| 27 | `Text and Infographic Right` | Title, Content | Body — infographic right |
| 28 | `Text and Infographic Left` | Title, Content | Body — infographic left |
| 29 | `Text and Infographic Right 2` | Title, Content | Body — infographic right variant |
| 30 | `Text and infographic Left 2` | Title, Content | Body — infographic left variant |
| 31 | `Quote or high impact with image` | Title, Quote, Picture | Pull quote — with image |
| 32 | `Quote or high impact` | Title, Quote | Pull quote — text only |
| 33 | `Next steps` | Title, Step1, Step2, Step3 | Closing — next steps |
| 34 | `Closing` | Title, Content | Closing — standard |
| 35 | `Title Only` | Title | Blank with title bar |
| 36 | `Blank` | *(none)* | Fully blank — custom builds only |
| 37 | `Blank Accessibility` | Title | Blank with hidden title for a11y |
| 38 | `Closing with Image` | Picture, Title | Closing — image background |
| 39 | `Closing slide` | Title | Closing — heart/brand mark |
| 40 | `CVS logo on white` | Title | Standalone logo slide — white bg |
| 41 | `CVS logo on red` | Title | Standalone logo slide — red bg |

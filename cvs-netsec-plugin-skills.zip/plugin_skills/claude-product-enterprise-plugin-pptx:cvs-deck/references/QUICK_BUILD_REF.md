# CVS Quick Build Reference

## Setup (always start here)
```python
import sys; sys.path.insert(0, 'assets')
from cvs_utils import *          # color constants, helpers, open_template
prs = open_template()            # embeds CVS master (bundled template ships pre-stripped; this is a no-op safety net)
```

## Colors
| Constant | Hex | Use |
|---|---|---|
| `CVS_RED` | CC0000 | Accents, eyebrows, icons on light bg |
| `CVS_NAVY` | 0A1F3C | Hero bg, dark dividers, closing slides |
| `CVS_WHITE` | FFFFFF | Text on dark bg, icons on dark bg |
| `TEXT_DARK` | 1A1A1A | Titles, primary body text |
| `TEXT_GRAY` | 444444 | Secondary body text, captions |
| `TEXT_LIGHT` | 868686 | Footer text, muted labels |
| `SURF_WARM` | F5F1EC | Light warm background panels |
| `SURF_COOL` | F0F2F5 | Light cool background panels |
| `BORDER_SOFT` | D8D3C8 | Dividers, card borders |

## Grid
- **Slide:** 13.33" × 7.50"
- **Safe area:** x: 0.5"–12.83", y: varies by title tier → 6.9"
- **Footer zone:** y: 7.0"–7.5" (reserved — nothing below y=6.9")
- **Left margin:** 0.5"  |  **Content width:** 12.3"

## Adaptive title tiers
| Title length | Font | Box h | `content_y` |
|---|---|---|---|
| < 40 chars | 32pt bold | 0.90" | 1.80" |
| 40–65 chars | 26pt bold | 1.30" | 2.18" |
| 65–90 chars | 22pt bold | 1.60" | 2.55" |

```python
content_y = add_title(slide, title_text, eyebrow="Section Name")
# content_y is the y-coordinate where body content starts — always use the return value
```

## Slide factory — use these, not add_slide() directly

```python
# Cover — layout has built-in logo + heart; no footer on covers
slide = cover_slide(prs, "Presentation Title", "Presenter Name | CVS Health | Month Year")

# Content — master provides logo + confidentiality + page number automatically
slide = content_slide(prs)                        # 'Title and Content' (default)
slide = content_slide(prs, 'Two Content')         # two-column
slide = content_slide(prs, 'Divider red')         # section break

# Custom (rare) — master suppressed; add footer elements manually if needed
slide = blank_slide(prs)
add_title(slide, title); add_confidentiality_text(slide); add_footer(slide, n)
```

## What the master provides automatically (on all content_slide() slides)
| Element | Position | Source |
|---|---|---|
| CVS Health logo | bottom-right y≈6.97" | Slide master `Graphic 13` |
| Confidentiality text | bottom-left y≈7.03" | Slide master `TextBox 12` |
| Page number | bottom-left y≈6.96" | Slide master `Content Placeholder 8` |

**Do NOT add these manually on content slides — the master handles them. Only add them manually on `blank_slide()` slides where suppress_master() was called.**

## Required on every slide
```python
content_y = add_title(slide, title_text, eyebrow="Section Name")
# For content_slide(): master handles footer — nothing else needed
# For blank_slide(): call add_confidentiality_text(slide) and add_footer(slide, n)
# For cover_slide(): layout handles logo + heart — nothing else needed
```

## Common layouts (pass to content_slide())
```
'Title and Content'     # Standard body (most slides)
'Two Content'           # Two columns
'Three Content'         # Three columns
'Comparison'            # Side-by-side comparison
'Five Content Journey'  # Process / journey map (5 steps)
'Quote or high impact'  # Pull quote
'Divider red/navy/gray' # Section break
'Closing slide'         # Closing — heart/brand mark
```

## Icon quick-add
```python
copy_icon(slide, 'Stethoscope', x=0.5, y=content_y, w=0.5, h=0.5)
# color_hex defaults to CVS_RED_HEX; use 'FFFFFF' on dark backgrounds
# See references/icon-cheat-sheet.md for intent → label mapping
```

## Checklist (every build before saving)
- [ ] Cover uses `cover_slide()` — not Blank layout
- [ ] Content slides use `content_slide()` — master provides footer automatically
- [ ] `blank_slide()` used only when no named layout fits
- [ ] Title added with `add_title()` — never hardcode 32pt
- [ ] No content below y=6.9" (footer zone reserved)
- [ ] Icons recolored — `copy_icon()` does this automatically
- [ ] Red appears somewhere on every content slide

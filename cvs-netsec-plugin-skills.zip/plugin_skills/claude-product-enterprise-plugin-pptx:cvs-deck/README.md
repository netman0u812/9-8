# CVS Health PowerPoint Skill — Maintainer README

**Package version:** 0.1.2 (General Availability)
**Last updated:** August 2026
**Author:** Ben Dundee ([Ben.Dundee@cvshealth.com](mailto:Ben.Dundee@cvshealth.com))
**Maintained by:** CECI Team
**Questions:** Contact Ben Dundee or your Claude administrator; BrandCenter@CVSHealth.com for brand asset questions

---

## What This Skill Does

This skill enables Claude to build CVS Health-branded PowerPoint presentations. When installed, Claude can:

- Build on-brand decks from scratch using the bundled Everyday Template — the CVS slide master is embedded in every output file, so PowerPoint recognizes it as a CVS-themed deck
- Select from 6 built-in cover layouts and matching closing layouts
- Look up and insert icons from the bundled Iconography Library (1,228 icons, vector-copied — not rasterized)
- Apply proven content patterns for business slides (exec summaries, status dashboards, journey maps, 30-60-90 plans, etc.)
- Follow CVS brand guidelines automatically — colors, typography, layout grid, and a QA checklist run before every delivery

---

## Architecture — Local-First

Everything a standard build needs is bundled in the package itself. **No SharePoint / M365 connector is required for normal use.**

```
cvs-pptx/
├── README.md                        ← You are here
├── SKILL.md                         ← Claude's instructions (the "brain")
├── assets/
│   ├── manifest.json                 ← Asset registry: what's bundled, refresh procedure
│   ├── cvs_utils.py                  ← Slide factory helpers (open_template, cover_slide, content_slide, add_title, icon recolor, etc.)
│   ├── icon-index.json               ← Label → {slide, shape} lookup for the icon library
│   ├── build_icon_index.py           ← Regenerates icon-index.json after an icon library refresh
│   ├── templates/everyday_2026.pptx  ← Base template: 42 layouts (6 covers, ~30 interior, 6 closing), 0 content slides
│   ├── libraries/Iconography_Library_01_2026.pptx
│   └── marks/                        ← CVS logo + 8 heart PNG variants (solid/outline × red/white × reg/sm)
└── references/
    ├── CVS_Slide_Style_Guide.md     ← Full brand rules: colors, fonts, layout grid, code recipes
    ├── QUICK_BUILD_REF.md           ← Always-read cheat sheet: setup, colors, grid, title tiers
    ├── visual-vocabulary.md         ← Recipes for hearts, hexagons, funnels, hero quotes, palette schemes
    ├── cover-registry.md            ← Quick-Match guide to the 6 built-in covers
    ├── slide-layout-registry.md     ← Layout index for the Everyday Template + Chart Library
    ├── icon-cheat-sheet.md          ← Intent → exact icon label mapping
    ├── icon-registry.md             ← Icon category browsing (when the cheat sheet doesn't cover it)
    ├── inspiration-patterns.md      ← Named content patterns (exec summary, 30-60-90, RACI, etc.)
    └── layout-quick-ref.md          ← Extended layout index
```

### What's bundled vs. not

| Asset | Status | Notes |
|---|---|---|
| Everyday Template | Bundled | `assets/templates/everyday_2026.pptx` — source of covers, interior layouts, closing layouts |
| CVS Logo + Hearts | Bundled | `assets/marks/` |
| Icon Library | Bundled | `assets/libraries/Iconography_Library_01_2026.pptx`, indexed in `icon-index.json` |
| Cover Library (53 extra covers) | Not bundled, no fallback | Excluded for size. Use the 6 built-in covers only. |
| Pictogram Library | Not bundled, no fallback | Never had a working asset source. Use icons instead. |
| Chart Library | Not bundled | Not currently fetched — future enhancement. See `manifest.json → not_bundled` if this ever gets built out. |

**Important:** the Cover and Pictogram Libraries have no live SharePoint fallback. An earlier version of this skill referenced a "fetch the full library" escape hatch for both — that URI pointed at a personal SharePoint drive, not a shared location, so it would fail for anyone else. That escape hatch has been removed. If a future version bundles either asset for real, update `assets/manifest.json`, `references/cover-registry.md` (or a new pictogram registry), and re-add the relevant guidance to `SKILL.md`.

**Executive Template:** used sometimes for external/C-suite decks, but out of scope for this skill — the >99% use case is the Everyday Template, and `open_template()` only supports that one file. Descoped intentionally, not an oversight; `references/template-uri.md`, which used to document its SharePoint location, was removed in v0.1.2 along with the rest of that file's dead content. If Executive Template support is ever added, it needs a real code path (a second `open_template()`-style function, a way to choose between them) — the old file's contents wouldn't have been enough on their own.

---

## Updating the Package

### When to update

- CVS Brand Center releases new or updated template files (typically January each year)
- New icons are added to the icon library
- The style guide is revised (colors, fonts, layout rules change)
- New inspiration patterns are approved for org-wide use

### How to update

**Step 1 — Identify what changed**, then edit the relevant file:

| If this changed... | Edit this file |
|---|---|
| Template file moved, renamed, or replaced | `assets/manifest.json` — update `source_uri`/`sourced` date; replace `assets/templates/everyday_2026.pptx`; bump `ASSET_VINTAGE` in `SKILL.md` |
| New icons added to the icon library | Replace `assets/libraries/Iconography_Library_01_2026.pptx`, re-run `python3 assets/build_icon_index.py`, update `references/icon-registry.md` / `icon-cheat-sheet.md` |
| New slide layouts in the template | `references/slide-layout-registry.md` |
| New cover or closing variants added to the template itself | `references/cover-registry.md` |
| Brand color or font changes | `references/CVS_Slide_Style_Guide.md` **and** `assets/cvs_utils.py` color constants **and** the Fast Reference table in `SKILL.md` — keep all three in sync; a past color-drift bug came from these three drifting apart |
| New business content patterns approved | `references/inspiration-patterns.md` |

**Step 2 — Update the version**

At the top of this README and in `SKILL.md`'s frontmatter, bump the version. Semantic versioning:
- **Patch:** typo fixes, minor additions
- **Minor:** new registry entries, new layouts, new patterns
- **Major:** new template source year, structural reorganization, a bundled Cover or Pictogram Library

**Step 3 — Repackage and distribute**

```bash
python -m scripts.package_skill /path/to/cvs-pptx /path/to/output/
```

Colleagues install the resulting `.skill` file via **Claude → Settings → Skills → Upload Skill**. The new version replaces the old one automatically.

---

## File Format Reference

All reference files are Markdown (`.md`) — a plain text editor works fine for edits. The `.skill` file is a ZIP archive; rename it to `.zip` and extract to inspect contents before distributing.

---

## Version History

| Version | Date | Changes |
|---|---|---|
| 0.1.2 | August 2026 | **Patch.** Enterprise-distribution review pass: fixed a footer contradiction (a leftover manual-footer section told the model to duplicate what the master already provides automatically); removed pptxgenjs content package-wide, including a full conversion of `references/visual-vocabulary.md` (10 recipes) found during verification — two of its recipes (heart assets, icon fetching) documented workflows already superseded by the local-bundling and vector-copy approaches this skill actually uses, and a color-drift bug was found and fixed between its palette and `cvs_utils.py`'s; reworded nine spots that described the template-strip step as removing "58 slides," which stopped being true once the bundled template started shipping pre-stripped; removed `references/template-uri.md` entirely after an audit found almost nothing in it was still load-bearing (redundant with `manifest.json`, superseded by local bundling, or referencing an Executive Template capability confirmed as an intentional descope, not an oversight — now documented as such); added a surface-detection step and an Output Contract section, both self-contained with no dependency on other skills; consolidated version numbering onto this single canonical number, removing a separate, never-fully-retired "v1.3"/"v1.4" scheme that had been running in parallel since before the v0.1 GA reset; and dropped a per-file token-count column from the reading list that nothing in the skill's logic actually depended on. See SKILL.md Changelog for full detail. |
| 0.1.1 | August 2026 | **Patch.** First repackage since GA — bundles patches 1–3. Fixed placeholder ghosting: `add_title()` now writes into the real title placeholder instead of a floating textbox drawn over it (see SKILL.md Changelog, patch 3, for the full root-cause writeup). Fixed a `cover_slide()` bug hardcoding presenter placeholder idx 1. Removed all 58 example content slides from `everyday_2026.pptx` and cleared baked example text from all 42 layouts' placeholders — confirmed unused in practice via a build-history audit, and the source of the ghosting risk when reused via `duplicate_slide()`. Also folds in patch 1 (template metadata remediation) and patch 2 (removed embedded chart workbooks), neither of which had bumped the version number at the time. Template file: 4.2MB → 238KB; package: 7.1MB → 3.3MB. Icon library untouched. |
| 0.1 | July 2026 | **General Availability.** Version reset — everything before this was internal beta. Fixed a color-drift bug in `cvs_utils.py` (navy/text colors didn't match documented brand palette). Removed the Cover Library and Pictogram Library fallbacks (both pointed at a personal SharePoint drive with no valid shared-location replacement); the skill now supports only the 6 built-in covers and the bundled icon library. Removed a stale compiled artifact and a hardcoded example name. Rewrote this README to match the current local-first architecture. |

---

## Contact

**Author:** Ben Dundee ([Ben.Dundee@cvshealth.com](mailto:Ben.Dundee@cvshealth.com))
For questions about brand assets, contact **BrandCenter@CVSHealth.com**
For questions about this skill package, contact the CECI team or your Claude administrator.

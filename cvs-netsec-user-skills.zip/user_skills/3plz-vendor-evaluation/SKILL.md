---
name: 3plz-vendor-evaluation
description: Use for anything related to the 3PLZ program — third-party/partner connectivity zero-trust platform vendor evaluation (F5 Distributed Cloud vs Cloudflare Zero Trust, plus Zscaler and Cisco as eliminated candidates), the seven-dimension CR-01–CR-06/CR-SS scoring model, POC Phase 3 functional testing, the Oct 1 2026 final selection, or ECMG governance-flow alignment (12-step onboarding, Tenant-owns-the-connection / APM_ID-owns-the-service model). Trigger this whenever "3PLZ," "F5 Distributed Cloud," "Cloudflare Zero Trust," "Presidio," "WTIT," partner/vendor connectivity, mTLS proxy, SSH split-proxy, or partner SFTP/VPN modernization comes up, even if the user doesn't say "3PLZ" by name. Also consult cvs-netsec-context for shared org facts and leadership-doc-drafting for board-brief formatting conventions.
---

# 3PLZ Vendor Evaluation

**Last refreshed from program documents dated Aug 20–21, 2026** (journey overview v40, governance companion v7, live connection inventory). Where this contradicts an older assumption, the newer figure below is the one to use.

## Program scope & inventory (updated)

3PLZ replaces CVS/Aetna's ungoverned partner connectivity sprawl with a governed zero-trust platform. The live connection inventory (as of Aug 20, 2026) now shows:
- **685 IPSec VPN connections** (245 at SHEA, 236 Woonsocket, 107 WDC, 97 MDC), spanning **562 unique partners**
- **675 of those VPNs have a defined policy; 10 are flagged "NO POLICY - VIOLATION"** — treat this as a live, named finding, not a rounding error, when discussing enforcement gaps
- **20 MPLS private lines (legacy NET4WIR)** and **75 MPLS private lines (FTD-managed)**
- Total inventory framed in program materials as **~780 characterized connections**, "characterized down to crypto posture and enforcement mode"
- Core insight unchanged: **these connections were never governed at all** — this remains the justification for the program.

Older figures ("1,000+ partner connections," "~30,000 SFTP relationships," "643 VPN/MPLS records, 543 unique partners, 82 confirmed active") came from an earlier snapshot — use the numbers above going forward, and flag the discrepancy if a stakeholder cites the old figures.

## Current program phase

- **Current phase: POC Phase 3C — Functional Testing, Jul 15–Aug 31, 2026 (active).**
- Phase 1 (Architecture) and Phase 2 (Vendor RFC & Selection) are **complete** as of Mar 2026.
- Phase 3A (POC Kick-off) and 3B (Testing Harness Development) are **complete**; 3D (Vendor Selection) is **upcoming, Sep 1–Oct 1, 2026**.
- **Phase 5 / Final Platform Selection: October 1, 2026.** Use "Oct 1, 2026" as the specific decision date going forward, not "mid-October" or "the October deadline" generically — program materials now state both, so either is defensible, but Oct 1 is the more precise anchor.
- Test harness: Azure-based, four-zone topology (Zone 1 control, Zone 2 partner, Zone 3 vendor, Zone 4 CVS), five concurrent tenant contexts, validated across both F5/WTIT and Cloudflare/Presidio environments.

## Vendor field: now four evaluated, two in POC

A **seven-dimension weighted scoring model** was used at Phase 2 (RFC & Selection, complete Mar 31, 2026) across four vendors. This supersedes any older two-vendor-only framing:

| Dimension | Requirement ID | Weight | F5 Dist. Cloud | Cloudflare ZT | Zscaler | Cisco/SecHub |
|---|---|---|---|---|---|---|
| Per-Tenant CA Isolation | CR-01 | 25% | 9 | 7 | 3 | 3 |
| SSH Managed Access | CR-02 | 20% | 9 | 7 | 4 | 4 |
| Lifecycle Automation (API) | CR-04 | 20% | 9 | 8 | 5 | 3 |
| DNS Segmentation | CR-03 | 10% | 8 | 9 | 4 | 3 |
| Outbound Governed Access | CR-06 | 10% | 8 | 9 | 6 | 5 |
| Self-Service API Readiness | CR-SS | 10% | 8 | 8 | 5 | 2 |
| Multi-Tenant Scale | CR-05 | 5% | 9 | 8 | 7 | 6 |
| **Weighted Score** | | | **8.85** | **7.85** | **4.40** | **3.55** |

- **F5 Distributed Cloud and Cloudflare Zero Trust were both selected for POC.** Zscaler and Cisco Secure Access (SecHub365) were **not selected** — both were assessed as network/tunnel-layer platforms, while 3PLZ requires application-layer (Layer 7) delivery, which determined the split.
- Keep the **CR-01 … CR-06 / CR-SS** requirement-ID scheme when discussing scoring or gaps going forward. This replaces the older **G-01…G-12 gap-register numbering** as the primary evaluation framework in current program materials — the newer documents don't reference G-01–G-12 at all. If a stakeholder or older doc references G-numbers, treat it as the prior framework and clarify which one is in use before answering.

## Vendor status detail (POC Phase 3, current)

**F5 Distributed Cloud (with SI WTIT)** — Medium risk, primary POC candidate (weighted score 8.85).
- XC namespace architecture gives native structural per-tenant isolation; per-tenant CA and DNS segmentation align with platform design intent.
- SSH managed access with credential vaulting is a native platform capability, not an adjunct.
- API-driven lifecycle automation is the primary operational model; offboarding residual state is described as "a solved problem."
- Main risk is **systems-integrator execution** (WTIT delivery discipline), not platform capability. CR-06 (outbound governed access via XC) is less battle-tested than F5's inbound proxy heritage and carries moderate implementation risk.

**Cloudflare Zero Trust (with SI Presidio)** — Medium risk, CR-02 is the central open question (weighted score 7.85).
- **PQC IPSec is now confirmed supported** — this is resolved, not a gap.
- **The open architectural item has changed framing**: it is no longer described as "no E2E private transit" as a blanket blocker. Current framing is narrower — **CR-02, no native SSH split-proxy capability**. Client-based SSH (browser-rendered terminal via Cloudflare Access) does not satisfy the transparent managed-session model; production delivery would need in-house split-proxy development plus SI-developed integration.
- E2E private-transit testing is **on hold pending Magic WAN beta access**; Cloudflare's own roadmap targets a closed beta for E2E Private-to-Private by **Dec 31, 2026 — after the Oct 1 decision date**.
- Cloudflare's native DNS control, edge delivery, and Gateway forward proxy are strengths directly addressing CR-03 and CR-06; Terraform-native API surface supports CR-04.
- VP of Product **Steve Goldsmith** has offered recurring engagement given these findings (carry this forward from the prior version of this skill).

**Do not describe Cloudflare's remaining gap as an unqualified "platform-level blocker on all six connection patterns."** That was the framing in an earlier snapshot. The current, more precise framing is CR-02 (SSH split-proxy) plus E2E-transit timing risk — narrower and more specific than before.

## Selection criteria (Phase 5, Oct 1 2026)

- Evidence-based, comparative, **no partial credit for capability demonstrated in isolation** — every gate must hold in a live multi-tenant context.
- **CR-01 (per-tenant mTLS CA isolation) is the primary gate at 25% weight** — the highest-weighted requirement and where the platforms differ most fundamentally.
- CR-02 + CR-04 are grouped as "operational" gates in Phase 5 materials.

## Governance (ECMG alignment — v7 companion, supersedes v5)

- 3PLZ's governance value proposition: it becomes **the first single administrative plane** collecting contract info, risk info, and application-profiling/consumption context that today lives scattered across Procurement/Legal, ad hoc risk snapshots, and nowhere at all, respectively.
- **12-step onboarding flow** mapping 3PLZ onto ECMG's live governance model — "one front door, one system of record," not a parallel intake path. Preserve this step count/numbering when referencing or extending it (consistent with the prior skill version).
- Program-wide risks, cross-functional dependencies, and funding decisions live in **Board Investment Brief v6, Section 7** — the governance companion cross-references rather than duplicates this, to avoid two conflicting owner lists.
- **Updated stakeholder/owner list** (add to, don't replace, the existing 3PLZ stakeholder list):
  - **Soleil Doce** — GRC: enterprise control mappings, attestation requirements, exception governance, and the escalation point for the PQC compliance-threshold ownership question. (Note: prior skill spelled this "Soleil Dolce" — confirm correct spelling with the user if it matters for a formal document.)
  - **Jeff Roach** — Technology Partner Office: vendor sourcing, licensing, supplier oversight for the platform itself (distinct from ECMG role/process questions).
  - **Lenny Guardino** — Network Engineering: boundary architecture, SNAT/DNS design, migration sequencing for the connectivity estate.
  - **Lawrence Crockett** — Program Development & Strategy: owns adopting the Tenant Container Object and Live Service Catalog as ECMG enterprise patterns, and the open question of who owns their schema (3PLZ platform team vs. ECMG).

## Testing & scoring artifacts (carried forward, still accurate)

- A full test suite exists for both vendor/SI pairs (F5/WTIT and Cloudflare/Presidio) covering POC functional testing.
- Requirement CR-02 = SSH managed access (dual-proxy/split-proxy model) — F5 native support; Cloudflare's known gap.
- Board Investment Brief v6 and governance alignment companion (now **v7**, not v5) exist with a six-phase roadmap and Section 7 risks/dependencies. **Use v7, not v5, going forward** — v7 is the current companion document.

## Stakeholders (merged list)

Lawrence Crockett, Vincent Scales, Natalie Henderson, Soleil Doce (formerly listed as "Dolce"), Kris Proto, Mani Ponniah, Dino Kotenoglou, Jeff Roach (Technology Partner Office), Lenny Guardino (Network Engineering); SI contacts Nathan, Ben, Joe. Cloudflare: Steve Goldsmith (VP of Product).

## Working-style notes specific to this update

- The program materials this update is based on are self-described as a **one-year retrospective** ("a year ago... a year later...") — useful framing if asked to draft a status update or annual review for 3PLZ.
- When a stakeholder cites the older gap-register (G-01–G-12) or older inventory figures (1,000+/~30,000 SFTP), treat that as the prior snapshot rather than silently correcting them — surface the newer figures and let the person reconcile which one their document should use.

---
name: nac-ztna-fpms
description: Use for NAC/ZTNA modernization (Forescout refresh, Claroty/IoT posture), the Firewall Policy Management System (FPMS), intent-based policy delivery framework, and Tufin-vs-FPMS scope questions. Trigger on "Forescout," "NAC," "ZTNA," "FPMS," "intent-based policy," "Tufin," "CCD EDL," or firewall rule builder/topology questions, even if the specific program name isn't used. Also consult cvs-netsec-context for the shared visibility/source-of-truth problem this work is built around.
---

# NAC/ZTNA Modernization & FPMS

## Shared root problem

CVS has no reliable network/asset source of truth (see cvs-netsec-context). Both Forescout and FPMS are partial fixes for this same root problem — when scoping new work in either area, check whether it's duplicating an inventory effort that already exists elsewhere (CCD EDL catalog, Forescout source-of-truth integration) before proposing a new one.

## Forescout NAC refresh

- Architecture: **10 appliances across Shea DC and RI DC.**
- Three Phase 1 milestones:
  1. Platform Refresh (1A)
  2. Source-of-Truth Integration (1B)
  3. RADIUS Enforcement Validation (1C)
- Posture telemetry sources feeding Forescout: **Claroty** (IoT/OT), plus MDM, Zscaler ZIA, Qualys, CrowdStrike, and Tanium. When discussing posture data gaps, check which of these six sources is actually missing rather than treating "posture telemetry" as a single monolithic feed.

## FPMS (Firewall Policy Management System)

- Core design: a **topology-aware firewall rule builder** grounded in live Panorama estate data.
- Uses a **two-question framework**: (1) define resource X, (2) grant access to resource X. Keep this framing when explaining or extending the tool's UX/logic — it's the organizing principle, not just a data model detail.
- Six-category object model; **ten canonical traffic flow patterns (P1–P10)**.
- Zone constraint mapping file: `ng_zone_map.json`, linking 728 CCD EDL objects to Panorama zone names.
- Real CCD EDL catalog embedded in the tool: **3,243 SO (Standard Objects), 728 NG (Next-Gen) objects.**
- Estate finding baked into the tool's rationale: 98% of 15,629 rules use Alert-All-SPG (consistent with the cvs-netsec-context figure — minor variance is from different snapshot dates, not a contradiction).

## Intent-based policy delivery framework

- 13-document corpus covering:
  - P1–P6 MAC (Move/Add/Change) processes
  - A broker-agnostic object store
  - FPMS as the PA-native rule builder
  - CSNA as the observation/evidence plane
- A formal response to an FRW v1.1 RFP argued for **scope expansion** based on confirmed estate findings — when asked to draft similar RFP responses, ground the argument in specific estate findings (the stats in cvs-netsec-context) rather than general capability claims.

## Tufin vs. FPMS positioning

A position paper opposed extending Tufin to Palo Alto, recommending a **two-track model**: Tufin stays scoped to FTD/ASA/Check Point, FPMS handles PA. If asked about Tufin/FPMS overlap or consolidation, default to this two-track position rather than proposing a single-tool consolidation, unless new information changes the picture.

## RAPD cross-reference

Forescout also appears in the RAPD (rogue AP detection) replacement architecture alongside Cisco Catalyst Center and Palo Alto/Panorama — see `ids-ips-policy-rebuild` for that PCI-compliance framing.

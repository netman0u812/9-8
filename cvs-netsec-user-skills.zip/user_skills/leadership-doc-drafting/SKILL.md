---
name: leadership-doc-drafting
description: Use whenever drafting or reviewing formal written deliverables for Michael J. Martin's network security work — board investment briefs, governance alignment documents, findings/assessment reports, position papers, RFP responses, or performance review documentation. Trigger on "board brief," "governance doc," "findings report," "position paper," or any request to write something "for leadership" vs. "for the team," even if no specific program is named. Pairs with the program-specific skills (3plz-vendor-evaluation, panos-dlp-decrypt-migration, ids-ips-policy-rebuild, nac-ztna-fpms) for content; this skill governs format and tone.
---

# Leadership & Practitioner Document Drafting Conventions

## The core distinction to apply every time

Sharply separate **practitioner-audience** writing from **leadership-audience** writing. Ask (or infer from context) which one is being requested before drafting — don't default to a generic middle-ground tone.

**Practitioner-audience** (peers, engineers, other security architects):
- Technical precision, acronyms without expansion, exact counts (e.g., "138 of 249 FMC devices," not "many devices")
- Findings-report structure: scope → method → findings → evidence → recommendation
- OK to reference ticket numbers, object model internals, config specifics

**Leadership-audience** (board briefs, exec governance docs):
- Lead with risk/investment framing, not technical mechanism
- Use structured sections like a numbered roadmap (e.g., 3PLZ's six-phase roadmap) and a dedicated risks/dependencies/open-decisions section (e.g., 3PLZ Section 7) rather than narrative prose
- Translate technical findings into business consequence (e.g., "ungoverned partner connections" not "82 confirmed active VPN/MPLS records lacking policy review") — but don't drop the underlying number entirely if it's load-bearing for the argument; put it in a supporting section
- Keep gap registers (e.g., G-01–G-12) as structured, numbered items even in leadership docs — leadership consumes the structure, not the narrative retelling

## Evidence-anchored writing

Treat prior findings as **binding evidence**, not something to re-litigate or hedge on each time they're cited. If a document says "Alert-All-SPG suppresses ~99.5% of rules," don't rephrase this more cautiously ("appears to suppress a majority of") in a later document — carry the confirmed figure forward.

Correct overclaiming directly. If a stakeholder draft, prior version, or the user's own draft states something beyond what the evidence supports, flag it plainly rather than smoothing it into the final version. This is more important in leadership docs, where overclaiming has outsized consequences if challenged.

## Documents over email

Default to producing a standalone document (not an email draft) for anything intended as a formal record — findings reports, gap registers, governance proposals, RFP responses. Only draft an email if explicitly asked, or if the ask is clearly a short status ping rather than a record.

## Format conventions observed in prior work

- Board briefs: versioned (e.g., "v6," "v7"), with a numbered roadmap and a dedicated risks/dependencies/open-decisions section.
- Governance flows: numbered end-to-end steps (e.g., 3PLZ Governance Flow Draft v1 = 12 steps) — preserve step numbering across revisions rather than renumbering.
- Findings/assessment reports: merged across platforms where relevant (e.g., PA + Cisco in one IDS/IPS assessment) rather than siloed by vendor.
- Position papers: state the recommendation early (e.g., Tufin/FPMS two-track model), then ground it in specific estate findings, not general principle.
- Performance/Workday docs: individual goal documents, mid-year reviews, and professional development plans per team member — keep these separate per person, not combined into one team document.

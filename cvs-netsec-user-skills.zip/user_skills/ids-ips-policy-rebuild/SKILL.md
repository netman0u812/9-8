---
name: ids-ips-policy-rebuild
description: Use for IDS/IPS policy framework rebuild work (NETSEC-IDS-01/02/05), Palo Alto and Cisco FMC/Sourcefire enforcement assessments, IPS licensing/EOL tracking, correlation log analysis (beacon heuristics, IRC C2 detection), and RAPD (rogue access point detection) PCI compliance work. Trigger on "IDS," "IPS," "FMC," "Sourcefire," "Alert-All-SPG," correlation logs, C2 detection, or rogue AP/wireless detection, even without the NETSEC-IDS ticket numbers being mentioned. Also consult cvs-netsec-context for the estate-wide Alert-All-SPG and FMC licensing facts this skill assumes.
---

# IDS/IPS Policy Framework Rebuild

## Governing findings — treat as binding, don't re-derive

- Alert-All-SPG suppresses enforcement on ~99.5% of ~15,600 CVS Panorama rules.
- 138 of 249 FMC-managed devices lack IPS licensing.
- 15 Sourcefire/FMC devices are past end-of-support.
- Skyhigh SWG certificate verification rules are all wired to "continue" despite being named as block rules — the **same governance pattern** as Alert-All-SPG. When writing findings, name this as a recurring pattern across platforms (rules/profiles named as enforcing but configured as permissive), not as two unrelated issues.
- Cisco ASA/FTD infrastructure is confirmed **out of scope** for forward-looking work — don't propose new IPS capability builds on ASA/FTD; treat it as legacy to be sunset or worked around.

## Deliverable format

The core artifact is a **merged HTML enforcement assessment across PA and Cisco platforms** — cross-platform, not siloed by vendor. When producing or extending IDS/IPS findings reports, default to this merged-platform format so PA and FMC findings sit in one comparable view rather than separate reports.

## Correlation log analysis

Analysis of correlation log data from **MID-PAN-PROD-01** has focused on beacon-heuristics and IRC C2 (command-and-control) detection objects, producing formal findings reports. When asked to analyze correlation logs or C2 detection, follow this same formal-findings-report structure rather than an ad hoc summary, and check whether MID-PAN-PROD-01 is the relevant source device before assuming a different one.

## RAPD (Rogue Access Point Detection)

- Framed as a **PCI DSS v4.0 compliance document** addressing Requirements 11.2.1 and 12.10.1.
- Purpose: replace Armis RAPD capability with **Cisco Catalyst Center Rogue Management/aWIPS, Forescout, and Palo Alto/Panorama**. When discussing RAPD, keep this three-way replacement architecture in mind rather than proposing a single-vendor replacement for Armis.
- A network TAP incident at the **Shea Data Center** surfaced undocumented MPLS infrastructure and EOL Cisco Firepower/FMC devices unpatched since 2022 — treat this as a live finding with compliance implications (unpatched EOL devices), not just an infrastructure-discovery footnote.

## Ticket/framework references

NETSEC-IDS-01, -02, -05 are the tracking tickets for this rebuild. If asked to draft or update related documentation, keep references to these ticket numbers rather than inventing new ones, and ask which of the three is in scope if ambiguous.

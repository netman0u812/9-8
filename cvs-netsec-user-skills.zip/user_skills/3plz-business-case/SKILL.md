---
name: 3plz-business-case
description: Use for the 3PLZ Business Case / Board Investment Brief — the $20M–$26M five-year funding ask for the "Governed Third-Party Connectivity Platform" (aka Third-Party Landing Zone), its risk narrative, financial model, phased implementation plan (Phase 0–5), success metrics, risks/dependencies/open decisions, and technical appendices (architecture, identity model, partner classification, service catalog). Trigger on "business case," "Board Investment Brief," "3PLZ funding," "tenant-based platform cost," "$750K per tenant," "service catalog," "boundary shift," or requests to draft/update/summarize/present these documents, even if the user doesn't name them directly. Also consult cvs-netsec-context for org facts, 3plz-vendor-evaluation for POC/vendor status, and leadership-doc-drafting for board-brief tone and formatting conventions.
---

# 3PLZ Business Case & Board Investment Brief

Two closely related documents underlie this skill:
- **WEN-Third_Party_Landing_Zone_Business_Case_v3.docx** — the full technical/financial business case, with 8 appendices (A–H) covering architecture, identity model, inspection, partner classification, service catalog, infrastructure, regulatory mapping, and POC status.
- **3PLZ_Board Investment Brief v7.docx** — the board-facing distillation of the same narrative, organized into 7 numbered sections, dated June 2026. **This supersedes "Board Investment Brief v6,"** which the 3plz-vendor-evaluation and governance-companion materials still reference — flag that cross-reference for correction if it comes up.

These two documents share nearly identical executive-summary language; treat the Business Case as the source of technical/financial detail and the Board Brief as the version to imitate for tone when drafting board-facing material.

## The ask (carry this framing into any summary or draft)

**Total investment: $20M–$26M over five years.** The Board is asked to approve three specific things, not just funding:
1. **Fund the platform** — modular, elastic, boundary-based connectivity infrastructure.
2. **Commit to the operating model** — a service-catalog-driven governance framework with **no bespoke exceptions**; new patterns are funded by the business function that needs them.
3. **Provide executive sponsorship for the boundary shift** — relocating third-party connectivity termination from inside enterprise data centers to a managed boundary exchange. This is explicitly framed as the most contested decision and the one requiring Board-level (not IT-level) mandate.

Keep these three decisions distinct when drafting — don't collapse them into a single "approve the budget" ask, since the operating-model and sponsorship asks are cultural/organizational commitments, not spending decisions.

## Headline risk stats (use verbatim — these are the anchors of the narrative)

- **25,000+** external data interactions annually across **500+** third-party partner relationships
- **$2B+** cost of a single breach event at enterprise scale (Change Healthcare 2024 is the named comparator)
- **267 days** — industry-average time to detect a third-party breach (the longest of any attack vector)
- Root architectural pattern named across Change Healthcare, MOVEit, SolarWinds, and Okta: **a trusted third-party channel that authenticated the connection and never verified the transaction**
- Current model's own cost: an estimated **60–70% operational overhead premium** over platform-based delivery, plus a **$3M–$5M firewall refresh cycle every 5–7 years**

## Financial model — unit economics

- **Cost basis: $750,000 per block of 25 tenant relationships.** A "tenant" = one partner/B2B relationship's full set of connectivity patterns, controls, onboarding, and lifecycle governance.
- At the current ~500+ partner estate, the VPN + private-circuit tenant population totals **~$15M**. The internet-direct transactional partner population is **still being modeled** and will land as a Phase 2 cost submission — don't quote a number for it, since none exists yet.
- Full 5-year breakdown: Tenant-based platform **$15M+**, self-service portal/governance platform **$3M–$4M**, service catalog pattern development **$1.5M–$2M**, organizational change/adoption **$1M–$1.5M**, ongoing 5-year operations **$1.5M–$2M/year**. **Total: $20M–$26M.**
- **Phase 1 ask is $3M–$4M**, requested immediately; every subsequent phase requires separate authorization at its own gate, contingent on the prior phase's outcomes. Don't present this as a single $20M+ up-front ask — the phased-gate structure is a deliberate governance feature of the pitch.

## Implementation plan — Phase 0 through 5

Preserve this phase structure and naming when referencing or extending the roadmap:

| Phase | Timeline | Proves | Key deliverables |
|---|---|---|---|
| **0 — POC & Vendor Selection** | Months 0–6 (through 9/30/26) | The technology | Complete Cloudflare + F5 POC validation; vendor recommendation and selection; funding approval |
| **1 — Pilot Deployment** | Months 6–10 (through 12/31/26) | The operating model | Onboard 5 representative partner connections across VPN/SFTP/API/leased-line; Connectivity Governance Council established |
| **2 — Foundation & Discovery** | Months 10–18 | Governance and inventory | Production platform foundation; complete partner inventory discovery; Wave 1 high-risk partner migration |
| **3 — Governance & Initial Expansion** | Months 18–30 | Standard patterns and controls | Certify initial service catalog (6–8 patterns); mandatory attestation process; chargeback/showback model |
| **4 — Enterprise Migration & Self-Service Platform** | Months 30–48 | Enterprise migration | Self-service portal; HTTPS/API mTLS enforcement; DNS steering; catalog covers >90% of use cases |
| **5 — Full Operating Model & Transformation** | Months 48–60+ | 3PLZ as mandatory platform | Exchange-based connectivity is default; legacy infrastructure retired; full tenant-based operating model |

Note: this Phase 0–5 numbering is the Business Case's own program structure and is **distinct from the "POC Phase 3A/3B/3C/3D" phase numbering** used in the 3plz-vendor-evaluation skill for the F5/Cloudflare POC specifically — the vendor-evaluation phases are nested inside this document's "Phase 0." Don't conflate the two numbering schemes when a stakeholder says "Phase 3."

## Success metrics (baseline → Phase 1 → steady-state)

- Partner connections with a named business owner: Unknown → 100% → 100% (maintained via attestation)
- Time to onboard a new partner: weeks-to-months → days (POC) → **<1 day** (self-service portal)
- Transactions with cryptographic transfer receipt: zero → all SSH/SFTP in POC scope → all transactions, all patterns
- Cross-tenant lateral movement incidents: undetectable → zero (structural isolation) → zero
- Service catalog coverage: zero → core patterns (VPN, SFTP, API, private circuit) → >90% of use cases
- Mean time to detect anomalous third-party session: 267 days (industry avg) → near-real-time behavioral alerting → automated detection <15 minutes

## Risks, dependencies, and open decisions

**Risks are paired with named owners** — preserve this pairing rather than listing risks generically:
- Incomplete partner inventory → third-party ownership team (Lenny's org) + GRC for attestation
- Cloud/boundary provisioning delays → Jeff Roach's team (cloud/platform) + Network Security (boundary design)
- Partner resistance/contract limitations → Procurement, Legal, Lenny's third-party team
- Inspection/logging volume cost growth → SOC/SIEM, DLP owners, PQC (where crypto lifecycle affects logging/certs)
- Legacy protocol exceptions → GRC (exception governance) + Network Security/app owners
- Insufficient dedicated engineering capacity → Security Engineering + Jeff Roach's team + platform ops

**Four named cross-functional dependencies, each a Phase 1 gate deliverable:**
- **GRC (Soleil Doce)** — control mappings, attestation requirements, exception process, audit evidence model
- **Technology Partner Office (Jeff Roach)** — vendor evaluation, sourcing, contract/renewal, supplier oversight; treats 3PLZ as a managed technology service, not a one-time security purchase
- **PQC** — certificate/key lifecycle review, PQC readiness, future migration guardrails for authentication/receipt mechanisms
- **Network Engineering (Lenny Guardino)** — landing-zone architecture, routing/segmentation/SNAT/DNS design, migration sequencing, run-state monitoring

**Open decisions requiring gate-level resolution before scaling past POC:** final platform provider, Year 1 tenant capacity, Year 2 scale target, self-service portal build-vs-buy, funding model (centralized vs. chargeback vs. hybrid), migration priority criteria, exception approval authority, Board reporting cadence, run-state ownership, and enterprise mandate scope (migrated connections only vs. all new/renewing relationships). Treat these as gate criteria, not implementation details — the doc is explicit that scaling past POC without resolving them is a governance risk in itself.

## Technical architecture (Appendix A–E — use for technical/practitioner-audience questions)

**Two control layers, always both present:**
- **Layer 1 — 3PLZ Gateway (3PLZ GW):** session identity verification (pubkey+OTP or mTLS), payload inspection pipeline (CDR, AV, DLP, schema validation), cryptographic transfer receipt generation, dual-proxy SSH inspection.
- **Layer 2 — Palo Alto NGFW (PA FW):** per-tenant zone enforcement, SNAT (partner IP opacity), DNS rewriting (name-based service addressing), App-ID/Threat Prevention, session metadata logging.
- **Boundary Exchange** (Equinix or equivalent): physical termination point, VM-Series firewall hosting, private peering fabric — this is what eliminates dedicated circuit provisioning for new partners.

**Three connectivity patterns**, each converging on the same identity/inspection/receipt outcomes via different mechanisms:
1. **Internet VPN (IPsec S2S)** — dedicated VM-Series instance per tenant, portable /32 tunnel anchor, /30 VTI transit, /27 SNAT block; traffic transits 3PLZ GW before PA zone policy.
2. **Direct Internet SSH/SFTP and HTTPS/API** — no VPN tunnel; 3PLZ GW is the sole identity/inspection boundary; Vault-injected short-lived credentials replace static API keys for outbound.
3. **Private Circuits (MPLS/Leased Line)** — terminate directly on PA two-zone config; carrier path assurance makes the full 3PLZ GW proxy unnecessary; behavioral anomaly baselines substitute for inspection on encrypted traffic.

**Four-way partner classification** (documented per-partner in the tenant record, reviewed at each attestation): Inspectable (full pipeline), Signature-only (structural inspection + PGP/GPG signature, content stays opaque), Encrypted-PHI (inspection deferred to a controlled decryption enclave, dual-hash receipt), Private Circuit (inline PA profiles + behavioral baseline). When asked about inspection depth for a partner, check which of these four classes applies rather than assuming full inspection.

**Service catalog patterns and current status** (as of this document): Internet VPN–SFTP/SSH (POC, in validation), Internet VPN–Application (POC, in validation), Direct Internet–SFTP/SSH (Phase 2, planned), Direct Internet–HTTPS/API (Phase 3, queued), Private Circuit (Phase 1, PA two-zone model), Web Application Access (Phase 3, queued), plus a standing "new pattern" track that is always business-funded per request.

## Working-style notes for this material

- **Preserve the "not a security project, an enterprise capability" framing** — the document is deliberate about positioning this as a business/operating-model transformation, not an IT security purchase. Don't reframe it as a security initiative when summarizing for a business audience.
- **The $20M–$26M figure is a range, not a point estimate** — keep the range intact rather than collapsing it to a midpoint unless specifically asked for one number.
- When asked to draft board-facing content from this material, follow `leadership-doc-drafting` conventions: lead with risk/investment framing, use the numbered-roadmap and dedicated risks/dependencies/open-decisions structure already present in Board Brief v7, and don't drop the underlying figures ($750K/tenant, 267-day MTTD, etc.) even when translating to business language.

---
name: cvs-netsec-context
description: Foundational context for Michael J. Martin's role as Lead Director of Network Security Engineering at CVS Health — org structure, team, cross-program glossary, estate-wide facts, and working-style conventions. ALWAYS consult this skill first for any CVS/Aetna network security, firewall, Palo Alto/Panorama, or security-program conversation, even if the specific program isn't named, since it provides shared vocabulary and facts the other program-specific skills (3plz-vendor-evaluation, panos-dlp-decrypt-migration, ids-ips-policy-rebuild, nac-ztna-fpms, leadership-doc-drafting) assume as background. Use this whenever the user references "the estate," "Panorama," "CVS/Aetna," his team, or asks for status across multiple programs at once.
---

# CVS Health Network Security Engineering — Context

## Role & Team

Michael J. Martin is Lead Director of Network Security Engineering at CVS Health. He owns:
- Firewall rule governance
- Advanced Palo Alto policy integration (Security profiles, IDS/IPS, Content, DLP/File)
- All advanced Panorama policy integration across a large multi-entity estate (CVS + Aetna infrastructure)

Team: one Senior Engineer, one Engineer, two Junior Engineers (referred to elsewhere as Art, Joe, John, and two junior engineers). Michael produces goal documents, mid-year reviews, and professional development plans for each via Workday.

Background: 24 years at McKinsey & Company prior to CVS.

## Active Programs (glossary)

| Program | One-line description | Skill to use |
|---|---|---|
| 3PLZ | Third-party/partner connectivity zero-trust platform; vendor evaluation (Cloudflare/Presidio vs F5/Distributed Cloud) | `3plz-vendor-evaluation` |
| FPMS | Firewall Policy Management System — topology-aware PA rule builder | `nac-ztna-fpms` |
| Intent-based policy delivery | 13-doc corpus, P1–P6 MAC processes, broker-agnostic object store | `nac-ztna-fpms` |
| Skyhigh-to-PA migration | SWG-to-Palo Alto DLP/decrypt parity | `panos-dlp-decrypt-migration` |
| TRv2 | Entra Tenant Restrictions v2 via PAN-OS forward proxy header injection | `panos-dlp-decrypt-migration` |
| IDS/IPS remediation | NETSEC-IDS-01/02/05 policy framework rebuild | `ids-ips-policy-rebuild` |
| NAC/ZTNA modernization | Forescout refresh, RAPD (rogue AP detection) | `nac-ztna-fpms` |

## Estate-wide facts (cite these verbatim when relevant — do not re-derive or approximate)

- ~15,600–15,629 Panorama-managed rules estate-wide; **Alert-All-SPG suppresses actual enforcement on ~99.5–98%** of them (a recurring governance anti-pattern: security profiles or rules *named* as blocking but wired to "alert"/"continue").
- The same governance pattern shows up in Skyhigh SWG certificate verification rules — all wired to "continue" despite being named as block rules.
- App-ID adoption is **~96% absent** estate-wide (i.e., almost all rules are port/protocol-based, not App-ID-based).
- Native PA Data Filtering profile objects are built but **unimplemented** — not wired to security policy rules.
- 138 of 249 FMC-managed devices lack IPS licensing; 15 Sourcefire/FMC devices are past end-of-support.
- CVS/Aetna have **45 confirmed RFC1918 (private IP) address collisions** post-2018 acquisition — a foundational infrastructure constraint that underlies multiple programs.
- CVS's dynamic list infrastructure (customer-maintained lists used by Skyhigh SWG) was **never migrated off Aetna-owned infrastructure** (both estates fetch from proxyconsole.aetna.com).
- Aetna's HTTPS decryption coverage gap is the **root upstream dependency** blocking DLP, IPS, and Content-ID inspection simultaneously (you can't inspect what you don't decrypt).
- Cisco ASA/FTD infrastructure is confirmed **out of scope** for forward-looking work — treat as legacy/sunset, not a target for new capability.
- CVS has a fundamental **asset and network visibility problem with no reliable source of truth** — this is why nearly every enforcement initiative ends up building its own partial inventory (CCD EDL catalog, FPMS zone map, Forescout source-of-truth integration, etc. are all partial fixes for this same root problem).
- The CCD Platform (Cloud/Config Data platform) is treated as a foundational data engineering capability underpinning multiple security programs — reference it rather than treating estate data feeds as one-off.

## Key stakeholders (cross-program)

3PLZ: Lawrence Crockett, Vincent Scales, Natalie Henderson, Soleil Dolce, Kris Proto, Mani Ponniah, Dino Kotenoglou; SI contacts Nathan, Ben, Joe.

## Working style — apply this to every deliverable

- **Evidence-anchored**: treat prior findings (estate stats above, gap registers, prior analysis) as binding evidence. Don't restate a finding more tentatively than the underlying data supports, and don't soften a confirmed gap into a "potential" one.
- **Documents over email** for anything that needs to be a formal record — default to producing a doc, not drafting an email, unless explicitly asked for the latter.
- **Audience-aware tone**: sharply distinguish practitioner-audience writing (technical precision, acronyms fine, cite exact rule/object counts) from leadership-audience writing (see `leadership-doc-drafting` skill for board-brief conventions).
- **Directly correct overclaiming.** If a draft, a stakeholder claim, or a prior analysis overstates confidence or scope beyond what the evidence supports, say so plainly rather than smoothing it over. This applies to Michael's own draft language too, if asked to review it.
- Don't present speculative gap-filling as fact — if a number or status isn't confirmed in known findings, flag it as an assumption to verify rather than presenting it as known.

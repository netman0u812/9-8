---
name: 3plz-lvcolo-hub
description: Use for the Las Vegas colocation (LV-COLO) 3PLZ firewall hub — the PA-5400 multi-tenant architecture that terminates IPsec and circuit partner connections, including zone/VR/VSYS design, IPAM address pools, SNAT/PNAT translation model, DNS proxy rewrite, DMZ segment design, the automation pipeline (tenant onboarding/offboarding/PSK rotation/service-map-change workflows), use-case catalogue (UC1-UC8), and open capacity/scale questions. Trigger on "LV-COLO," "PA-5400," "3PLZ hub," "tenant zone," "vr-{TID}," "SNAT/PNAT," "shared-sidecar," "tz-{TID}-ipsec," "dmz-{TID}," or any Vegas colo firewall/architecture diagram, even if not named explicitly. Also consult cvs-netsec-context for org facts and 3plz-vendor-evaluation/3plz-business-case for the program-level (non-LV-COLO-specific) 3PLZ material — this skill is scoped to the physical hub architecture, not vendor selection or the funding case.
---

# 3PLZ LV-COLO Hub Architecture (PA-5400)

This skill covers the physical/technical hub design for 3PLZ's Las Vegas colocation firewall platform — distinct from the vendor evaluation (F5/Cloudflare POC) and the funding business case, which live in other skills.

## Critical: two competing architectures exist in the source documents — resolve which is current before answering

The uploaded documents describe **two mutually incompatible VSYS models** for the same platform. Do not blend them silently:

1. **Four-VSYS model** (`Enterprise Service Edge Architecture v2.0`, dated March 2026): VSYS 1 Internet Edge, VSYS 2 Intranet Services, VSYS 3 IPsec Tenant, VSYS 4 Circuit Tenant. This is also the subject of a dedicated **Design Review** (March 2026) that raised significant unresolved gaps (see below) and recommended it for pilot "subject to resolution of all P1 items."
2. **Single-VSYS with per-tenant zones** (`PA5400 Single-SYS Multi-VR Architecture Design`, v1.0, undated): explicitly states **"Multi-VSYS was evaluated and rejected"** — citing the exact inter-VSYS external-zone limit and cross-VSYS IKE anchor problems that the 4-VSYS doc lists as unresolved "Critical" open items. This design's zone names (`shared-ike`, `tz-{TID}-ipsec`, `shared-sidecar`, `dmz-{TID}`, `shared-intranet`) and object model **match the architecture diagrams** (Zone Architecture — IPsec Tunnel & Loopback; Remote Host → Tenant DMZ Segment; Remote to Intranet Connectivity SNAT/PNAT) that were provided as the visual reference material.

**Working assumption for this skill: the Single-VSYS + per-tenant-zone model is the current, adopted architecture** — it reads as the resolution to the 4-VSYS design's own blocking open items, and it's what the diagrams depict. Both documents share the identical IPAM address plan (same pool ranges, same stride, same object-naming convention), which is consistent with the single-VSYS design being a refinement of the same underlying plan rather than an unrelated alternative. **If a stakeholder references "VSYS 3" or "VSYS 4" specifically, flag that this maps to the older 4-VSYS proposal and confirm which model is actually deployed before proceeding** — don't assume they're describing the current zone model.

## Platform basics (true under either model)

- **Platform: Palo Alto Networks PA-5400 Series, Active/Passive HA cluster.** PAN-OS 11.2+ target (11.1.5+ minimum if MACsec compensating control needed for circuit tenants).
- **Target scale: up to 1,000 concurrent tenants.**
- **All routing is static** — no OSPF/BGP within the tenant fabric. (Note: the separate Design Review document *does* describe BGP/OSPF for summarized route advertisement in the 4-VSYS design specifically — treat that as belonging to the superseded model unless told otherwise.)
- **Automation pipeline is the only path to configuration** — direct Panorama/CLI access for tenant objects is prohibited by access control, not convention, in both designs.

## Zone model (current — Single-VSYS)

| Zone | Type | Purpose |
|---|---|---|
| `tz-{TID}-ipsec` | Per-tenant | IPsec tunnel data plane ingress/egress; hosts `tunnel.{TID}`; per-tenant audit boundary |
| `dmz-{TID}` | Per-tenant | Tenant DMZ segment boundary; hosts the DMZ 802.1Q sub-interface; per-tenant audit boundary |
| `shared-ike` | Shared | IKE control-plane termination; hosts all `loopback.{TID}` interfaces (shared because IKE is a platform service, not a tenant data boundary) |
| `shared-sidecar` | Shared | NAT translation corridor between tenant zone and intranet zone — **all per-tenant SNAT rules fire here** |
| `shared-intranet` | Shared | Trust zone representing the internal network — shared because the intranet is a single domain that all tenants peer with under the same conditions |

Per-tenant zones are solid-bordered in diagrams; shared zones are dashed-bordered — the distinction marks audit-boundary status, not traffic volume or criticality.

## Per-tenant object model

Every tenant gets, at onboarding, via the pipeline only:
- `loopback.{TID}` — IKE local identity, anchors the IPsec SA, resides in `shared-ike`, address from `192.168.0.0/19` (/32 each)
- `tunnel.{TID}` — VTI for IPsec data plane, resides in `tz-{TID}-ipsec`, address from `172.30.8.0/20` (/30 each)
- `dmz-{TID}.{vlan}` — 802.1Q sub-interface, DMZ gateway, resides in `dmz-{TID}`, VLAN ID from IPAM
- `vr-{TID}` — per-tenant virtual router, static routes only, **no cross-tenant route leakage**

## IPAM address pools (shared across both documents — treat as stable)

| Pool | Range | Stride | Assigned to |
|---|---|---|---|
| IKE Loopback | `192.168.0.0/19` | /32 | `loopback.{TID}` |
| VTI P2P | `172.30.8.0/20` | /30 | `tunnel.{TID}` |
| Tenant→Intranet SNAT (inbound identity) | `172.30.0.0/20` | /30 | Partner identity visible to internal hosts |
| Intranet→Tenant SNAT (outbound identity) | `172.29.0.0/20` | /30 | Internal identity visible to partner |
| Tenant DMZ | `172.30.128.0/17` | /26 | Per-tenant DMZ L3 segment |

**Known unresolved sizing conflicts — don't state these as solved:**
- The DMZ pool (`/17` at `/26` per tenant) supports only **512 tenants**, short of the 1,000-tenant target. Resolving this requires either expanding to a `/16` or shrinking the per-tenant block to `/27`. This is an open decision, not yet made per the source documents.
- SNAT `/30` blocks give only 2 usable host addresses. If 4 distinct SNAT identities per tenant are ever required, pools would need to expand to `/19` with `/29` blocks (6 usable each). Current usage (2 addresses: primary + secondary/reserved) fits within `/30`.
- `172.29.0.0/19` is a valid single summary route covering both SNAT pools (`172.29.0.0/20` + `172.30.0.0/20`) for upstream devices. The VTI pool and DMZ pool need their own separate summary routes.

## NAT model — SNAT (single host) vs PNAT (port-mapped multi-host)

- **SNAT**: remote host connects to one internal host; firewall masks both identities; port is preserved. Remote host never sees the real internal IP (DNS returns the SNAT identity); internal host never sees the real remote IP.
- **PNAT**: remote host connects to the *same* SNAT inbound IP on different external ports; each port maps to a different internal host/port (e.g., `:8443→app:443`, `:5432→db:5432`, `:2222→mgmt:22`). This is how one tenant's single inbound identity serves multiple internal services.
- Translation happens in the `shared-sidecar` zone. On the DMZ path specifically, **no SNAT is applied** — the DMZ segment is tenant-exclusive by VLAN/VR isolation instead, so the remote host's real IP *is* visible to the DMZ host (this is a deliberate, documented exception — don't describe DMZ traffic as identity-masked).

## DNS architecture

- Per-tenant DNS proxy (`dns-{TID}`) rewrites A records so name resolution returns the SNAT identity, never the real IP, in both directions (tenant→intranet and intranet→tenant).
- **Known platform limit, unresolved**: PA-5400 DNS proxy object limit is 256 — it's not yet confirmed whether this is per-VSYS or platform-wide. If platform-wide, the per-tenant `dns-{TID}` model as designed caps out at 256 tenants, well short of the 1,000-tenant target, and would force a shared-proxy-with-SNAT-differentiation redesign. Flag this explicitly whenever discussing DNS scale — it is not a solved problem.

## Automation pipeline — nine components, four workflows

**Components** (each with one defined responsibility; pipeline is the only thing that talks to Panorama): Tenant Portal/API, TenantProfile Store, IPAM Service, Secrets Manager (PSK lifecycle via Vault — no secret value ever leaves it into logs), Pipeline Orchestrator, Template Engine (stateless renderer), Validation Service (pre-commit gate), Acceptance Test Suite (post-commit live-state verifier, 11 tests at onboarding), Panorama API Client (only component that calls Panorama).

**Four workflows**, all halt-on-failure with full audit logging via `workflow_run_id`:
- **W1 — Onboarding**: validate profile → IPAM allocate → PSK generate → render → validate bundle → scoped commit → 11 acceptance tests. State path: `(none)→PENDING→PROVISIONING→ACTIVE` (or `FAILED`/`DEGRADED` on partial failure).
- **W2 — PSK Rotation**: generates a pending PSK alongside the current one (dual-key window, target ≤5 minutes), updates only the `ike-{TID}` object, verifies new SA establishment, then promotes pending→current and revokes the old key.
- **W3 — Service Map Change**: delta-mode render (4 objects: NAT rule, address object, security policy rule, DNS rewrite) for adding/removing a single service on an ACTIVE tenant — not a full re-render. **Open risk, unresolved**: if the TenantProfile was modified outside this workflow, the delta could diverge from what a full re-render would produce; no decision has been made on whether to always full-re-render for safety.
- **W4 — Offboarding**: requires explicit operator confirmation; deletes objects in reverse dependency order (policy→NAT→DNS→interfaces→VR→zones); releases IPAM; revokes PSK; verifies zero orphaned objects before marking `OFFBOARDED` (terminal state — a new tenancy needs a new tenant_id).

**Tenant state machine** terminal/stable states: `PENDING → PROVISIONING → ACTIVE`, with `DEGRADED` (partial acceptance-test failure, config left in place, needs manual remediation) and `FAILED` (commit or deletion failure, needs manual intervention) as recoverable-but-alerting states, and `OFFBOARDED` as terminal/read-only.

## Use case catalogue (UC1–UC8, per the v2 catalogue — supersedes the earlier 9-use-case v1)

The v2 use-case catalogue consolidated what was a 9-item list (v1) down to 8 — UC7–UC9 in v1 (automation lifecycle, forensic attribution, scale-to-1000) were merged into UC7 (Compliance and Forensic Attribution) and UC8 (Compliance and Scale) in v2. **Use v2's numbering going forward**; if a stakeholder cites "UC9" they're using the older scheme.

Core use cases: UC1 Secure Tunnel Establishment (foundation for everything else) · UC2 Single Application/API Access (SNAT only) · UC3 Multi-Service Access via Single IP (SNAT+PNAT) · UC4 Interactive Session Access — SSH/RDP (dedicated SNAT identity governs internal access control) · UC5 Name-Based Service Resolution (DNS proxy rewrite, load-bearing for all name-initiated connections) · UC6 Tenant DMZ Segment · UC7 Compliance and Forensic Attribution · UC8 Compliance and Scale (1,000-tenant target, zone-efficient hybrid model, HA-transparent).

## Design Review findings (on the 4-VSYS design specifically — treat as historical unless that model is confirmed still active)

The dedicated design review (March 2026) gave an overall verdict of **"recommended for progression to pilot, subject to resolution of all P1 items."** Named gaps, none stated as resolved in these documents:
- IKE anchor resilience — loopback /32 as a single point of failure
- VSYS capacity guardrails undefined
- BGP peering architecture underspecified
- **PSK management at scale flagged as a security risk** in the review — cross-reference against the automation architecture's W2 rotation workflow, which does address rotation mechanics but per the automation doc's own Open Items, the tenant-side rotation *coordination* mechanism is still undefined
- MTU/MSS strategy deferred, flagged as important given VDI sensitivity
- Monitoring/observability insufficiently defined
- No multi-region or DR strategy
- Bi-directional NAT complexity/asymmetry risk

## Other unresolved platform-scale questions (don't present these as settled)

- Maximum security zone count on the PA-5400 SKU, and whether it's per-VSYS or platform-wide (at 1,000 tenants, ~2,000+ zones are needed)
- Maximum Virtual Router count (1,001 VRs needed at full scale under either design)
- IPsec tunnel/IKE peer limits per platform, unconfirmed with Palo Alto SE
- Panorama commit time and rollback RTO at 100+ tenant scale — not yet lab-tested
- HA link sizing for session sync at full tenant load
- ARP table limits for circuit tenants specifically

## Working-style notes for this material

- **Always check the design-assumption list before asserting a capability is supported.** Both architecture docs assume IKEv2-only (no IKEv1), non-overlapping tenant remote-network prefixes, and continuous Panorama/Vault availability — these are assumptions, not validated facts, per the documents' own "Design Assumptions" sections.
- **Don't present open items as resolved.** A large fraction of this platform's scale story (DNS proxy limit, DMZ pool sizing, zone/VR platform limits) is explicitly unconfirmed in the source material — say so rather than picking the more optimistic reading.
- When asked to produce onboarding runbooks, capacity plans, or pilot checklists for this hub, ground them in the specific numbered open items above (both the Enterprise Service Edge doc's Critical/High/Medium tables and the Single-VSYS doc's Blocking Dependencies) rather than treating the design as production-ready.

# Reusable Join & Containment Patterns for SRC/DEST FW Policy Analysis

All patterns below were used and verified working against a real CCD
Platform data collect (`ipam_db_collect_YYYYMMDD.zip`). Adjust file paths to
the actual collect's filenames — they carry version stamps that change per
collect.

## Loading a CCD Platform CSV (handles the `#STEM=`/`#VERSION=` comment header)

Every CCD Platform dataset file has 1+ leading comment lines starting with
`#` before the real CSV header. Strip them generically rather than
hardcoding a line count, since the comment block length varies by dataset:

```python
import csv

def load_rows(path):
    with open(path, encoding='utf-8', errors='replace') as f:
        lines = f.readlines()
    header_idx = next(i for i, l in enumerate(lines) if not l.startswith('#'))
    return list(csv.DictReader(lines[header_idx:]))
```

## Building a containment-searchable index from a CIDR dataset

`all_IP_networks`, `EGRESS-FW-TOPOLOGY`, `external_ip_registry`, and
`pci_subnet_index` are all CIDR-keyed. Build both an exact-match dict and a
prefix-length-sorted list for containment fallback:

```python
import ipaddress

def build_index(rows, cidr_field='CIDR'):
    exact_index = {}
    all_networks = []
    for row in rows:
        cidr = row.get(cidr_field, '').strip()
        if not cidr:
            continue
        try:
            net = ipaddress.ip_network(cidr, strict=False)
        except ValueError:
            continue
        exact_index[net] = row
        all_networks.append((net, row))
    # Sort most-specific-first so containment search finds the tightest match
    all_networks_sorted = sorted(all_networks, key=lambda x: -x[0].prefixlen)
    return exact_index, all_networks_sorted

def find_covering(net, sorted_list):
    """Return (covering_network, row) for the most specific containing entry, or (None, None)."""
    for cand, row in sorted_list:
        if cand.version == net.version and (net.subnet_of(cand) or net == cand):
            return cand, row
    return None, None
```

**Performance note:** `find_covering` is O(n) per lookup against the sorted
list. For `external_ip_registry` (~57K rows) this is noticeably slow
(~85-120s) for a few hundred lookups — acceptable for a one-off analysis,
but cache the match results (`pickle.dump`) if you'll need the same lookups
again in the same session, rather than re-running the full scan.

## The full join chain: SRC/DEST subnet → location → app → PCI classification

```python
def containing_24(net):
    """app_subnet_index is keyed at /24 granularity regardless of the input subnet's own prefix."""
    return str(ipaddress.ip_network(f"{net.network_address}/24", strict=False)) if net.version == 4 else None

def enrich_subnet(subnet_str, all_ip_networks_sorted, app_index, location_master_index):
    net = ipaddress.ip_network(subnet_str, strict=False)

    # 1. Location + routing domain + heritage, from all_IP_networks
    cov, ipam_row = find_covering(net, all_ip_networks_sorted)
    ipam_row = ipam_row or {}

    # 2. Fuller location detail (city/state/region) via SITE_CODE -> location_master
    lm_row = location_master_index.get(ipam_row.get('SITE_CODE', ''), {})

    # 3. App/PCI/risk attribution -- keyed at /24, so always compute the containing /24
    #    even when the input subnet is smaller (e.g. a /27 or /32)
    cidr24 = containing_24(net)
    app_row = app_index.get(cidr24, {})

    return {
        'subnet': subnet_str,
        'matched_ipam_cidr': str(cov) if cov else None,
        'canonical_location': ipam_row.get('CANONICAL_LOCATION', ''),
        'city': lm_row.get('CITY', ''),
        'state': lm_row.get('STATE', ''),
        'routing_domain': ipam_row.get('ROUTING_DOMAIN', ''),
        'heritage': ipam_row.get('HERITAGE', ''),
        'data_quality': ipam_row.get('DATA_QUALITY', ''),
        'apm_ids': app_row.get('APM_IDS', ''),
        'pci_designation': app_row.get('PCI_DESIGNATION', ''),
        'risk_tier': app_row.get('RISK_TIER', ''),
        'app_env_types': app_row.get('APP_ENV_TYPES', ''),
        'prod_app_count': app_row.get('PROD_APP_COUNT', ''),
    }
```

**Index-keying gotcha:** `app_subnet_index` is keyed by `CIDR_24` (a plain
string, not a parsed network) — build that index as a dict, not a
containment-searchable list, since the lookup is always an exact /24 string
match, never a containment search:

```python
def build_app_index(app_subnet_index_rows):
    return {row['CIDR_24']: row for row in app_subnet_index_rows if row.get('CIDR_24')}
```

`location_master` is keyed by `SITE_CODE` (also exact-match, not CIDR):

```python
def build_location_master_index(lm_rows):
    return {row['SITE_CODE']: row for row in lm_rows if row.get('SITE_CODE')}
```

## Checking PCI CDE boundary membership (overlap, not just containment)

Use `.overlaps()` rather than `.subnet_of()` here — a DEST subnet and a CDE
CIDR entry may partially overlap without one strictly containing the other,
depending on how each was originally carved:

```python
def check_cde_overlap(dest_subnet_str, pci_cde_networks):
    """pci_cde_networks: list of (ipaddress.ip_network, row) built from pci_subnet_index."""
    net = ipaddress.ip_network(dest_subnet_str, strict=False)
    hits = []
    for cde_net, cde_row in pci_cde_networks:
        if net.overlaps(cde_net):
            hits.append(cde_row)
    return hits  # empty list = no CDE overlap
```

## Object-group collapse (avoiding the cartesian product)

```python
def build_policy_spec(src_groups: dict[str, dict], ports: list[str]):
    """
    src_groups: {group_name: {'firewall': str, 'members': list[str], 'dest_group': str, 'dest_count': int}}
    Produces one row per (SRC group x port) -- NOT per individual SRC/DEST subnet pair.
    """
    rows = []
    rule_num = 1
    for group_name, info in src_groups.items():
        for port in ports:
            rows.append({
                'rule_num': rule_num,
                'firewall': info['firewall'],
                'src_group': group_name,
                'src_members': ' | '.join(info['members']),
                'dest_group': info['dest_group'],
                'dest_member_count': info['dest_count'],
                'port': port,
                'action': 'Allow',
            })
            rule_num += 1
    return rows
```

## Interpreting `EGRESS-FW-TOPOLOGY`'s confidence fields in code

See `references/confidence-tiers.md` for the full tier table and how to read
the `MAPPING_METHOD`/`CONFIDENCE` fields. In code:

```python
def classify_confidence(row):
    method = row.get('MAPPING_METHOD', '')
    confidence = row.get('CONFIDENCE', '')
    if confidence == 'HIGH':
        return 'traffic-confirmed', True   # (label, safe_to_build_policy_on)
    if confidence == 'MEDIUM':
        return 'location-confirmed', True
    if confidence == 'LOW-AMBIGUOUS':
        return 'location-heritage-ambiguous -- NEEDS OWNER CONFIRMATION', False
    if confidence == 'LOW':
        return 'asserted-default -- NEEDS OWNER CONFIRMATION', False
    return 'no-location-data', False
```

Surface the second element of this tuple in any deliverable — don't let a
`False` silently pass through as if it were confirmed.

## Note on terminology in this file

The function names below (`enrich_subnet`, `build_policy_spec`, etc.) use
generic "subnet"/"src_groups" naming for reusability, but per the main
`SKILL.md`, always start an actual analysis from **Target A / Target B**
context (location, classification, exposure, ownership, directionality)
before applying these join functions — the code here handles the data
lookups, not the sequencing.


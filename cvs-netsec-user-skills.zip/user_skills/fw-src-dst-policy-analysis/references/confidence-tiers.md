# EGRESS-FW-TOPOLOGY Confidence Tiers

`EGRESS-FW-TOPOLOGY` tags every per-CIDR enforcement assignment with a
`MAPPING_METHOD` and `CONFIDENCE` field. Read both — the method name tells
you *why* the confidence level is what it is, which matters for deciding
whether an assignment needs owner confirmation before policy ships on it.

| Tier | Method pattern | What it actually means |
|---|---|---|
| HIGH | `TRAFFIC-CONFIRMED` | Real observed traffic backs the assignment |
| MEDIUM | `LOCATION-HERITAGE-CONFIRMED[+variant]` / `LOCATION-CONFIRMED[+variant]` | Location actually confirmed, not via traffic |
| **LOW-AMBIGUOUS** | `LOCATION-HERITAGE-AMBIGUOUS` | **The pipeline tried to resolve location+heritage jointly and got conflicting/insufficient signal** — a resolution *failure*, not a default |
| LOW | `ASSERTED-*` (retail, PBM-default, HCB-AP-pair, cloud-azure, cloud-gcp, colo, partner, internet-facing, etc.) | No real resolution attempted — a category-based default guess |
| NONE | `NO-LOCATION` | No location data at all |

## Why LOW-AMBIGUOUS and LOW/ASSERTED are different failure modes

`LOW-AMBIGUOUS` is not just "low confidence" generically — it means the
pipeline had real signal (location and heritage data both existed) and
attempted joint resolution, but the signals conflicted or were insufficient
to converge on one answer. `ASSERTED-*` rows never attempted real location
resolution in the first place — they applied a rule-of-thumb category
default (e.g., "this looks like a retail subnet, assign the retail
default").

**Treat `LOW-AMBIGUOUS` as the higher-priority item to get owner
confirmation on**, not because the number is lower, but because it
represents an active resolution failure on a subnet where the data should
have been resolvable. A physical-location mismatch (the assigned firewall's
DC doesn't match where most of the traffic's actual destinations sit) is
corroborating evidence that a `LOW-AMBIGUOUS` tag was a real miss, not
administrative caution.

## Relative frequency (observed on a full-dataset scan, ~200K row sample)

For calibration — `LOCATION-HERITAGE-AMBIGUOUS` is not a rare edge case:

| Method | Confidence | Approx. share of sample |
|---|---|---|
| `ASSERTED-RETAIL` | LOW | ~61% |
| `LOCATION-HERITAGE-AMBIGUOUS` | LOW-AMBIGUOUS | ~32% |
| `LOCATION-HERITAGE-CONFIRMED+SIBLING16` | MEDIUM | ~2% |
| `TRAFFIC-CONFIRMED` | HIGH | ~1.5% |
| `LOCATION-HERITAGE-CONFIRMED` | MEDIUM | ~1.5% |
| `NO-LOCATION` | NONE | <1% |
| Various other `ASSERTED-*` | LOW | remainder |

In other words: across the estate, only a small single-digit percentage of
assignments are backed by real traffic confirmation or firm location
resolution. The large majority are either category defaults or unresolved
ambiguity. **Expect to hit low-confidence assignments routinely, not as an
exception** — build the confidence check into every analysis by default,
don't treat it as an optional extra step for suspicious-looking results.

# Worked Example: How This Methodology Was Corrected

This documents the actual sequence of wrong turns and corrections from the
session that produced this skill, using a real request: mapping GCP/Azure
CI/CD runner subnets ("CAP-Runners") to a set of on-prem/cloud destination
servers ("PCW" custom class) for a permit-rule policy.

## Wrong turn 1 — chasing corroborating data instead of using the given inventory

The requester had already uploaded a real, enriched destination server list.
The first mistake was treating this as insufficient and searching for flow
logs, CSNA data, or other corroboration instead of just using the list that
was handed over. **If a real inventory is given, that inventory is the
destination population for the task at hand** — validating that inventory
against other sources is a separate task, not a prerequisite for using it.

## Wrong turn 2 — building the full cartesian product

With 12 SRC subnets, 290 DEST subnets, and 3 ports, a literal per-pair
output produced 10,440 rows. No firewall admin writes policy this way. The
correction: collapse to object-groups — group SRC subnets by shared
enforcement firewall, DEST subnets into one object-group per logical
population, and the real rule count becomes (SRC-group-to-firewall
pairings) × (ports) — 9 rules in this case, not 10,440.

## Wrong turn 3 — trusting a single enforcement-point dataset

The first firewall assignment used `ROUTING_DOMAIN` + `cloud_fw_mgmt_ips` —
a reasonable first pass. A second, per-CIDR dataset (`EGRESS-FW-TOPOLOGY`)
gave a *different* answer for the same subnets. A third, device-level
dataset (`fw_location_topology`) then revealed the real structure — a
heritage split (`azhtrust*` dedicated to Aetna at Dallas Equinix) and a
shared hub (`azhub*`, confirmed `HERITAGE=CVS|AETNA`) — that neither of the
first two sources showed on its own. **Checking only one source would have
produced a confidently wrong answer.**

## Wrong turn 4 — grouping destinations by heritage

After confirming some destinations were Aetna-heritage and some CVS, the
natural-seeming move was to build `AETNA-PCW`/`CVS-PCW` object-groups and
assume that solved the enforcement-scoping problem. It didn't: when the
location breakdown was checked, `AETNA-PCW` (38 subnets) turned out to span
5 different physical sites (29 at Phoenix, but also Middletown, Windsor, and
one at Woonsocket) — meaning a single heritage-based group doesn't correspond
to a single enforcement path at all. **Heritage is an ownership label, not a
topology signal.**

## Wrong turn 5 — assuming SITE_CODE alone fixes the grouping problem

The next correction attempt was to group by `SITE_CODE` instead. Better, but
still incomplete: re-checking Shea DC (`US_SCO_AZ_DC`, 124 subnets) showed
those subnets split across at least 3 different `EGR_CODE` egress
assignments (`EGR_SHEAW-TC`, `EGR_CMC-TI`, `EGR_LV-TI`). **One physical site
can have multiple legitimate (or ambiguously-inferred) egress paths.** The
actual atomic grouping key had to be `EGR_CODE` + IP prefix + `SITE_CODE`
together — the "topology fingerprint" — not any one of the three alone.

## Wrong turn 6 — attempting a PROD/NON-PROD environment split

An attempt to further split CVS destinations into `CVS-PCW-PROD` and
`CVS-PCW-NONPROD` using `app_subnet_index.APP_ENV_TYPES` and
`PROD_APP_COUNT` seemed reasonable until two things were checked: (1) many
subnets host multiple environment tiers simultaneously (`DEV | PROD | QA |
UAT` on one /24), so a subnet-level split misrepresents reality, and (2) a
full-dataset scan of `APP_ENV_TYPES` found 66 distinct atomic codes with
massive spelling inconsistency (`PROD`/`prod`/`Production`/`prd`) that
correlated with no BU or heritage pattern — confirming it as ungoverned
free-text entry, not a legitimate taxonomy to split on.

## Wrong turn 7 — treating PCI_DESIGNATION as CDE membership

78 of the 287 destination subnets carried a `PCI_DESIGNATION` tag, which
initially seemed to mean a dedicated PCI firewall tier was needed. Checking
those 78 subnets against `pci_subnet_index` (the network-verified CDE
boundary, not the app-level tag) found **zero overlap** — none of them were
actually inside the confirmed Cardholder Data Environment. The dedicated PCI
firewalls exist for a genuinely different, narrower subnet population.
`PCI_DESIGNATION` and CDE boundary membership answer different questions and
must be checked separately.

## The final correction — Target A/B before SRC/DEST

The deepest correction came last: the whole exercise had implicitly assumed
fixed SRC/DEST roles from the start (runners = SRC, servers = DEST) without
first contextualizing each side independently (location, App/Infra/Delivery/
Service classification, public/private, CVS/AETNA/PARTNER ownership) or
establishing the actual client-server directionality (one-way vs.
bi-directional) between them. This reordering — Target A/Target B →
contextualize both → determine directionality → then map topology — is now
the mandatory starting sequence in the main `SKILL.md`, not an afterthought.

## The lesson generalized

Every wrong turn above shares one shape: **a single field or a single
dataset looked like it was sufficient, and wasn't.** The fix was always the
same kind of action — check a second source, check the actual physical/
network reality behind the label, or step back to an earlier, more
fundamental question (what *is* this target, before asking what it connects
to). Apply that same skepticism by default on future analyses, rather than
waiting for a wrong answer to surface first.

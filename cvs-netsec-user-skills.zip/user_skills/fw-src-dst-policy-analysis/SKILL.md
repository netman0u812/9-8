---
name: fw-src-dst-policy-analysis
description: Methodology for mapping firewall policy requests between two targets (Target A / Target B) against the CCD Platform's raw IPAM data — contextualizing each target, determining client-server directionality, triangulating the real enforcement firewall via EGR_CODE + IP prefix + SITE_CODE, and producing a current-state (L4/port-protocol) rule with an explicit path toward App-ID conversion. Use whenever asked "what firewall do I apply policy on," "map these subnets to destinations," "what FW enforces this traffic," or any two-target firewall policy request that needs grounding against real IPAM/topology data rather than assumption. Also trigger for PCI-boundary questions and CVS/AETNA/PARTNER ownership questions. This skill is a workflow, not a fact sheet — consult ccd-platform-data-model for the underlying dataset definitions this workflow consumes, and intent-based-firewall-policy for how this current-state output feeds the target App-ID architecture.
---

# Firewall Policy Analysis — Target A/B Methodology

## Start here: Target A and Target B, not "SRC and DEST"

Don't assume fixed SRC/DEST roles at the start of an analysis. Begin with
two **targets** (each a real IP/subnet) and work out their relationship, not
the other way around:

1. **Identify Target A and Target B.**
2. **Contextualize each target independently**, before touching directionality:
   - **Location** — physical site or cloud region
   - **Classification** — App / Infra / Delivery / Service
   - **Exposure** — Public / Private
   - **Ownership** — CVS / AETNA / **PARTNER** (a real third category — don't reduce this to a CVS/AETNA binary)
3. **Only then determine the client-server relationship** between the two targets: which side initiates, which side listens, and — critically — **is the relationship one-way or bi-directional?** A protocol like WinRM has session semantics that aren't purely one-way; don't assume a single push-only rule covers it without checking.

Skipping straight to "SRC subnets need to reach DEST subnets on these ports"
without doing steps 2–3 first produced a series of wrong or incomplete
answers when this methodology was being developed — see
`references/anti-patterns-worked-examples.md` for the specific worked
example.

## Contextualizing a target: what "Custom Class" populations look like in practice

A destination population (e.g., a "PCW" custom class) is not one app, one
environment, or one enforcement point — it's a **shared address space**
hosting many things at once:

- Individual subnets routinely carry dozens of distinct `APM_IDS` simultaneously (one /24 can list 40+ separate applications)
- Environment tiers (Prod/QA/Dev/UAT/Test) **coexist on the same subnet** — they are not separated at the subnet level
- **`APP_ENV_TYPES` is not a governed field.** A full-dataset check found 66 distinct atomic codes for what should be a handful of environment tiers — the same concept spelled 3-4 different ways (`PROD`/`prod`/`Production`/`prd`), ambiguous undocumented codes (`PT2`, `STP`, `CTE`, `PE`, `REG`), and at least one row where a business classification (`CRITICAL BUSINESS APPLICATION`) was typed into the environment field by mistake. This inconsistency is **not** BU- or company-specific — checked directly, every spelling variant appears across every BU and heritage combination with no pattern. It's accumulated free-text entry error, not a legitimate organizational convention to respect.
- **Do not attempt a PROD/NON-PROD object-group split at the subnet level.** The data doesn't support it structurally (mixed environments per subnet) or reliably (ungoverned field). If environment-tier separation is genuinely required, it has to come from the individual APM/application record, not the subnet.

## Finding the real enforcement point: the topology fingerprint, not any single field

**None of these fields alone determines the enforcement firewall — the
combination does:**

| Signal alone | Why it's insufficient by itself |
|---|---|
| IP prefix alone | Same range can sit behind different firewalls in different contexts |
| `SITE_CODE` alone | One physical site routinely spans multiple egress paths — e.g. Shea DC subnets were confirmed split across `EGR_SHEAW`, `EGR_CMC`, and `EGR_LV` simultaneously |
| `HERITAGE` alone | Not a physical/enforcement attribute at all — it's an ownership tag, and it's messy on top of that (multi-value strings like `AETNA \| CVS`, `AETNA \| Mixed` are common) |
| `EGR_CODE` alone | A logical egress cluster name without the prefix/site pairing doesn't tell you which specific subnets within that cluster actually route there |

**`EGR_CODE` + IP prefix + `SITE_CODE`, read together, is the topology
fingerprint** that actually triangulates the real enforcement path. This is
also exactly why `EGRESS-FW-TOPOLOGY`'s `LOCATION-HERITAGE-AMBIGUOUS`
confidence tier exists — it's the pipeline's own admission that these three
signals failed to converge cleanly for a given subnet, which is different
from (and worse than) a plain default assertion. See
`references/confidence-tiers.md` for the full tier table and how to read it.

**Use `HERITAGE`/ownership for governance and rule-approval labeling — never
for enforcement-point scoping.** CVS/AETNA/PARTNER matters for who owns and
approves a rule; it does not determine which physical device enforces it.

## Egress vs. ingress domain — know which one you actually have

Today's `EGR_CODE`/`EGRESS-FW-TOPOLOGY` model is **egress-only**. There is no
equivalent static ingress-domain field in the current CCD Platform data.
This matters directly for bi-directional protocols (see the client-server
step above) — an egress-only mapping tells you the outbound half of a path
and nothing confirmed about the return path.

**Ingress-domain resolution is a planned capability, not a missing dataset
field to search harder for.** It's expected to be built by correlating IP
Flow evidence (CSNA), App-ID telemetry, and Splunk traffic logs — the same
evidence chain used for the L4→App-ID conversion below. Until that lands,
reason about bi-directional traffic manually and flag it explicitly rather
than assuming the egress assignment covers both directions.

## Current state vs. target state — define which one you're delivering

**Phase 1 (today — current state): Protocol/IANA-port + SRC-group +
DEST-group + enforcement firewall.** This is not an approximation waiting to
be replaced — it is the complete, correct rule definition available today.
A finished Phase 1 rule has exactly these four elements:

1. SRC object-group (see collapse method below)
2. DEST object-group
3. Protocol + IANA-registered destination port (e.g., TCP/443, TCP/22, TCP/5985-5986) — this is the real service identifier at this phase, not a placeholder
4. The specific enforcement firewall, determined via the topology fingerprint above

**Phase 2 (the target state — a journey, not a single migration event):
App-ID / Custom App-ID conversion.** This directly closes the estate-wide
finding (see `intent-based-firewall-policy`) that ~96% of PA rules use
`app=any` with no application identity. The conversion path is evidence-based:
correlate **IP Flow (CSNA) + App-ID telemetry + Splunk traffic logs** to
confirm real application identity behind existing L4 rules, then convert to
native App-ID where PA recognizes the app, or Custom App-ID for internal
applications it doesn't. App-ID does not replace port/protocol identification
— it adds a verification layer confirming the traffic on that port is
actually the expected application, not just anything using that port number.

**State which phase you're delivering for, explicitly, in every output.** A
Phase 1 deliverable presented without this framing reads as a finished
answer when it's actually the necessary first step of a longer conversion.

## Object-group collapse — still applies, now correctly scoped

Once Target A and Target B populations are contextualized and the topology
fingerprint is resolved per subnet, group SRC subnets by **shared enforcement
firewall** (not by heritage), and DEST subnets into per-population
object-groups. The real rule count is (distinct SRC-group-to-firewall
pairings) × (ports) — typically single digits, not the thousands you get
from a literal SRC×DEST×port cartesian product. Ownership (CVS/AETNA/PARTNER)
can label a DEST group for governance purposes without being the reason it
was split — split on topology fingerprint, label with ownership.

## PCI_DESIGNATION vs. confirmed CDE boundary — still a required check

`app_subnet_index.PCI_DESIGNATION` (`PCI`, `PCI Connected`, `PCI Security
Tool`) is an application/business-level tag — it says an app *relates to*
PCI, not that its subnet sits in the segmented Cardholder Data Environment.
`pci_subnet_index` is the network-verified CDE boundary, confirmed directly
from firewall interface configs. Always check DEST subnets against
`pci_subnet_index` by overlap before assuming a PCI-tagged destination needs
the dedicated PCI firewall tier (`cvs_pci_fw_mgmt_ips` / `aetna_pci_fw_mgmt_ips`)
— a subnet can be fully PCI-tagged at the app level with zero CDE overlap.

## Anti-patterns to avoid

1. **Starting from SRC/DEST instead of Target A/Target B + directionality.** This was the single biggest correction to this methodology — see `references/anti-patterns-worked-examples.md`.
2. **Grouping by heritage for enforcement purposes.** Heritage is ownership, not topology. Use the EGR_CODE+prefix+SITE_CODE fingerprint.
3. **Assuming SITE_CODE alone collapses to one firewall.** It doesn't — check EGR_CODE too.
4. **Splitting DEST groups by PROD/NON-PROD at the subnet level.** The environment field isn't governed and environments coexist per subnet.
5. **Chasing a "better" data source instead of using the inventory you were given.** If the requester uploaded a server list, that IS the destination population.
6. **Building the full SRC×DEST×port cartesian product** instead of collapsing to object-groups.
7. **Presenting a low-confidence mapping with the same weight as a confirmed one.** Always carry the `CONFIDENCE`/`MAPPING_METHOD` field forward.
8. **Presenting a Phase 1 (L4/port) rule as if it were the final App-ID target state**, or vice versa — always state which phase the deliverable is for.
9. **Assuming SRC-side app/PCI/risk attribution exists.** Infrastructure-only subnets (CI/CD runners, management planes) often have zero `app_subnet_index` entry — expected, not an error.
10. **Searching harder for an ingress-domain dataset that doesn't exist yet** instead of naming it as a planned, evidence-based future capability.

## Related skills

- `ccd-platform-data-model` — definitions for every dataset this workflow joins across
- `intent-based-firewall-policy` — the governance framework and the 96% `app=any` finding that Phase 2 of this methodology directly addresses
- `cisco-sna-five-stack` — CSNA flow data is one of the three evidence sources (with App-ID telemetry and Splunk) for the Phase 1→Phase 2 conversion
- Reusable Python join/containment code: `references/enrichment-joins.md`
- Confidence tier reference: `references/confidence-tiers.md`
- Worked example of the anti-patterns and corrections: `references/anti-patterns-worked-examples.md`

---
name: panos-dlp-decrypt-migration
description: Use for PAN-OS DLP, file blocking, App-ID, decryption architecture, and the Skyhigh SWG-to-Palo Alto migration/parity work, including Entra Tenant Restrictions v2 (TRv2) forward-proxy header injection. Trigger on any mention of "Skyhigh," "SK_to_PA," DLP patterns/dictionaries, decrypt/decryption coverage, TRv2, PAN-OS Data Filtering profiles, or segments MID/WIN/PAZSHDC/RRISHDC, even if not phrased as a migration question. Also consult cvs-netsec-context for the shared decrypt-gap and App-ID-adoption facts this skill builds on.
---

# PAN-OS DLP, Decrypt Architecture & Skyhigh-to-PA Migration

## Core dependency chain — lead with this

**Aetna's HTTPS decrypt coverage gap is the root upstream blocker for DLP, IPS, and Content-ID inspection simultaneously.** Any conversation about why DLP or IPS isn't catching something on Aetna segments should trace back to this first, rather than treating each inspection failure as an independent gap. Don't propose DLP or Content-ID fixes without first checking whether decrypt coverage is the actual blocker.

## Skyhigh-to-PA migration (SK_to_PA_Security_Model_and_Parity_Plan)

- Deliverable format: capability gap documentation organized across **effort tiers** (not a flat gap list) — preserve this structure when extending the plan.
- Known resolved item: User-ID/AD group scoping requirements for broad LAN-to-Internet rules.
- DLP parity mapping against Skyhigh SWG DLP policies: SSN, HICN, PCI, Member ID are the categories with **active blocking** on Skyhigh today — PA parity work should be checked against these four as the baseline, not a generic DLP category list.
- Skyhigh SWG DLP dictionary comparison: Aetna has 16 dictionaries vs CVS's 41 — a significant coverage gap, and directionally consistent with Aetna generally lagging CVS on inspection maturity (see decrypt gap above).
- ICAP directional gap also documented between the two estates.
- Both estates fetch customer-maintained dynamic lists from proxyconsole.aetna.com — CVS's dynamic list infrastructure was never migrated off Aetna-owned infrastructure. Treat this as a standing risk/dependency whenever proposing changes to either estate's dynamic list handling.

## DLP pattern library

- US driver's license regex patterns have been built for **all 50 states**, sourced from the lipe-dev/NTSI GitHub gist and corrected for PAN-OS compatibility. If asked to extend or debug DLP regex patterns, check compatibility against PAN-OS's regex engine quirks the same way — don't assume a generic PCRE pattern will work unmodified.
- Native PA Data Filtering profile objects are **built but not wired to security policy rules** estate-wide (see cvs-netsec-context). Before reporting DLP as "implemented" anywhere, verify the profile is actually attached to a rule, not just defined as an object.

## Decryption architecture

Deep technical work spans named segments: **MID, WIN, PAZSHDC, RRISHDC**. When discussing decrypt architecture, ask which segment is in scope if not specified — findings and coverage differ by segment, and generalizing across all four is likely to overstate or understate coverage.

## TRv2 (Entra Tenant Restrictions v2)

Implementation approach: PAN-OS forward proxy **HTTP header injection**, deployed across the CVS/Aetna Panorama estate. This is a forward-proxy/header-injection design specifically — don't suggest alternate TRv2 implementation paths (e.g., client-side or IdP-side enforcement) without flagging that it's a different architecture than what's been built.

## Related audit context

SOC 2 audit response work touches the partially decommissioned PDC environment (PDC-013, PDC-020, PDC-029 AuditBoard requests) and the Aetna PCI environment (IPS tuning, Splunk eStreamer blockers, network discovery from seed ranges to reverse-engineer PCI scope). If DLP/decrypt work intersects with PCI scope questions, flag the connection to this audit work rather than treating it as unrelated.

---
name: microsegmentation-architecture
description: Use for host/workload microsegmentation architecture questions — comparing enforcement models (Unisys Stealth's cryptographic identity model, Akamai Guardicore's proprietary-agent/deception model, Illumio's OS-native-agent model, Zscaler ZTE's broker model, agentless options Elisity/Zero Networks), container/Kubernetes east-west segmentation (Cilium/eBPF, service mesh), and encrypted-traffic inspection constraints for PCI DSS/HIPAA. Trigger on "microsegmentation," "Illumio," "Guardicore," "Unisys Stealth," "Zscaler," "Cilium," "eBPF," "east-west traffic," "SSL decrypt for app traffic," or pairing microsegmentation with Forescout NAC, even without a named vendor. Complements nac-ztna-fpms and panos-dlp-decrypt-migration — consult those for estate-specific facts this builds on, and cvs-netsec-context for shared org facts.
---

# Microsegmentation Architecture — Enforcement Models, Container Gaps, Encrypted-Traffic Inspection

Source: technical architecture survey developed for the NAC/ZTNA modernization program's microsegmentation-overlay evaluation (paired with Forescout continuous-validation NAC). Full formal deliverable: `Microsegmentation_Architecture_Survey.docx`.

## How to use this skill

Four architectural models, evaluated by mechanism rather than brand, because the model determines which operational/compliance constraints an implementation will hit. Ask which question is actually being asked — vendor comparison, container fit, or compliance/decrypt — and pull the relevant section. Don't recite the whole survey for a narrow question.

## The four-question framework (apply first, to any new vendor too)

1. **Where is the enforcement point?** Host OS firewall / proprietary local firewall / network switch / cloud proxy.
2. **Does traffic change path, or only policy?** Broker models reroute traffic; agent models enforce locally, path unchanged.
3. **What is the identity primitive?** Cryptographic community membership / process fingerprint / IP-or-label tag / user-device identity.
4. **What does it require of the counterparty?** Both sides need the same agent / only one side / neither (enforcement is external).

## Model summaries

**Unisys Stealth — cryptographic identity / "circle of trust."** Cryptographic communities-of-interest; encrypted tunnels between members; non-members can't discover or address the community (stronger containment than an ACL — cloaking + encryption + auth, not just allow/deny). **Why it lost the market (inference, not documented postmortem):** bilateral dependency (both sides must run Stealth or a gateway) inflates rollout scope vs. workload-by-workload agent adoption; five years of repeated "now it's finally simpler" releases (2016–2020) signals persistent deployment friction; Unisys is a diversified services company, not a security pure-play, diluting investment focus. Current standing: ~1.5% category mindshare (mid-2026), no Forrester Wave/Gartner Customers' Choice/Constellation ShortList presence. **Verdict: not a live contender** — has-been, not a technical failure.

**Akamai Guardicore Segmentation — proprietary agent + integrated deception.** Proprietary local firewall (not OS-native) gives process-level attribution and native deception (decoys) that Illumio lacks. Trade-off: proprietary firewall on every host complicates OS upgrade cycles, runs counter to NIST 800-207's preference for standard components. Current standing: Forrester Wave Leader, Gartner Peer Insights Customers' Choice 2026 (168 reviews, 4.8/5). **Verdict: credible primary candidate** for the managed on-prem server estate.

**Illumio — OS-native agent / centralized Policy Compute Engine.** Strip the marketing: agent reports flow telemetry → central service computes policy graph → pushes rules to the host's own native firewall (iptables/nftables/WFP). The enforcement primitive is free and built into every OS — **the differentiated value is the automated discovery/dependency-mapping engine**, not enforcement itself. For a static, non-elastic on-prem estate, the "identity survives IP churn" advantage is largely moot; the mapping/discovery value is the real justification, especially given this estate's documented lack of an asset/topology source of truth. Current standing: Forrester Wave Leader (highest current-offering/strategy scores), Gartner Customers' Choice 2026 (59 reviews, 4.8/5, 98% willing-to-recommend). **Verdict: strongest-validated candidate** — but frame the buying question as "how much of the discovery value can we realize independent of committing to their enforcement engine," not "can it enforce."

**Zscaler Zero Trust Exchange — cloud broker/proxy.** Not one architecture — three lineages under one brand:
- **ZPA** (native, founding-era): cloud broker; user/workload never placed on network; direct brokered connection per resource.
- **Zscaler Microsegmentation** (substantially descends from **Edgewise Networks**, acquired May 2020, $18M-raised Boston startup; kept "standalone" initially, "gradual" integration promised, Edgewise brand has since vanished from marketing): agent-based, AI/ML app-identity pattern learning, targets AWS/Azure/on-prem/K8s (on-prem claim is **unverified** — no analyst validation found for on-prem specifically).
- **Zero Trust Branch / Zscaler Cellular** (from **Airgap Networks**, acquired April 2024, DHCP-proxy /32-per-device isolation, agentless): targets campus/branch/factory/OT-IoT — this is Zscaler's answer to the same unmanaged-device problem Elisity/Zero Networks solve differently.

**Strategic red flag:** Airgap's pre-acquisition marketing (retained by Zscaler) explicitly frames the product as **replacing** NAC, east-west firewalls, and microsegmentation — not complementing them. Every other vendor here (Illumio, Guardicore, Stealth) is built to sit alongside existing network/firewall/NAC infrastructure. This is a direct strategic tension with any concurrent Forescout NAC investment — evaluating Zscaler as a segmentation overlay while keeping Forescout means running two vendors both aiming to replace the same trust model.
**Verdict: not recommended** for on-prem data-center segmentation (no analyst validation, traffic-path-change cost, NAC-replacement tension). Zero Trust Branch may warrant a narrow, separate OT/IoT-only evaluation against Elisity/Zero Networks.

**Agentless/identity-based alternatives (Elisity, Zero Networks):** best fit for unmanaged/IoT/OT/legacy devices that can't run an agent — the same population NAC is built to see. Elisity enforces on existing switch infrastructure (Gartner Market Guide Representative Vendor, Forrester Strong Performer, highest vision/roadmap score). Zero Networks pairs agentless segmentation with JIT MFA-triggered access (highest current category mindshare growth, 6.2% vs. Stealth's 1.5%).

## Container/Kubernetes constraints

**Why the broker model breaks down in K8s:** brokers need a legible app boundary to sit in front of. Shared multi-tenant clusters encapsulate pod-to-pod traffic (VXLAN/Geneve) between nodes — an external firewall/broker sees only node-to-node UDP encapsulation; pod identity/namespace/labels are invisible at that layer. Building the dependency map is the real problem, not the brokering.

**The eBPF/Cilium answer — and its hard boundary:** Cilium assigns each pod a numeric identity from K8s labels; identity travels in packet metadata; the **receiving node's kernel eBPF program** evaluates policy via BPF map lookups — independent of overlay encapsulation. This is now close to default for production clusters (e.g., Azure CNI Overlay + Cilium as the 2026 AKS standard). This closes L3/L4 identity-based east-west enforcement cleanly.

**What it does NOT do — this is a hard architectural boundary, not a maturity gap that closes with a release:**
- **No TLS/SSL decrypt.** No CA infrastructure, no MITM capability. Embedded Envoy does L7 metadata matching (HTTP method/path, gRPC service, DNS FQDN) only on traffic already readable in cleartext; mTLS-secured mesh traffic falls back to L3/L4 only.
- **No IDS/IPS signature/behavioral engine.** Hubble = flow telemetry (NetFlow analog), not inspection.
- **No App-ID equivalent.** Cilium "identity" = label-hash policy identity — a different concept from PAN-OS App-ID's protocol-behavior/payload-signature classification. Don't conflate these in architecture docs.

**Governance gap:** K8s-native policy (CiliumNetworkPolicy/NetworkPolicy YAML) lives entirely outside Panorama/FPMS. This is a governance/audit gap requiring an explicit answer, not something that resolves itself.

**Recommended egress/decrypt patterns for containerized workloads** (increasing centralization):
1. Service-mesh sidecar TLS termination (Istio/Envoy mTLS) — mesh-scoped only, own CA-governance problem.
2. **Dedicated egress gateway** (Istio egress gateway or PA VM-series as mandatory cluster egress) — Cilium's job narrows to "guarantee this is the only path out"; decrypt/DLP/App-ID happens at the gateway using existing PAN-OS stack. **Preferred pattern for this estate.**
3. NAT/proxy-chain into existing PA estate.

Treating "Cilium enforces network policy" as "this traffic is inspected" reproduces the Alert-All-SPG pattern in a new form — a control that looks like it covers a case it doesn't.

## Encrypted-traffic inspection vs. PCI/HIPAA

**Critical correction to carry into any compliance conversation: neither PCI DSS 4.0 nor HIPAA mandates network-layer decryption.** PCI Req 4.1 mandates strong crypto *in transit* (protect it, not defeat it); Req 4.2.1/4.2.1.1 require cert/key inventory and validity management. PCI's own IDS/IPS language (~Req 11.4.7 area) explicitly accepts real-time endpoint scanning, egress traffic filtering, and DLP tools as compliant malware-detection mechanisms — none require decrypt.

**The decrypt requirement in this estate is a compensating-control design choice** (App-ID/Content-ID/DLP on PAN-OS requires decrypt to function) — **not an external regulatory mandate.** This distinction changes the remediation path entirely and should never be conflated in leadership material.

**Why this matters architecturally:** PCI/HIPAA's network-control language was written against a **client-centric threat model** (human-operated endpoint → server: phishing, compromised workstation). Server-to-server/pod-to-pod east-west traffic has no user-session texture to baseline against, and legitimate high-frequency machine traffic is statistically indistinguishable from C2 beaconing — the compliance model doesn't natively fit this threat surface, which is why containerized east-west strains it.

**Encrypted Traffic Analysis (ETA) — decrypt-free detection, by category:**
- **Handshake/cert metadata (cleartext pre-encryption):** JA3/JA3S/JA4 TLS fingerprinting (client/server library fingerprint from ClientHello/ServerHello — catches non-browser TLS stacks like C2 frameworks); SNI-based domain policy/logging; certificate anomalies (self-signed, CN/SAN mismatch, short validity).
- **Flow-behavioral/statistical:** packet size distribution, inter-arrival timing, volume/direction asymmetry — the basis of NDR platforms (Darktrace, ExtraHop, Vectra, Corelight); directly aligned with the IDS/IPS rebuild program's existing beacon-heuristic/C2 detection work (see `ids-ips-policy-rebuild` skill).
- **Workload/process-identity runtime detection:** Cilium Tetragon / Falco (eBPF syscall-level hooks — process exec, file access, network activity, independent of payload encryption). **Maturity caveat, state explicitly if recommending this:** baseline-building is largely manual per-workload (doesn't scale to a 1,000-tenant estate any better than hand-written ACLs), high false-positive rates without deep per-app knowledge the estate doesn't have, no mature curated threat-intel feed comparable to commercial EDR. Document as an immature, probabilistic compensating control, never as IDS/IPS parity.
- **DNS-layer visibility:** cleartext pre-connection lookups; DGA-pattern/high-entropy domains, anomalous query volume — ties directly to Cilium's own FQDN-based egress policy.

**The irreducible ceiling:** none of the above confirms *what data* traversed an encrypted channel — only that the connection pattern was anomalous. Closing that specific gap requires either (a) a controlled decrypt boundary (the egress-gateway pattern above) for the subset of traffic genuinely in PCI/HIPAA scope, or (b) data minimization at the source (tokenization/field-level encryption of PAN/PHI before it reaches the network layer, satisfying PCI Req 3.4 regardless of transport-layer visibility).

## Open due-diligence questions to carry into any vendor conversation

- **Zscaler:** which capabilities trace to native ZPA vs. Edgewise-derived vs. Airgap-derived code paths, and what integration work has actually occurred since each acquisition (ask directly — not publicly documented).
- **Illumio/Guardicore POC:** score dependency-mapping accuracy against known application inventories as the primary criterion, not raw enforcement capability (enforcement is commodity; discovery is the scarce value).
- **Any container security requirement:** must state the chosen egress/decrypt pattern explicitly (Section above) — silence on this defaults to an unstated, unaudited gap.
- **K8s policy governance:** how CiliumNetworkPolicy/NetworkPolicy will be represented in or reconciled against Panorama/FPMS — currently an open, unresolved question estate-wide.

## Related skills
- `nac-ztna-fpms` — Forescout/NAC scope this segmentation work is meant to pair with.
- `panos-dlp-decrypt-migration` — the estate's existing decrypt/DLP gap that any container egress pattern must reconcile with.
- `ids-ips-policy-rebuild` — beacon-heuristic/C2 detection work the ETA behavioral-analysis section builds on.
- `cvs-netsec-context` — estate-wide facts (App-ID adoption gap, no source-of-truth, Alert-All-SPG pattern) referenced throughout this analysis.
